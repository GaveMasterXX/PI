<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    $file_list = array( "net_types.h",
			"net_functions.c",
			"net_io.c",
			"net_exec_step.c",
			"net_main.c",
			"net_dbginfo.c" );

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $dir = $user_dir . "/code_gen/" . $out_file;
    if( !file_exists($dir) ) mkdir( $dir );

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $tdset = array();
    $td_cnt = 0;
    $xpath = new DOMXPath( $pnmlDoc );
    $tdlist = $xpath->query( "//pnml/net/place/timedomain/text" );
    foreach( $tdlist as $tdn ) {
        $td = $tdn->textContent;
        if( !isset($tdset[$td]) ) {
	    $tdset[$td] = true;
	    ++$td_cnt;
	}
    }
    if( $td_cnt > 1 ) {
        echo( "<p>GALS Model: Please decompose and generate code for each component.</p>" );
	die( "<p><a href='index.php'> Return to model </a></p>" );
    }

    $mod_time  = date("Y-m-d H:i:s", filemtime($pnml_file));

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2c_inc.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','model_version', $mod_time);
    $proc->transformToURI($pnmlDoc, $dir . "/" . "net_types.h" );
    unset( $xsldoc );
    unset( $proc );

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2c_func.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','inc_file','net_types.h');
    $proc->transformToURI($pnmlDoc, $dir . "/" . "net_functions.c" );
    unset( $xsldoc );
    unset( $proc );

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2c_main.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','inc_file','net_types.h');
    $proc->transformToURI($pnmlDoc, $dir . "/" . "net_main.c" );
    unset( $xsldoc );
    unset( $proc );

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2c_io.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','inc_file','net_types.h');
    $proc->transformToURI($pnmlDoc, $dir . "/" . "net_io.c" );
    unset( $xsldoc );
    unset( $proc );

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2c_exec_step.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','inc_file','net_types.h');
    $proc->transformToURI($pnmlDoc, $dir . "/" . "net_exec_step.c" );
    unset( $xsldoc );
    unset( $proc );


    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2c_dbginfo.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','inc_file','net_types.h');
    $proc->transformToURI($pnmlDoc, $dir . "/" . "net_dbginfo.c" );
    unset( $xsldoc );
    unset( $proc );

    $zipname = $user_dir . "/code_gen/" . $out_file . ".zip";
    if( file_exists($zipname) ) unlink( $zipname );
    $zipfile = new ZipArchive();
    $zipfile->open( $zipname, ZIPARCHIVE::CREATE );
    $zipfile->addEmptyDir( $out_file );
    $zipfile->addFile( "cgMakefile", $out_file . "/" . "Makefile" );
    foreach( $file_list as $file ) {
	$zipfile->addFile( $dir . "/" . $file, $out_file . "/" . $file );
    }
    $zipfile->addFile( "server/http_server.h", $out_file . "/http_server.h" );
    $zipfile->addFile( "server/http_server.c", $out_file . "/http_server.c" );
    $zipfile->addFile( "server/net_server.h", $out_file . "/net_server.h" );
    $zipfile->addFile( "server/net_server.cpp", $out_file . "/net_server.c" );
    $zipfile->addFile( "gpio/linux_sys_gpio.c", $out_file . "/linux_sys_gpio.c" );
    $zipfile->addFile( "gpio/raspi_mmap_gpio.c", $out_file . "/raspi_mmap_gpio.c" );
    $zipfile->addFile( "gpio/dummy_gpio.c", $out_file . "/dummy_gpio.c" );
    $zipfile->close();

    foreach( $file_list as $file ) unlink( $dir . "/" . $file );
    rmdir( $dir );

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename( $zipname ) );
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize( $zipname ) );
    ob_clean();
    flush();
    readfile( $zipname );
    unlink( $zipname );
?>
