<?php
    // Author: 2013 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $pnmlDocInit = new DOMDocument();
    $pnmlDoc = new DOMDocument();

    $pnmlDocInit->load($pnml_file);

    //aplicar a cleanIDs.xsl para remver simbolos de pontuacao dos IDs/nomes 
    $xslClean = new DOMDocument;
    $xslClean->load('xsl/cleanIDs.xsl');
    $procClean = new XSLTProcessor;
    $procClean->importStyleSheet($xslClean); 
    $pnmlDoc->loadXML( $procClean->transformToXML($pnmlDocInit) );

    $xpath = new DOMXPath( $pnmlDoc );

    echo "<HTML>\n";
    echo "<HEAD>\n";
    echo "<TITLE> IOPT State Space Generation with Custom Initial Marking </TITLE>\n";
    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n";
    //echo "<script src='query_script.js'></script>\n";
    echo "<link href='../css/style.css' rel='stylesheet' type='text/css' media='screen' />\n";
    echo "</HEAD>\n";
    echo "<BODY>\n";
 
    echo "<center>\n";
    echo "<p><font size='+2'><b> State-space Generator<br/>";
    echo "Initial Marking Editor</b></font></p>\n";

    echo "<form name='initial_marking' action='ss_start.php' method='post'>\n";

    echo "<table width='60%' border='3' cellpadding='2' rules='none'>\n";
    echo "<tr><th align='center' colspan='2'> Model " . $_SESSION["pnml_file"] . "</th></tr>\n";

    $pl_names = $xpath->query( "//pnml/net/place/name/text" );


    $place_names = array();
    $duplicates = false;
    foreach( $pl_names as $pname ) {
	$place = $pname->parentNode->parentNode;
        $name = $pname->textContent;
        $id = $place->getAttribute( "id" );
	if( isSet($place_names[$name]) ) {
	    echo "<blink>Error: Duplicate place name (previous id=$place_names[$name]).</blink>";
	    $duplicates = true;
	}
	else $place_names[$name] = $id;
    }

    echo "<tr><td colspan='2' align='center'>";
    if( $duplicates )
	echo "<input type='submit' name='original_marking' value='Use Original Marking'></input>\n";
    else
	echo "<input type='submit' name='custom_marking' value='Generate State Space'></input>\n";
    echo "&nbsp; &nbsp; &nbsp;\n";
    echo "<input type='button' name='cancel' value='Cancel' onclick='window.close();'></input>\n";
    echo "</td></tr>\n";

    echo "<tr><td align='center'>Place:</td><td aling='center'>Marking:</td></tr>\n";
    $place_names = array();

    foreach( $pl_names as $pname ) {
	$place = $pname->parentNode->parentNode;
        $name = $pname->textContent;
        $id = $place->getAttribute( "id" );

        $def_value = 0;
        $initm_node = $place->getElementsByTagName("initialMarking");
	if( $initm_node->length == 1 ) {
	    $text = $initm_node->item(0)->getElementsByTagName( "text" );
	    if( $text->length == 1 ) 
		$def_value = intval( $text->item(0)->textContent );
	}

	echo "<tr>";
	echo "<td align='right'> $name [$id]:</td>\n";
        echo "<td><input type='number' name='p_$id' value='$def_value'></input>";
	if( isSet($place_names[$name]) ) {
	    echo "<blink>Error: Duplicate place name (previous id=$place_names[$name]).</blink>";
	}
	else $place_names[$name] = $id;

	echo "</td></tr>\n";
    }

    echo "</table>\n";
    echo "</center>\n";

    echo "</BODY>\n";
    echo "</HTML>\n";
?>
