// PNML Editor
// 2012 (C) GRES Research Group - FCT/UNL - Uninova

const EditModes = { "Select":0, "Place":1, "Transition":2, "Arc":3,
                    "AsyncChannel":4, "Erase":5, "InSignal":6, "OutSignal":7,
                    "InEvent":8, "OutEvent":9, "Annotations":10,
                    "EditArc":11, "NewArray":12, "Scroll":13 };
const EditModesStr = [ "Select", "Add Place", "Add Transition", "Add Arc",
                       "Add Async Channel", "Erase",
                       "Add Input Signal", "Add Output Signal",
                       "Add Input Event", "Add Output Event",
                       "Edit Annotations", "Edit Arc", "Add Array/Table",
                       "Scroll Page" ];

const SNAP=10;
const MAX_OFF=80;
const MAX_PL_OUT=10;
const MAX_TR_OUT=8;

var pnml = null;
var undo_history = [];
var redo_list = [];
var clipboard_data = [];
var xsltProcessor = null;
var exprToStrXsltProc = null;
var iframe_doc = null;
var iframe_elem = null;
var drawingarea = null;
var dwframe = null;
var statusbar = null;
var coord_x = null;
var coord_y = null;
var mouse_x = 0;
var mouse_y = 0;
var start_x = 0;
var start_y = 0;
var clipboard_window = null;
var expr_window = null;
var expr_stvec_mode = false;

var node_nr = 1;
var sel_node = null;
var node_type = "empty";
var changed = false;
var moved = false;
var edit_mode = EditModes.Select;
var source_node_id = null;
var source_node_x = 0;
var source_node_y = 0;
var arc_mode = "entry";
var button_pressed = false;
var arc_point_idx = 0;
var arc_graphics = null;

var annotation_node = null;
var annotation_pos = null;
var annotation_off = null;
var annotation_text = null;

var msel_mode = "none";
var msel_start_x = 0;
var msel_start_y = 0;
var msel_end_x = 0;
var msel_end_y = 0;
var multiple_sel = [];
var multiple_sel_pos = [];
var sel_edit_expr = null;
var edit_expr_input = null;
var backup_expr = null;
var plugin_name = null;
var plugin_doc = null;

var snap_to_grid = true;
var show_grid = true;
var tmove_count = 0;

var chrome = false;
var safari = false;



function loadXMLDoc( dname )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Error: Web Browser does not support XMLHttpRequest !" );
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}



function saveXMLDoc( dname, doc )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Error: Web Browser does not support XMLHttpRequest !" );
    xhttp.open( "POST", dname, false );
    xhttp.setRequestHeader("Content-Type", "text/xml"); 
    xhttp.send(doc);
    return xhttp.status;
}



function loadDocument()
{
    pnml = loadXMLDoc("get_model.php");
    var xsl = loadXMLDoc("xsl/iopt2svg-edit.xslt");
    xsltProcessor = new XSLTProcessor();
    xsltProcessor.importStylesheet(xsl);
    dwframe = document.getElementById("drawingarea");
    drawingarea = dwframe.contentWindow;
    iframe_doc  = dwframe.contentDocument;
    iframe_elem = iframe_doc.documentElement;
    statusbar = document.getElementById("status");
    coord_x = document.getElementById("coord_x");
    coord_y = document.getElementById("coord_y");
    undo_history = [];
    unselect();
    saveHistory();
    changed = false;
    snap_to_grid = true;
    show_grid = true;

    chrome = (navigator.userAgent.indexOf( "Chrome" ) > 0);
    safari = (navigator.userAgent.indexOf( "Safari" ) > 0);
    if( safari && (chrome || navigator.userAgent.indexOf( "Android" ) > 0) ) {
        chrome = true;
        safari = false;
    }

    nodes = pnml.getElementsByTagName( "*" );
    for( var i = 0; i < nodes.length; ++i ) {
        if( node_nr <= Number(nodes[i].getAttribute("id")) ) {
           node_nr = 1 + Number(nodes[i].getAttribute("id"));
        }
    }

    iframe_elem.addEventListener( "touchcancel",touch_cancel, true );
    iframe_elem.addEventListener( "mouseup",    bg_move, true );
    iframe_elem.addEventListener( "keydown", keyPressed, true );

    if( chrome || safari ) {
        iframe_elem.addEventListener( "touchstart", catch_touch, false );
        iframe_elem.addEventListener( "touchmove",  catch_touch, false );
        iframe_elem.addEventListener( "touchend",   catch_touch, false );
    }

    // Net name must be a valid C identifier
    var net = pnml.getElementsByTagName( "net" ) [0];
    if( net != null ) {
        net.setAttribute( "name", validateName( net.getAttribute( "name" ) ) );
    }

    var exprToStrXsl = loadXMLDoc( "xsl/expr2str.xslt" );
    exprToStrXsltProc = new XSLTProcessor();
    exprToStrXsltProc.importStylesheet(exprToStrXsl);

    if( !(chrome && navigator.userAgent.indexOf( "Android" ) > 0) ) 
        updateAllExpressionsText();
    updatePNMLVersion( pnml );
    redrawNet();
}


var redraw_tmout = null;


function drawNet()
{
    var i, j;
    var nodes = iframe_elem.childNodes;
    for( i=nodes.length-1; i >= 0; i-- ) {
        iframe_elem.removeChild( nodes[i] );
    }

    redraw_tmout = null;

    xsltProcessor.setParameter( null, "show_grid", show_grid ? "1" : "0" );
    xsltProcessor.setParameter( null, "edit_annotations", 
                                (edit_mode==EditModes.Annotations) ? "1": "0" );
    xsltProcessor.setParameter( null, "sel_arc", 
                                (sel_node != null && node_type == "arc") ?
                                sel_node.getAttribute("id") : 0 );
    if( edit_mode==EditModes.Arc && source_node_id != null ) {
        xsltProcessor.setParameter( null, "new_arc", 
                                    String(source_node_x) + " " + 
                                    String(source_node_y) + " " +
                                    String(cursor_x) + " " +
                                    String(cursor_y) );
    }
    else xsltProcessor.setParameter( null, "new_arc", "'-'" );

    // code for Mozilla, Firefox, Opera, etc.
    if (document.implementation && document.implementation.createDocument)
    {
        resultDocument = xsltProcessor.transformToFragment(pnml,iframe_doc);
        iframe_elem.appendChild(resultDocument);
    }

    var sel_id = -1;
    if( sel_node != null ) sel_id = sel_node.getAttribute( "id" );

    var items = iframe_elem.getElementsByTagName( "*" );
    for( i = 0; i < items.length; ++i ) {
        var selected = false;
        var id1 = items[i].getAttribute( "id" );
        if( id1 == null ) continue;
        if( id1 == sel_id ) selected = true;
        else for( j = 0; j < multiple_sel.length; ++j ) {
            var id2 = multiple_sel[j].getAttribute( "id" );
            if( id2 == null ) continue;
            if( id1 == id2 ) {
                 selected = true;
                 break;
            }
        }
        if( selected == true ) {
            items[i].setAttribute( "stroke", "red" );
            if( items[i].getAttribute( "stroke-width" ) < 2 )
                items[i].setAttribute( "stroke-width", "2" );
        }
    }

    drawingarea.focus();
}


function redrawNet()
{
    if( redraw_tmout == null ) redraw_tmout = setTimeout( drawNet, 40 );
}



function translateSelection( offx, offy )
{
    var i, j, sel_id = -1;
    if( sel_node != null ) sel_id = sel_node.getAttribute( "id" );

    var offset = "translate(" + offx + "," + offy + ")";

    var items = iframe_elem.getElementsByTagName( "g" );
    for( i = 0; i < items.length; ++i ) {
        var selected = false;
        var id1 = items[i].getAttribute( "id" );
        if( id1 == null ) continue;
        if( id1 == sel_id ) selected = true;
        else for( j = 0; j < multiple_sel.length; ++j ) {
            var id2 = multiple_sel[j].getAttribute( "id" );
            if( id2 == null ) continue;
            if( id1 == id2 ) {
                 selected = true;
                 break;
            }
        }

        if( !selected && items[i].getAttribute( "node-type" ) == "arc" )
        {
             var arc = findNode( "arc", id1 );
             var source = arc.getAttribute( "source" );
             var target = arc.getAttribute( "target" );
             if( source == sel_id ) source = -1;
             else if( target == sel_id ) target = -1;
             else for( j = 0; j < multiple_sel.length; ++j ) {
                var id2 = multiple_sel[j].getAttribute( "id" );
                if( source == id2 ) source = -1;
                if( target == id2 ) target = -1;
             }
             if( source == -1 && target == -1 ) selected = true;
             else if( source == -1 || target == -1 ) 
                items[i].setAttribute( "opacity", 0.20 );
        }

        if( selected == true ) items[i].setAttribute( "transform", offset );
    }
}



function save()
{
    if ( !validatePnml() ) {
        alert("File NOT saved");
        return;
    }
    updateAllExpressionsText();
    var ser = new XMLSerializer();
    var output = ser.serializeToString( pnml );
    var res = saveXMLDoc( "save_model.php", output );
    if( res == 409 ) alert( "Cannot save: File changed by other user !\nTo keep changes: Select all, Paste to clipoard and Copy to another model." );
    else if( res > 200 ) alert( "Error " + res + " uploading model" );
    else changed = false;
}



function cancel()
{
    if( changed ) {
        if( confirm( "Save changes ?" ) ) {
            save();
            if( changed == true ) return;
        }
    }
    document.location.href = "index.php";
}



function deleteNode( ntype, id )
{
    var net = pnml.getElementsByTagName( "net" )[0];
    if( net == null ) return;

    var nodes = net.getElementsByTagName( ntype );
    for( var i = 0; i < nodes.length; ++i ) {
        if( nodes[i].getAttribute("id") == id ) {
            nodes[i].parentNode.removeChild( nodes[i] );
            redrawNet();
            saveHistory();
            return;
        }
    }
}


function nodeHasArcs( node_id )
{
    var arcs = pnml.getElementsByTagName( "arc" );
    for( var i = 0; i < arcs.length; ++i ) {
        if( arcs[i].getAttribute("target") == node_id ) return true;
        if( arcs[i].getAttribute("source") == node_id ) return true;
    }
    return false;
}



function isAsyncChannel( node )
{
    if( node.nodeName != 'place' ) return false;
    var placetype = node.getElementsByTagName( "placetype" )[0];
    if( placetype == null ) return false;
    return (placetype.textContent == "asyncchannel");
}



function isRecOrUnfAsyncChannel( node )
{
    if( node.nodeName != 'place' ) return false;
    var placetype = node.getElementsByTagName( "placetype" )[0];
    if( placetype == null ) return false;
    if (placetype.textContent != "asyncchannel") return false;
    var actype = node.getElementsByTagName( "actype" )[0];
    return (actype.textContent == "acknowledge" || actype.textContent == "notenable");
}

function getNodeText( node, name )
{
    var nodetype = node.getElementsByTagName( name )[0];
    if( nodetype == null ) return false;
    var nodetext = nodetype.getElementsByTagName( "text" )[0];
    if( nodetext == null || !nodetext.textContent.length ) return false;
    return nodetext.textContent;
}


function nodeHasChannels( node_id )
{
    var nodes = pnml.evaluate( "//net//arc[(@source='" + node_id + "' or @target='" + node_id + "') and type='channel']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;
    return false;
}



function findNode( ntype, id )
{
    var nodes = pnml.getElementsByTagName( ntype );
    for( var i = 0; i < nodes.length; ++i ) {
        if( nodes[i].getAttribute("id") == id ) return nodes[i];
    }
    return null;
}



function findNodeByName( ntype, nname )
{
    var nodes = pnml.evaluate( "//net/" + ntype + "/name[text='" + nname + "']",
                pnml, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null );  
    return nodes.singleNodeValue;
}


function signalUsedByEvents( sig_id )
{
    var nodes = pnml.evaluate( "//net//event[@signal='"+sig_id+"']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;
    return false;
}


function signalUsedByArrays( sig_id )
{
    var nodes = pnml.evaluate( "//net/variable/array[@index1='" + sig_id +
                               "' or @index2='" + sig_id + "']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;
    return false;
}


function signalDefinedByPlaceOutputActions( sig_id )
{
    var nodes = pnml.evaluate(
     "//net//place/signalOutputActions/signalOutputAction[@idRef='"+sig_id+"']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    return( nodes.snapshotLength > 0 );
}


function signalDefinedByTransitionOutputActions( sig_id )
{
    var nodes = pnml.evaluate(
     "//net//transition/signalOutputActions/signalOutputAction[@idRef='"+sig_id+"']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    return( nodes.snapshotLength > 0 );
}


function signalUsedByPlaceOutputActions( sig_id )
{
    if( signalDefinedByPlaceOutputActions( sig_id ) ) return true;

    var nodes = pnml.evaluate(
     "//net//place/signalOutputActions//expression//operand[@idRef='" + sig_id +
     "' or @idx1='" + sig_id + "' or @idx2='" + sig_id + "']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;

    return false;
}


function signalUsedByTransitionGuards( sig_id )
{
    nodes = pnml.evaluate(
     "//net//transition/signalInputGuards//expression//operand[@idRef='"+sig_id+"']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;

    return false;
}


function signalUsedByTransitionOutputActions( sig_id )
{
    if( signalDefinedByTransitionOutputActions( sig_id ) ) return true;

    var nodes = pnml.evaluate(
         "//net//transition/signalOutputActions//expression//operand[@idRef='" +
         sig_id + "' or @idx1='" + sig_id + "' or @idx2='" + sig_id + "']",
         pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;

    return false;
}


function signalInUse( sig_id )
{
    if( signalUsedByEvents( sig_id ) ) return true;
    if( signalUsedByPlaceOutputActions( sig_id ) ) return true;
    if( signalUsedByTransitionOutputActions( sig_id ) ) return true;
    if( signalUsedByTransitionGuards( sig_id ) ) return true;
    if( signalUsedByArrays( sig_id ) ) return true;
    return false;
}



function eventInUse( ev_id )
{
    var nodes = pnml.evaluate( "//net//transition//event[@idRef='"+ev_id+"']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;
    return false;
}



function findArc( source_id, target_id )
{
    var nodes = pnml.evaluate( "//net//arc[@target='" + target_id +
                               "' and @source='" + source_id + "']",
                pnml, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null );  
    return nodes.singleNodeValue;
}

function findArcWithTarget( target_id )
{
    var nodes = pnml.evaluate( "//net//arc[@target='" + target_id + "']",
                pnml, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null );  
    return nodes.singleNodeValue;
}

function existsArcChannelWithTarget( target_id )
{
    var nodes = pnml.evaluate( "//net//arc[@target='" + target_id + "' and type='channel']",
                pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    if( nodes.snapshotLength > 0 ) return true;
    return false;
}

function getPlaceList()
{
     return pnml.getElementsByTagName( "place" );
}



function getArrayList()
{
    var vars = pnml.getElementsByTagName( "variable" )[0];
    if( vars == null ) return null;
    var arrays = vars.getElementsByTagName( "array" );

    var result = [];
    for( var i = 0; i < arrays.length; ++i ) {
        var id = arrays[i].getAttribute( "id" );
        var idx1 = arrays[i].getAttribute( "index1" );
        if( findNode( "signal", idx1 ) == null ) continue;
        var idx2 = arrays[i].getAttribute( "index2" );
        var constant = arrays[i].getAttribute( "constant" );
        if( expr_stvec_mode && (
            constant != "true" ||
            signalDefinedByPlaceOutputActions( idx1 ) ||
            signalDefinedByPlaceOutputActions( idx2 ) ) ) continue;
        result.push( arrays[i] );
    }

    return result;
}



function getTransitionList()
{
     return pnml.getElementsByTagName( "transition" );
}


function getSignalList( stype )
{
    var signals = pnml.getElementsByTagName( "signal" );
    var result = [];

    if( expr_stvec_mode && stype == "input" ) return result;

    for( var i = 0; i < signals.length; ++i ) {
        if( signals[i].parentNode.nodeName == stype ) {
            var id = signals[i].getAttribute( "id" );
            if( expr_stvec_mode && signalDefinedByPlaceOutputActions( id ) ) 
                continue;
            result.push( id );
        }
    }

    return result;
}



function unselect()
{
    sel_node = null;
    sel_position = null;
    node_type = "empty";
    msel_mode = "none";
    multiple_sel = [];
    multiple_sel_pos = [];
    annotation_node = null;
    annotation_pos = null;
    annotation_off = null;
    annotation_text = null;
    sel_edit_expr = null;
    edit_expr_input = null;
    document.getElementById("properties").src = "prop.html";
}



function pickNode( type, evt )
{
    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
    }

    evt.preventDefault();

    unselect();
    button_pressed = false;

    var id = evt.target.getAttribute( type + "-id" );

    if( edit_mode == EditModes.Erase ) {
        if( (type == "place" || type == "transition" ) && nodeHasArcs( id ) )
            alert( "Error: Node has connected arcs" );
        else if( type == "event" && eventInUse( id ) )
            alert( "Error: Event used by transitions" );
        else if( (type == "signal" || type=="array") && signalInUse( id ) )
            alert( "Error: Signal used by events, arrays or output actions" );
        else deleteNode( type, id );

        if( !evt.shiftKey ) edit_mode = EditModes.Select;
        unselect();
        return;
    }

    if( edit_mode == EditModes.Arc &&
        (type == "place" || type == "transition" ) ) {
        addArc( type, id );
        return;
    }

    sel_node = findNode( type, id );

    if( sel_node != null ) {
        sel_position = sel_node.getElementsByTagName( "position" )[0];
        node_type = type;
        if( isAsyncChannel( sel_node ) )
            document.getElementById("properties").src = "asyncchannel.html";
        else document.getElementById("properties").src = type + ".html";
        statusbar.value = "Select " + type + " " + id +
                          (isAsyncChannel(sel_node) ? " [AsyncChannel]" : "");
    }
    else node_type = "empty";

    if( sel_node != null && sel_node.nodeName == 'arc' ) {
        redrawNet();
        if( chrome ) edit_mode = EditModes.EditArc;
    }
}



function selectAll()
{
    unselect();
    multipleSelect( -Infinity, -Infinity, Infinity, Infinity, false);
    redrawNet();
}


function invertSelection()
{
    var old_sel = multiple_sel;
    if( old_sel.length < 1 && sel_node != null ) old_sel.push( sel_node );

    selectAll();
    all_nodes = multiple_sel;
    all_nodes_pos = multiple_sel_pos;
    multiple_sel = [];
    multiple_sel_pos = [];

    for( var i = 0; i < all_nodes.length; ++i ) {
        if( old_sel.indexOf( all_nodes[i] ) < 0 ) {
            multiple_sel.push( all_nodes[i] );
            multiple_sel_pos.push( all_nodes_pos[i] );
        }
    }

    if( multiple_sel.length > 0 ) {
        statusbar.value = "Select "+multiple_sel.length+" nodes";
        msel_mode = "done";
    }
    else {
        msel_mode = "none";
        statusbar.value = "Select none";
    }

    redrawNet();
}


function multipleSelect( startx, starty, endx, endy, add )
{
    var aux;
    if( startx > endx ) { aux = startx; startx = endx; endx = aux; }
    if( starty > endy ) { aux = starty; starty = endy; endy = aux; }

    if( add ) { 
        if( multiple_sel.length < 1 && sel_node != null ) {
            multiple_sel.push( sel_node );
            multiple_sel_pos.push( sel_position );
        }
        sel_node = null;
        sel_position = null;
        node_type = "empty";
    }
    else unselect();

    var nodes = pnml.evaluate("//net//*[name()='place' or name()='transition' or name()='signal' or name()='event' or name()='array']/graphics/position", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  

    for( var i = 0; i < nodes.snapshotLength; ++i ) {
        var pos = nodes.snapshotItem(i);
        if( multiple_sel_pos.indexOf( pos ) >= 0 ) continue;
        var x = Number(pos.getAttribute( "x" ));
        var y = Number(pos.getAttribute( "y" ));
        if( x >= startx && x <= endx && y >= starty && y <= endy ) {
            multiple_sel_pos.push( pos );
            multiple_sel.push( nodes.snapshotItem(i).parentNode.parentNode );
        }
    }

    if( multiple_sel.length > 0 ) {
        statusbar.value = "Select "+multiple_sel.length+" nodes";
        msel_mode = "done";
    }
    else {
        msel_mode = "none";
        statusbar.value = "Select none";
    }
}



function scrollWindow( evt )
{
    var btn, x, y;

    evt.preventDefault();
    evt.stopPropagation();

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
        btn = 0;
        x = evt.changedTouches[0].screenX;
        y = evt.changedTouches[0].screenY;
    }
    else {
        btn = evt.button;
        x = evt.screenX;
        y = evt.screenY;
    }

    if( btn != 0 || evt.type == "mouseup" || evt.type == "touchend" ) {
        setEditMode( EditModes.Select );
        button_pressed = false;
        start_x = 0;
        start_y = 0;
        return;
    }

    if( evt.type == "mousedown" || evt.type == "touchstart" )
        button_pressed = true;
    else if( button_pressed ) drawingarea.scrollBy( start_x-x, start_y-y );
    start_x = x;
    start_y = y;
}


function node_move( evt )
{
    var btn;

    if( edit_mode == EditModes.Scroll ) {
        scrollWindow( evt );
        return;
    }

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
        btn = 0;
        tmove_count = 0;

    }
    else btn = evt.button;

    evt.preventDefault();
    var type = evt.target.getAttribute( "node-type" );

    if( edit_mode == EditModes.Erase ) {
        if( evt.type == "mousedown" || evt.type == "touchstart" )
            pickNode( type, evt );
        return;
    }
    else if( edit_mode == EditModes.Annotations ) {
        annotMove( evt );
        return;
    }
    else if( edit_mode == EditModes.EditArc ) {
        arc_move( evt );
        return;
    }

    var i;

    if( evt.type == 'mousedown' || evt.type == 'touchstart' ) {
        moved = false;
        if( btn == 0 ) {
            if( evt.shiftKey && sel_node != null && multiple_sel.length == 0 ) {
                multiple_sel.push( sel_node );
                multiple_sel_pos.push( sel_position );
                sel_node = null;
                sel_position = null;
            }

            if( multiple_sel.length > 0 ) {
                var pick_id = evt.target.getAttribute( type + "-id" );
                var found = false;
                for( i = 0; i < multiple_sel.length; ++i ) {
                    var sel_id = multiple_sel[i].getAttribute( "id" );
                    if( pick_id == sel_id ) {
                        found = true;
                        break;
                    }
                }
                if( found ) {
                    if( multiple_sel.length > 0 && evt.ctrlKey ) {
                        multiple_sel.splice( i, 1 );
                        multiple_sel_pos.splice( i, 1 );
                        statusbar.value= "Select "+multiple_sel.length+" nodes";
                    }
                }
                else if( evt.shiftKey && type != 'arc' ) {
                    var node = findNode( type, pick_id );
                    multiple_sel.push( node );
                    multiple_sel_pos.push(
                        node.getElementsByTagName("position")[0] );
                    statusbar.value = "Select "+multiple_sel.length+" nodes";
                }
                else unselect();
            }

            if( multiple_sel.length == 0 ) pickNode( type, evt );
            else sel_node = null;
            if( sel_node != null || multiple_sel.length > 0 )
                button_pressed = true;
        }
        else {
            button_pressed = 0;
            sel_node = null;
            sel_position = null;
        }
        if( !(chrome||safari) || evt.type == "mousedown" ) redrawNet();
    }

    bg_move( evt );
}



function bg_move( evt )
{
    var btn;

    if( edit_mode == EditModes.Scroll ) {
        scrollWindow( evt );
        return;
    }

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
        btn = 0;
        cursor_x = evt.changedTouches[0].pageX;
        cursor_y = evt.changedTouches[0].pageY;

        if( evt.type == "touchstart" ) tmove_count = 0;
        else if( evt.type == "touchmove" ) ++tmove_count;
        else {
            if( tmove_count<2 && evt.target.getAttribute("id")=="background" ) {
               bg_click( evt );
               return;
            }
            tmove_count = 0;
        }
    }
    else {
        btn = evt.button;
        cursor_x = evt.pageX;
        cursor_y = evt.pageY;
    }

    evt.preventDefault();
    evt.stopPropagation();

//statusbar.value = ("target=" + evt.target.getAttribute("id") + " msel=" + msel_mode + " type=" + evt.type +" buttonpress=" + button_pressed + " event x = " + cursor_x + " y = " + cursor_y + " btn = " + btn );

    if( edit_mode == EditModes.EditArc ) {
        arc_move( evt );
        return;
    }
    if( edit_mode == EditModes.Annotations ) {
        annotMove( evt );
        return;
    }

    var ex = cursor_x;
    var ey = cursor_y;

    if( snap_to_grid ) {
        ex = ex - ex % SNAP;
        ey = ey - ey % SNAP;
    }

    coord_x.value = ex;
    coord_y.value = ey;

    if( evt.type == "mousedown" || evt.type == "touchstart" ) {
        start_x = ex;
        start_y = ey;
    }

    if( edit_mode==EditModes.Arc && source_node_id != null ) redrawNet();

    if( edit_mode != EditModes.Select ) return;

    if( button_pressed && btn == 0 ) {
        if( evt.type == "mousemove" || evt.type == "touchmove" ) {
            if( multiple_sel.length > 0 ) {
                var offx = ex - msel_start_x;
                var offy = ey - msel_start_y;
                for( var i = 0; i < multiple_sel_pos.length; ++i ) {
                     var x = Number(multiple_sel_pos[i].getAttribute("x"));
                     var y = Number(multiple_sel_pos[i].getAttribute("y"));
                     multiple_sel_pos[i].setAttribute( "x", x+offx );
                     multiple_sel_pos[i].setAttribute( "y", y+offy );
                     msel_start_x = ex;
                     msel_start_y = ey;
                }
                if( !(chrome||safari) || evt.type == "mousemove" ) redrawNet();
                else translateSelection( ex - start_x, ey - start_y );
                moved = true;
                changed = true;
            }
            else if( sel_position != null ) {
                sel_position.setAttribute( "x", ex );
                sel_position.setAttribute( "y", ey );
                if( !(chrome||safari) || evt.type == "mousemove" ) redrawNet();
                else translateSelection( ex - start_x, ey - start_y );
                moved = true;
                changed = true;
            }
        }
        else if( evt.type == "mouseup" || evt.type == "touchend" ) {
            button_pressed = false;
            if( moved ) saveHistory();
            moved = false;
        }
    }
    
    switch( evt.type ) {
        case "mousedown":
        case "touchstart":
            if( !evt.shiftKey && evt.target.getAttribute("id")=="background" ) {
                unselect();
                if( !(chrome||safari) || evt.type == "mousedown" ) redrawNet();
                statusbar.value = "";
            }
            msel_start_x = cursor_x;
            msel_start_y = cursor_y;
            if( button_pressed == false ) msel_mode = "start";
            else msel_mode = "none";
            break;
        case "mousemove":
        case "touchmove":
            if( msel_mode == "start" ) msel_mode = "selecting";
            if( msel_mode == "selecting" ) {

               msel_end_x = cursor_x;
               msel_end_y = cursor_y;
               if( msel_end_x != msel_start_x &&
                   msel_end_y != msel_start_y ) {
                   var sel_area = iframe_elem.getElementsByTagName( "rect" )[1];
                   sel_area.setAttribute( "x",
                       Math.min(msel_start_x, msel_end_x) );
                   sel_area.setAttribute( "y",
                       Math.min(msel_start_y, msel_end_y) );
                   sel_area.setAttribute( "width",
                       Math.abs(msel_end_x-msel_start_x) );
                   sel_area.setAttribute( "height",
                       Math.abs(msel_end_y-msel_start_y) );
               }
            }
            break;
        case "mouseup":
        case "touchend":
            if( msel_mode == "selecting" ) {
                multipleSelect( msel_start_x, msel_start_y,
                                msel_end_x, msel_end_y, evt.shiftKey );
            }
            else msel_mode = "none";
            button_pressed = false;
            redrawNet();
    }
}



function bg_click( evt )
{
    var x, y, btn;

    if( edit_mode == EditModes.Scroll ) {
        scrollWindow( evt );
        return;
    }

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
        btn = 0;
        x = evt.changedTouches[0].pageX;
        y = evt.changedTouches[0].pageY;
        tmove_count = 0;
    }
    else {
        btn = evt.button;
        x = evt.pageX;
        y = evt.pageY;
    }

    evt.preventDefault();

    if( snap_to_grid ) {
       x = x - x % SNAP;
       y = y - y % SNAP;
    }

//statusbar.value = "click mode=" + edit_mode + " x=" + x + " y=" + y;

    switch( edit_mode ) {
        case EditModes.Select:
            unselect();
            redrawNet();
            break;
        case EditModes.Place: 
            addNode( "place", x, y );
            break;
        case EditModes.Transition:
            addNode( "transition", x, y );
            break;
        case EditModes.InSignal:
            addSignal( "input", x, y );
            break;
        case EditModes.OutSignal:
            addSignal( "output", x, y );
            break;
        case EditModes.NewArray:
            addArray( x, y );
            break;
        case EditModes.InEvent:
            addEvent( "input", x, y );
            break;
        case EditModes.OutEvent:
            addEvent( "output", x, y );
            break;
        case EditModes.Arc:
           break;
        case EditModes.AsyncChannel:
            addNode( "place", x, y, "asyncchannel" );
            break;
        case EditModes.Erase:
            edit_mode = EditModes.Select;
            statusbar.value = "";
            break;
        case EditModes.EditArc:
            return;
    }

    if( !evt.shiftKey ) {
        edit_mode = EditModes.Select;
        statusbar.value = "";
    }

    redrawNet();
}


function createArc( source_id, target_id, inscr_value )
{
    var net = pnml.getElementsByTagName( "net" )[0];

    var node = pnml.createElement( "arc" );
    node.setAttribute( "id", node_nr++ );
    node.setAttribute( "source", source_id );
    node.setAttribute( "target", target_id );

    var source = findNode( "*", source_id );
    var target = findNode( "*", target_id );

    var arcType = "normal";
    if( isAsyncChannel( source ) || isAsyncChannel( target ) )
        arcType = "channel";

    var type_node = pnml.createElement( "type" );
    type_node.appendChild( pnml.createTextNode( arcType ) );
    node.appendChild(type_node);

    var graphics = pnml.createElement( "graphics" );
    //var position = pnml.createElement( "position" );
    //position.setAttribute( "page", "1" );
    //position.setAttribute( "x", 0 );
    //position.setAttribute( "y", 0 );
    //graphics.appendChild(position);
    node.appendChild(graphics);

    var pos = source.getElementsByTagName( "position" )[0];
    var x1 = Number(pos.getAttribute( "x" ));
    var y1 = Number(pos.getAttribute( "y" ));
    pos = target.getElementsByTagName( "position" )[0];
    var mx = x1-Number(pos.getAttribute( "x" ));
    var my = y1-Number(pos.getAttribute( "y" ));

    var mod = Math.hypot( mx, my );
    if( mod < 1 ) {
        mx = 10;
	my = 10;
    }
    else {
	mx = (10*mx/mod)|0;
	my = (10*my/mod)|0;
    }

    var inscr = pnml.createElement( "inscription" );
    graphics = pnml.createElement( "graphics" );
    var offset = pnml.createElement( "offset" );
    offset.setAttribute( "page", "1" );
    offset.setAttribute( "x", -my );
    offset.setAttribute( "y",  mx+5 );
    graphics.appendChild(offset);
    inscr.appendChild(graphics);
    var value = pnml.createElement( "value" );
    value.appendChild( pnml.createTextNode(inscr_value) );
    inscr.appendChild( value );
    node.appendChild( inscr );

    net.appendChild( node );
    return node;
}


function addArc( mode, node_id )
{
    if( source_node_id == null ) {
        source_node_id = node_id;
        arc_mode = mode;
        source_node_x = cursor_x;
        source_node_y = cursor_y;
        redrawNet();
        return;
    }

    if( node_id == source_node_id || mode == arc_mode ) {
        alert( "Invalid Arc" );
        edit_mode = EditModes.Select;
        unselect();
        return;
    }

    target_node_id = node_id;

    if( findArc( source_node_id, target_node_id ) != null ) {
        alert( "Repeated Arc" );
        edit_mode = EditModes.Select;
        unselect();
        return;
    }

    var source = findNode( "*", source_node_id );
    var target = findNode( "*", target_node_id );
    if( isAsyncChannel( source ) || isAsyncChannel( target ) ) {
      if( existsArcChannelWithTarget(target_node_id) ) {
        alert( "Each node cannot have more than one input channel arc" );
        edit_mode = EditModes.Select;
        unselect();
        return;
      }
    }

    createArc( source_node_id, target_node_id, 1, mode );
 
    source_node_id = null;
    redrawNet();
    saveHistory();
}



function createNode( ntype, nm, x, y, im, subtype )
{
    var net = pnml.getElementsByTagName( "net" )[0];

    var node = pnml.createElement( ntype );
    node.setAttribute( "id", node_nr++ );

    var nname = pnml.createElement( "name" );
    var text = pnml.createElement( "text" );
    text.appendChild( pnml.createTextNode( nm ) );
    nname.appendChild( text );
    var graphics = pnml.createElement( "graphics" );
    var offset = pnml.createElement( "offset" );
    offset.setAttribute( "x", "-10" );
    offset.setAttribute( "y", "20" );
    graphics.appendChild(offset);
    nname.appendChild(graphics);
    node.appendChild( nname );

    var comment = pnml.createElement( "comment" );
    text = pnml.createElement( "text" );
    text.appendChild( pnml.createTextNode( "" ) );
    comment.appendChild( text );
    graphics = pnml.createElement( "graphics" );
    offset = pnml.createElement( "offset" );
    offset.setAttribute( "x", "-30" );
    offset.setAttribute( "y", "20" );
    graphics.appendChild(offset);
    comment.appendChild(graphics);
    node.appendChild( comment );

    if( ntype == "place" && subtype == "asyncchannel" ) {
        var placetype = pnml.createElement( "placetype" );
        placetype.appendChild( pnml.createTextNode("asyncchannel") );
        node.appendChild( placetype );
        var actype = pnml.createElement( "actype" );
        actype.appendChild( pnml.createTextNode("simple") );
        node.appendChild( actype );
    }
    else if( ntype == "place" ) {
        var initm = pnml.createElement( "initialMarking" );
        text = pnml.createElement( "text" );
        text.appendChild( pnml.createTextNode( im ) );
        initm.appendChild( text );
        graphics = pnml.createElement( "graphics" );
        offset = pnml.createElement( "offset" );
        offset.setAttribute( "x", "0" );
        offset.setAttribute( "y", "-1" );
        graphics.appendChild(offset);
        initm.appendChild(graphics);
        node.appendChild( initm );

        var bound = pnml.createElement( "bound" );
        text = pnml.createElement( "text" );
        text.appendChild( pnml.createTextNode("3") );
        bound.appendChild( text );
        node.appendChild( bound );
    }
    else if( ntype == "transition" ) {
        var priority = pnml.createElement( "priority" );
        priority.appendChild( pnml.createTextNode("1") );
        node.appendChild( priority );
        node.appendChild( pnml.createElement( "signalInputGuards" ) );
        node.appendChild( pnml.createElement( "inputEvents" ) );
    }
    graphics = pnml.createElement( "graphics" );
    position = pnml.createElement( "position" );
    position.setAttribute( "page", "1" );
    position.setAttribute( "x", x );
    position.setAttribute( "y", y );
    graphics.appendChild(position);
    node.appendChild(graphics);

    net.appendChild( node );
    sel_position = position;
    return node;
}



function addNode( ntype, x, y, subtype )
{
    var nm = ntype.substr(0,2) + "_" + node_nr;
    if( subtype != null ) nm = subtype.substr(0,2) + "_" + node_nr;

    var node = createNode( ntype, nm, x, y, 0, subtype );

    sel_node = node;
    node_type = ntype;
    redrawNet();

    if( isAsyncChannel( sel_node ) )
        document.getElementById("properties").src = "asyncchannel.html";
    else document.getElementById("properties").src = node_type + ".html";
    saveHistory();
}




function addArray( x, y )
{
    unselect();

    var sname = prompt( "Array Name", 'Table' );
    if( sname == null ) return;
    sname = validateName( sname );
    if( findNode( "signal", sname ) ||
        findNode( "array", sname ) ) {
        alert( "Duplicate array/signal name" );
        return;
    }
    var sparent = pnml.getElementsByTagName( "variable" )[0];
    if( sparent == null ) {
        sparent = pnml.createElement( "variable" );
        var input = pnml.getElementsByTagName( "input" )[0];
        if( input!=null ) input.parentNode.insertBefore( sparent, input );
        else return;
    }

    var new_array = pnml.createElement( "array" );
    new_array.setAttribute( "id", sname );
    new_array.setAttribute( "type", "range" );
    new_array.setAttribute( "min", "0" );
    new_array.setAttribute( "max", "1" );
    new_array.setAttribute( "index1", "-" );
    new_array.setAttribute( "index2", "-" );
    new_array.setAttribute( "constant", "true" );

    var graphics = pnml.createElement( "graphics" );
    var position = pnml.createElement( "position" );
    position.setAttribute( "page", "1" );
    position.setAttribute( "x", x );
    position.setAttribute( "y", y );
    graphics.appendChild(position);
    new_array.appendChild(graphics);

    var mathexp = pnml.createElement( "math-exp" );
    mathexp.textContent = "0";
    new_array.appendChild(mathexp);
    var data = pnml.createElement( "array-data" );
    new_array.appendChild(data);

    sparent.appendChild( new_array );

    sel_position = position;
    sel_node = new_array;
    node_type = "array";
    redrawNet();

    document.getElementById("properties").src = "array.html";

    saveHistory();
}



function updateArray( win )
{
    if( sel_node == null || node_type != "array" ) return;

    var i;
    var array_id = win.document.forms[0].array_id;
    var mode = win.document.forms[0].mode;
    var dim  = win.document.forms[0].dim;
    var type = win.document.forms[0].cell_type;
    var min  = win.document.forms[0].range_min;
    var max  = win.document.forms[0].range_max;
    var index1 = win.document.forms[0].index1;
    var index2 = win.document.forms[0].index2;
    var range1 = win.document.getElementById( "range1" );
    var range2 = win.document.getElementById( "range2" );
    var show_expr = win.document.getElementById( "show-expr" );

    array_id.value = sel_node.getAttribute( "id" );
    min.value = sel_node.getAttribute( "min" );
    max.value = sel_node.getAttribute( "max" );
    type.value = sel_node.getAttribute( "type" );
    if( sel_node.getAttribute( "constant" ) == "true" ) mode[0].checked = true;
    else mode[1].checked = true;

    var idx1_id = "-", idx2_id = "-";
    var sig_idx1 = findNode( "signal", sel_node.getAttribute( "index1" ) );
    var sig_idx2 = findNode( "signal", sel_node.getAttribute( "index2" ) );

    if( sig_idx1 != null ) {
        idx1_id = sig_idx1.getAttribute( "id" );
        range1.textContent = sig_idx1.getAttribute("min") + " to " + 
                             sig_idx1.getAttribute("max");
    }

    if( sig_idx2 == null ) dim[0].checked = true;
    else {
        dim[1].checked = true;
        var tr2 = win.document.getElementById( "index2" );
        tr2.style.visibility = "visible";
        tr2.style.display = "table-row";
        idx2_id = sig_idx2.getAttribute( "id" );
        range2.textContent = sig_idx2.getAttribute("min") + " to " + 
                             sig_idx2.getAttribute("max");
    }

    var signals = pnml.getElementsByTagName( "signal" );
    for( i = 0; i < signals.length; ++i ) {
        if( signals[i].parentNode.nodeName != "output" ||
            signals[i].getAttribute( "type" ) != 'range' ) continue;
        var id = signals[i].getAttribute('id');
        index1.options.add( new Option( id, id, id==idx1_id, id==idx1_id ) );
        index2.options.add( new Option( id, id, id==idx2_id, id==idx2_id ) );
    }

    var data = sel_node.getElementsByTagName( "array-data" )[0];
    if( data == null ) return;

    var row, cell;
    var items = data.getElementsByTagName( "item" );
    var table = win.document.getElementById( "array-data" );
    if( table == null ) return;

    var mathexp = sel_node.getElementsByTagName("math-exp")[0];

    if( show_expr != null && mathexp != null && mathexp.textContent > "" ) {
        if( sig_idx2 != null )
            show_expr.textContent = "f(x,y) = " + mathexp.textContent;
        else
            show_expr.textContent = "f(x) = " + mathexp.textContent;
    }

    for( i = 0; i < items.length; ++i ) {
        row = win.document.createElement( "tr" );
        cell = win.document.createElement( "td" );
        cell.setAttribute( "align", "center" );
        cell.textContent = items[i].getAttribute( "idx2" );
        row.appendChild( cell );
        cell = win.document.createElement( "td" );
        cell.setAttribute( "align", "center" );
        cell.textContent = items[i].getAttribute( "idx1" );
        row.appendChild( cell );
        cell = win.document.createElement( "td" );
        cell.setAttribute( "align", "right" );
        cell.setAttribute( "onClick", "changeValue( this, " + 
                                       items[i].getAttribute("idx1") + ", " +
                                       items[i].getAttribute("idx2") + ");" );
        cell.textContent = items[i].getAttribute( "value" );
        row.appendChild( cell );
        table.appendChild( row );
    }
}




function changeArrayValue( idx1, idx2, value )
{
    if( sel_node == null || node_type != "array" ) return null;

    var min = Number(sel_node.getAttribute( "min" ));
    var max = Number(sel_node.getAttribute( "max" ));
    if( value < min ) value = min;
    if( value > max ) value = max;

    var item = pnml.evaluate(
                "//net/variable/array[@id='" + sel_node.getAttribute("id") + "']/array-data/item[@idx1='" + idx1 + "' and @idx2='" + idx2 + "']",
                pnml, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null );
    if( item.singleNodeValue == null ) return null;
    item.singleNodeValue.setAttribute( "value", value );

    var mathexp = sel_node.getElementsByTagName("math-exp")[0];
    if( mathexp != null && mathexp.textContent > "" &&
        mathexp.textContent.indexOf("[changed]") < 0 )
        mathexp.textContent += " [changed]";

    return value;
}




function saveArray( win )
{
    if( sel_node == null || node_type != "array" ) return;

    var id = sel_node.getAttribute("id");

    var mode = win.document.forms[0].mode;
    var dim  = win.document.forms[0].dim;
    var type = win.document.forms[0].cell_type;
    var min  = win.document.forms[0].range_min;
    var max  = win.document.forms[0].range_max;
    var index1 = win.document.forms[0].index1;
    var index2 = win.document.forms[0].index2;

    var prev_index1 = sel_node.getAttribute( "index1" );
    var prev_index2 = sel_node.getAttribute( "index2" );

    if( signalUsedByTransitionOutputActions( id ) ) {
        if( mode[0].checked == false ) {
            alert( "Array used by transition output actions must be constant" );
            return;
        }
        if( signalDefinedByPlaceOutputActions( index1.value ) ||
            signalDefinedByPlaceOutputActions( index2.value ) ) {
            alert( "Array used in transition output actions cannot use indexes defined by place output actions" );
            return;
        }
    }

    sel_node.setAttribute( "constant", mode[0].checked ? "true" : "false" );

    sel_node.setAttribute( "type", type.value );
    if( type.value == 'boolean' ) {
        sel_node.setAttribute( "min", 0 );
        sel_node.setAttribute( "max", 1 );
    }
    else {
        sel_node.setAttribute( "min", Number(min.value) );
        sel_node.setAttribute( "max", Number(max.value) );
    }

    var sig_idx1 = findNode( "signal", index1.value );
    if( sig_idx1 != null ) sel_node.setAttribute( "index1", index1.value );
    else sel_node.setAttribute( "index1", "-" );

    var sig_idx2 = findNode( "signal", index2.value );
    if( dim[1].checked && sig_idx2 != null ) {
        if( sig_idx1 == sig_idx2 ) {
            alert( "Cannot use the same index twice !" );
            sig_idx2.value = "-";
        }
        sel_node.setAttribute( "index2", index2.value );
    }
    else sel_node.setAttribute( "index2", "-" );

    validateArrayData();

    // Update all expressions index refereces:
    if( index1.value != prev_index1 || index2.value != prev_index2 ) {
        var nodes = pnml.evaluate("//net//operand[@type='array-item' and @idRef='" + id + "']", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );

        for( var i = 0; i < nodes.snapshotLength; ++i ) {
            nodes.snapshotItem(i).setAttribute( "idx1", index1.value );
            if( sig_idx2 != null )
                 nodes.snapshotItem(i).setAttribute( "idx2", index2.value );
            else nodes.snapshotItem(i).removeAttribute( "idx2" );
        }
        updateAllExpressionsText();
    }

    saveHistory();
    redrawNet();
}



function updateArrayRange( win, option, idx )
{
    var range = win.document.getElementById( "range" + idx );
    if( range == null ) return;
    idx_sig = findNode( "signal", option.value );
    if( idx_sig == null ) range.textContent = "";
    else range.textContent = idx_sig.getAttribute("min") + " to " + 
                             idx_sig.getAttribute("max");
}



function changeArrayId()
{
    if( sel_node == null || node_type != "array" ) return;
    var oldname = sel_node.getAttribute( "id" );

    var sname = prompt( "New Array/Table Name", oldname );
    if( sname == null ) return;

    sname = validateName( sname );
    if( sname == oldname ) return;

    if( findNode( "*", sname ) ) {
        alert( "Duplicate identifier / name" );
        return;
    }

    sel_node.setAttribute( "id", sname );

    var nodes = pnml.evaluate("//net//*[@idRef='" + oldname + "']", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );

    for( var i = 0; i < nodes.snapshotLength; ++i ) {
        if( nodes.snapshotItem(i).nodeName != "event" ) 
            nodes.snapshotItem(i).setAttribute( "idRef", sname );
    }

    updateAllExpressionsText();

    saveHistory();
    redrawNet();
}


function fillArray( win )
{
    if( sel_node == null || node_type != "array" ) return;

    saveArray( win );

    var func = "f(x)";
    var dim  = win.document.forms[0].dim;
    if( dim[1].checked ) func = "f(x,y)"

    var expr = "0";
    var mathexp = sel_node.getElementsByTagName("math-exp")[0];
    if( mathexp == null ) expr = "";
    else expr = mathexp.textContent

    expr = prompt( "Please enter a math. expression for " + func, expr );
    if( expr == null ) return;

    var xi = 0, xf = 0, yi = 0, yf = 0;

    idx1_sig = findNode( "signal", sel_node.getAttribute( "index1") );
    if( idx1_sig == null ) return;
    idx2_sig = findNode( "signal", sel_node.getAttribute( "index2") );
    xi = idx1_sig.getAttribute( "min" );
    xf = idx1_sig.getAttribute( "max" );
    if( idx2_sig != null ) {
        yi = idx2_sig.getAttribute( "min" );
        yf = idx2_sig.getAttribute( "max" );
    }

    if( mathexp == null ) {
        mathexp = pnml.createElement( "math-exp" );
        sel_node.appendChild( mathexp );
    }
    mathexp.textContent = expr;

    var data = sel_node.getElementsByTagName( "array-data" )[0];
    if( data == null ) {
        data = pnml.createElement( "array-data" );
        sel_node.appendChild(data);
    }

    var items = data.childNodes;
    for( i=items.length-1; i >= 0; i-- ) data.removeChild( items[i] );

    var item,res,x,y;
    var min = Number(sel_node.getAttribute( "min" ));
    var max = Number(sel_node.getAttribute( "max" ));
    for( y = yi; y <= yf; ++y ) {
        for( x = xi; x <= xf; ++x ) {
            res = Math.round(eval( "x=" + x + "; y=" + y + "; " + expr ));
            if( res < min ) res = min;
            if( res > max ) res = max;
            item = pnml.createElement( "item" );
            item.setAttribute( "idx1", x );
            item.setAttribute( "idx2", y );
            item.setAttribute( "value", res );
            data.appendChild( item );
        }
    }

    document.getElementById("properties").src = "array.html";
}



function validateArrayData()
{
    if( sel_node == null || node_type != "array" ) return;

    var expr = "0";
    var mathexp = sel_node.getElementsByTagName("math-exp")[0];
    if( mathexp == null ) expr = "0";
    else expr = mathexp.textContent

    var xi = 0, xf = 0, yi = 0, yf = 0;

    idx1_sig = findNode( "signal", sel_node.getAttribute( "index1") );
    if( idx1_sig == null ) return;
    idx2_sig = findNode( "signal", sel_node.getAttribute( "index2") );
    xi = Number(idx1_sig.getAttribute( "min" ));
    xf = Number(idx1_sig.getAttribute( "max" ));
    if( idx2_sig != null ) {
        yi = Number(idx2_sig.getAttribute( "min" ));
        yf = Number(idx2_sig.getAttribute( "max" ));
    }

    if( mathexp == null ) {
        mathexp = pnml.createElement( "math-exp" );
        sel_node.appendChild( mathexp );
        mathexp.textContent = expr;
    }

    var data = sel_node.getElementsByTagName( "array-data" )[0];
    if( data == null ) {
        data = pnml.createElement( "array-data" );
        sel_node.appendChild(data);
    }

    var i, x, y;
    var min = Number(sel_node.getAttribute( "min" ));
    var max = Number(sel_node.getAttribute( "max" ));

    var found = new Array();
    for( x = xi; x <= xf; ++x ) found[x] = new Array();

    // Update/remove unused old nodes
    var items = data.getElementsByTagName("item");
    for( i=items.length-1; i >= 0; i-- ) {
        x = Number(items[i].getAttribute( "idx1" ));
        y = Number(items[i].getAttribute( "idx2" ));
        if( x < xi || x > xf || y < yi || y > yf ) {
            data.removeChild( items[i] );
            continue;
        }
        var val = Number(items[i].getAttribute("value" ));
        if( val < min ) items[i].setAttribute( "value", min );
        else if( val > max ) items[i].setAttribute( "value", max );
        found[x][y] = 1;
    }

    // Insert new nodes
    for( y = yi; y <= yf; ++y ) {
        for( x = xi; x <= xf; ++x ) {
            if( found[x][y] == 1 ) continue;
            var res = Math.round(eval( "x=" + x + "; y=" + y + "; " + expr ));
            if( res < min ) res = min;
            else if( res > max ) res = max;
            var item = pnml.createElement( "item" );
            item.setAttribute( "idx1", x );
            item.setAttribute( "idx2", y );
            item.setAttribute( "value", res );
            data.appendChild( item );
        }
    }

    document.getElementById("properties").src = "array.html";
}


function importArray( content )
{
    if( sel_node == null || node_type != "array" ) return;

    var lines = content.value.split( "\n" );
    if( lines.length < 1 ) return;

    var xi = 0, xf = 0, yi = 0, yf = 0;
    idx1_sig = findNode( "signal", sel_node.getAttribute( "index1") );
    if( idx1_sig == null ) return;
    idx2_sig = findNode( "signal", sel_node.getAttribute( "index2") );
    xi = idx1_sig.getAttribute( "min" );
    xf = idx1_sig.getAttribute( "max" );
    if( idx2_sig != null ) {
        yi = idx1_sig.getAttribute( "min" );
        yf = idx1_sig.getAttribute( "max" );
    }

    var data = sel_node.getElementsByTagName( "array-data" )[0];
    if( data == null ) {
        data = pnml.createElement( "array-data" );
        sel_node.appendChild(data);
    }

    var i, x, y;
    var min = Number(sel_node.getAttribute( "min" ));
    var max = Number(sel_node.getAttribute( "max" ));

    var items = data.childNodes;
    for( i = items.length-1; i >= 0; i-- ) data.removeChild( items[i] );

    for( i = 0; i < lines.length; ++i ) {
        if( items[i][j] == '#' ) continue;
        items = lines[i].split( /[ ,;:\t]/g );
        if( items.length < 2 ) continue;
        x = Number(items[0]);
        if( x < xi || x > xf ) continue;
        if( idx2_sig != null ) {
            if( items.length < 3 ) continue;
            y = Number(items[1]);
            if( y < yi || y > yf ) continue;
            value = Number( items[2] );
        }
        else {
            y = 0;
            if( items.length == 3 ) value = Number( items[2] );
            else value = Number( items[1] );
        }

        if( value < min ) value = min;
        if( value > max ) value = max;

        item = pnml.createElement( "item" );
        item.setAttribute( "idx1", Math.round(x) );
        item.setAttribute( "idx2", Math.round(y) );
        item.setAttribute( "value", Math.round(value) );
        data.appendChild( item );
    }

    var mathexp = sel_node.getElementsByTagName("math-exp")[0];
    if( mathexp != null ) mathexp.textContent = "";

    document.getElementById("properties").src = "array.html";
}




function exportArray()
{
    if( sel_node == null || node_type != "array" ) return;
    var data = sel_node.getElementsByTagName( "array-data" )[0];
    if( data == null ) return;

    var sig_idx1 = findNode( "signal", sel_node.getAttribute( "index1" ) );
    if( sig_idx1 == null ) return;
    var sig_idx2 = findNode( "signal", sel_node.getAttribute( "index2" ) );

    var text = "#Array " + sel_node.getAttribute("id") + "\r\n";
    if( sig_idx2 != null ) text += "#X, Y, Value\r\n";
    else text += "#X, Value\n";

    var items = data.getElementsByTagName( "item" );
    for( var i = 0; i < items.length; ++i ) {
        text += items[i].getAttribute( "idx1" ) + ", ";
        if( sig_idx2 != null ) 
            text += items[i].getAttribute( "idx2" ) + ", ";
        text += items[i].getAttribute( "value" ) + "\r\n";
    }

    window.open( "data:text/csv;charset=utf-8," + encodeURIComponent(text),
                 "array_" + sel_node.getAttribute("id") + ".csv" );
}



function complementPlace()
{
    var node;
    if( multiple_sel.length > 1 ) return;
    if( multiple_sel.length == 1 ) node = multiple_sel[0];
    else node = sel_node;
    if( node == null || node.nodeName != "place" ) return;
    if( isAsyncChannel( node ) || nodeHasChannels( node.getAttribute("id") ) )
        return;

    unselect();

    var comp_node = node.cloneNode(true);
    var pname = comp_node.getElementsByTagName( "name" )[0];
    var text = pname.getElementsByTagName( "text" )[0];
    text.textContent = text.textContent + "_comp";

    var init_marking = comp_node.getElementsByTagName( "initialMarking" )[0];
    if( init_marking != null ) {
        text = init_marking.getElementsByTagName( "text" )[0];
        if( Number(text.textContent) > 0 ) text.textContent = "0";
        else text.textContent= "1";
    }

    var pos = comp_node.getElementsByTagName( "position" )[0];
    pos.setAttribute( "x", Number(pos.getAttribute("x")) + 25 );
    pos.setAttribute( "y", Number(pos.getAttribute("y")) + 25 );
    var node_id = node.getAttribute( "id" );
    var comp_node_id = node_nr++;
    comp_node.setAttribute( "id", comp_node_id );
    node.parentNode.appendChild( comp_node );

    var arcs = pnml.getElementsByTagName( "arc" );
    for( var i = 0; i < arcs.length; ++i ) {
        var arc_type = arcs[i].getElementsByTagName( "type" )[0];
        if( arc_type.textContent == "test" ) continue;
        if( arcs[i].getAttribute("target") == node_id ) {
            var new_arc = arcs[i].cloneNode(true);
            new_arc.setAttribute( "target", new_arc.getAttribute( "source" ) );
            new_arc.setAttribute( "source", comp_node_id );
            new_arc.setAttribute( "id", node_nr++ );
            arcs[i].parentNode.appendChild( new_arc );
        }
        else if( arcs[i].getAttribute("source") == node_id ) {
            var new_arc = arcs[i].cloneNode(true);
            new_arc.setAttribute( "source", new_arc.getAttribute( "target" ) );
            new_arc.setAttribute( "target", comp_node_id );
            new_arc.setAttribute( "id", node_nr++ );
            arcs[i].parentNode.appendChild( new_arc );
        }
    }

    var actions = comp_node.getElementsByTagName( "signalOutputAction" );
    for( var i = actions.length-1; i >= 0; --i ) {
         actions[i].parentNode.removeChild( actions[i] );
    }

    sel_node = comp_node;
    sel_position = pos;
    node_type = "place";
    redrawNet();
    saveHistory();
    document.getElementById("properties").src = "place.html";
}




function addInscriptions( arc1, arc2 )
{
    var v1 = 1, v2 = 1;
    var inscription = arc2.getElementsByTagName( "inscription" )[0];
    if( inscription != null ) {
        var value = inscription.getElementsByTagName("value")[0];
        if( value == null )
            value = inscription.getElementsByTagName("text")[0];
        if( value != null )
            v2 = Number(inscription.textContent);
    }
    inscription = arc1.getElementsByTagName( "inscription" )[0];
    if( inscription != null ) {
        var value = inscription.getElementsByTagName("value")[0];
        if( value == null )
            value = inscription.getElementsByTagName("text")[0];
        if( value != null ) {
            v1 = Number(inscription.textContent);
            value.textContent = (v1 + v2);
        }
    }
}



function nodeFusion()
{
    if( multiple_sel.length != 2 ) return;
    if( multiple_sel[0].nodeName != multiple_sel[1].nodeName ) return;
    if( multiple_sel[0].nodeName != "place" &&
        multiple_sel[0].nodeName != "transition" ) return;

    if( isAsyncChannel(multiple_sel[0]) ||
        isAsyncChannel(multiple_sel[1]) ) return;

    var id0 = multiple_sel[0].getAttribute( "id" );
    var id1 = multiple_sel[1].getAttribute( "id" );

    if( nodeHasChannels( id0 ) || nodeHasChannels( id1 ) ) return;

    var arcs = pnml.getElementsByTagName( "arc" );
    for( var i = arcs.length-1; i >= 0; --i ) {
        var target_id = arcs[i].getAttribute( "target" );
        var source_id = arcs[i].getAttribute( "source" );
        if( target_id == id1 ) {
            var existing = findArc( source_id, id0 );
            if( existing == null )
                arcs[i].setAttribute( "target", id0 );
            else {
                addInscriptions( existing, arcs[i] );
                arcs[i].parentNode.removeChild( arcs[i] );
            }
        }
        if( source_id == id1 ) {
            var existing = findArc( id0, target_id );
            if( existing == null )
                arcs[i].setAttribute( "source", id0 );
            else {
                addInscriptions( existing, arcs[i] );
                arcs[i].parentNode.removeChild( arcs[i] );
            }
        }
    }

    multiple_sel[1].parentNode.removeChild( multiple_sel[1] );
    multiple_sel.pop();
    multiple_sel_pos.pop();
    saveHistory();
    redrawNet();
    statusbar.value = "Node fusion: " + multiple_sel[0].nodeName;
}



function createInvariantSectionLock( semaphore )
{
    var i;
    var nodes = multiple_sel;
    if( nodes.length < 1 && sel_node != null ) {
        nodes.push( sel_node );
        multiple_sel_pos.push( sel_position );
    }

    var max_init_marking = 0;
    var places = [];
    for( i = 0; i < nodes.length; ++i ) {
        if( nodes[i].nodeName == "place" ) {
            places.push( nodes[i] );
            var im = nodes[i].getElementsByTagName( "initialMarking" )[0];
            if( im == null ) continue;
            var text = im.getElementsByTagName( "text" )[0];
            if( text == null ) continue;
            var imv = Number(text.textContent);
            if( imv > max_init_marking ) max_init_marking = imv;
        }
    }
    if( places.length < 1 ) return;

    var place_ids = [];
    for( i = 0; i < places.length; ++i ) {
        place_ids[i] = places[i].getAttribute( "id" );
        if( isAsyncChannel( places[i] ) || nodeHasChannels( place_ids[i] ) ) {
            alert( "Operation does not support channels !" );
            return;
        }
    }

    var bbox = boundingBox( multiple_sel_pos );
    unselect();

    var idx;
    var trans = [];
    var count = [];
    var arcs = pnml.getElementsByTagName("arc");
    for( i = 0; i < arcs.length; ++i ) {
        var type = arcs[i].getElementsByTagName("type")[0];
        if( type.textContent != "normal" ) continue;
        var inscr = arcs[i].getElementsByTagName( "value" )[0];
        if( inscr == null ) continue;

        var source_id = arcs[i].getAttribute("source");
        var target_id = arcs[i].getAttribute("target");
        if( place_ids.indexOf( source_id ) >= 0 ) {
            idx = trans.indexOf( target_id );
            if( idx <  0 ) {
                trans.push( target_id );
                count.push( 0 );
                idx = trans.length-1;
            }
            count[idx] += Number(inscr.textContent);
        }
        if( place_ids.indexOf( target_id ) >= 0 ) {
            idx = trans.indexOf( source_id );
            if( idx <  0 ) {
                trans.push( source_id );
                count.push( 0 );
                idx = trans.length-1;
            }
            count[idx] -= Number(inscr.textContent);
        }
    }

    if( semaphore ) {
        // Filer only the entry/exit transtions with arcs to external places:
        var valid_trans = [];
        var inv_arc_count = [];
        for( i = 0; i < trans.length; ++i ) {
            valid_trans[i] = false;
            inv_arc_count[i] = 0;
        }

        for( i = 0; i < arcs.length; ++i ) {
            var type = arcs[i].getElementsByTagName("type")[0];
            if( type.textContent != "normal" ) continue;

            var source_id = arcs[i].getAttribute("source");
            var target_id = arcs[i].getAttribute("target");
            var sidx = trans.indexOf( source_id );
            var tidx = trans.indexOf( target_id );
            if( tidx >= 0 && count[tidx] < 0 ) {
                ++inv_arc_count[i];
                if( place_ids.indexOf(source_id)<0 ) valid_trans[tidx] = true;
            }
            if( sidx >= 0 && count[sidx] > 0 ) {
                ++inv_arc_count[i];
                if( place_ids.indexOf(target_id)<0 ) valid_trans[sidx] = true;
            }
        }

        for( i = 0; i < trans.length; ++i ) {
            if( valid_trans[i]==false && inv_arc_count[i] > 0 ) count[i] = 0;
        }
    }

    var in_arcs = 0;
    var out_arcs = 0;
    for( i = 0; i < count.length; ++i ) {
        if( count[i] > 0 ) ++in_arcs;
        if( count[i] < 0 ) ++out_arcs;
    }
    if( in_arcs < 1 ) {
        if( semaphore ) alert( "Critical Section has no exit arcs !" );
        else alert( "Invariant Lock has no 'in' arcs !" );
        return;
    }
    if( out_arcs < 1 ) {
        if( semaphore ) alert( "Critical Section has no entry arcs !" );
        else alert( "Invariant Lock has no 'out' arcs !" );
        return;
    }

    var place_name = "inv_lock";
    if( semaphore ) place_name = "semaphore";

    var rep = 0;
    while( findNodeByName( "place", place_name + rep ) ) ++rep;

    var x, y;
    if( places.length == 1 ) {
        x = bbox[1] + 20;
        y = bbox[3] + 20;
    }
    else {
        x = (bbox[0] + bbox[1])/2;
        y = (bbox[2] + bbox[3])/2;
    }

    var lock_place = createNode( "place", place_name + rep, x, y,
                                 (max_init_marking > 0) ? 0 : 1 );
    var lock_id = lock_place.getAttribute( "id" );

    for( i = 0; i < trans.length; ++i ) {
        if( count[i] < 0 ) createArc( lock_id, trans[i], -count[i] );
        else if( count[i] > 0 ) createArc( trans[i], lock_id, count[i] );
    }

    sel_node = lock_place;
    redrawNet();
    saveHistory();
}



function validateName( n )
{
    if( n == null || n == "" ) return n;

    var c = n.charAt( 0 );
    if( !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c=="_" ) ) n = "_"+n;
    for( i = 1; i < n.length; ++i ) {
        c = n.charAt( i );
        if( !( c == '_' || c >= '0' && c <= '9' || 
               c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z') )
               n = n.substr( 0, i ) + "_" + n.substr( i+1 );
    }
    return n;
}



function addSignal( mode, x, y )
{
    unselect();

    var sname = prompt( "Signal Name",
                        mode.charAt(0).toUpperCase() + mode.charAt(1) + 'S' );
    if( sname == null ) return;
    sname = validateName( sname );
    if( findNode( "signal", sname ) ||
        findNode( "array", sname ) ) {
        alert( "Duplicate signal/array name" );
        return;
    }
    var sparent = pnml.getElementsByTagName( mode )[0];
    var new_signal = pnml.createElement( "signal" );
    new_signal.setAttribute( "id", sname );
    new_signal.setAttribute( "type", "boolean" );
    new_signal.setAttribute( "value", "0" );
    new_signal.setAttribute( "gpio_nr", "0" );

    var graphics = pnml.createElement( "graphics" );
    var position = pnml.createElement( "position" );
    position.setAttribute( "page", "1" );
    position.setAttribute( "x", x );
    position.setAttribute( "y", y );
    graphics.appendChild(position);
    new_signal.appendChild(graphics);

    sparent.appendChild( new_signal );

    sel_position = position;
    sel_node = new_signal;
    node_type = "signal";
    redrawNet();

    document.getElementById("properties").src = "signal.html";

    saveHistory();
}



function updateAllExpressionsText()
{
    var nodes = pnml.evaluate("//net//concreteSyntax[@language='iopt']", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );
    for( var i = 0; i < nodes.snapshotLength; ++i ) {
        var text = nodes.snapshotItem(i).getElementsByTagName("text")[0];
        var expr = nodes.snapshotItem(i).getElementsByTagName("expression")[0];
        if( text && expr ) text.textContent = exprToString( expr );
    }
}



function changeSignalId()
{
    if( sel_node == null || node_type != "signal" ) return;
    var oldname = sel_node.getAttribute( "id" );
    var stype = sel_node.parentNode.nodeName;

    var sname = prompt( "New Signal Name", oldname );
    if( sname == null ) return;

    sname = validateName( sname );
    if( sname == oldname ) return;

    if( findNode( "*", sname ) ) {
        alert( "Duplicate identifier / name" );
        return;
    }

    sel_node.setAttribute( "id", sname );

    var nodes = pnml.evaluate("//net//*[@idRef='" + oldname + "']", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );

    for( var i = 0; i < nodes.snapshotLength; ++i ) {
        if( nodes.snapshotItem(i).nodeName != "event" ) 
            nodes.snapshotItem(i).setAttribute( "idRef", sname );
    }

    var nodes = pnml.evaluate("//net/" + stype + "/event[@signal='" + oldname + "']", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );

    for( var i = 0; i < nodes.snapshotLength; ++i ) {
        nodes.snapshotItem(i).setAttribute( "signal", sname );
    }

    updateAllExpressionsText();

    saveHistory();
    redrawNet();
}


function changeEventId()
{
    if( sel_node == null || node_type != "event" ) return;
    var oldname = sel_node.getAttribute( "id" );

    var newname = prompt( "New Event Name", oldname );
    if( newname == null ) return;

    newname = validateName( newname );
    if( newname == oldname ) return;

    if( findNode( "*", newname ) ) {
        alert( "Duplicate identifier / name" );
        return;
    }

    sel_node.setAttribute( "id", newname );

    var nodes = pnml.evaluate("//net/transition//event[@idRef='" + oldname + "']", pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );

    for( var i = 0; i < nodes.snapshotLength; ++i ) {
        nodes.snapshotItem(i).setAttribute( "idRef", newname );
    }

    saveHistory();
    redrawNet();
}




function addEvent( mode, x, y )
{
    unselect();

    var ename = prompt( "Event Name", mode.charAt(0).toUpperCase() + 'E' );
    if( ename == null ) return;
    ename = validateName( ename );
    if( findNode( "event", ename ) ) {
        alert( "Duplicate event name" );
        return;
    }

    // Find a signal 
    var sig = null;
    var signals = pnml.getElementsByTagName( "signal" );
    for( var i = 0; i < signals.length; ++i ) {
        if( signals[i].parentNode.nodeName != mode ) continue;
        var id = signals[i].getAttribute( "id" );
        if( mode != "output" || !signalDefinedByPlaceOutputActions( id ) ) {
           sig = id;
           break;
        }
    }

    if( sig == null ) {
        alert( "There are no " + mode + " signals defined " +
               (mode == "output" ? "and not used by places !" : " !") );
        return;
    }

    var eparent = pnml.getElementsByTagName( mode )[0];
    var new_event = pnml.createElement( "event" );
    new_event.setAttribute( "id", ename );
    new_event.setAttribute( "edge", "up" );
    new_event.setAttribute( "level", "0" );
    new_event.setAttribute( "signal", sig );
    var graphics = pnml.createElement( "graphics" );
    var position = pnml.createElement( "position" );
    position.setAttribute( "page", "1" );
    position.setAttribute( "x", x );
    position.setAttribute( "y", y );
    graphics.appendChild(position);
    new_event.appendChild(graphics);

    eparent.appendChild( new_event );

    sel_position = position;
    sel_node = new_event;
    node_type = "event";
    redrawNet();

    document.getElementById("properties").src = "event.html";

    saveHistory();
}



function updatePlaceOutputActions( win, place_node )
{
    var i, j;
    all_outputs = [];
    all_output_names = [];
    var signals = pnml.getElementsByTagName( "signal" );
    for( i = 0; i < signals.length; ++i ) {
        var id = signals[i].getAttribute( "id" );
        if( signals[i].parentNode.nodeName == "output" &&
            !signalUsedByEvents( id ) && 
            !signalDefinedByTransitionOutputActions( id ) &&
            !signalUsedByTransitionOutputActions( id ) ) {
            all_outputs.push( id );
            all_output_names.push( id );
        }
    }

    // Add array names to list of valid outputs
    var array_nodes =
        pnml.evaluate( "//net/variable/array[@constant='false']", pnml, null,
                       XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );
    for( var i = 0; i < array_nodes.snapshotLength; ++i ) {
        var id = array_nodes.snapshotItem(i).getAttribute( "id" );
        var idx1 = array_nodes.snapshotItem(i).getAttribute( "index1" );
        var idx2 = array_nodes.snapshotItem(i).getAttribute( "index2" );
        if( findNode( "signal", idx1 ) == null ) continue;
        if( findNode( "signal", idx2 ) == null ) idx2 = null;
        if( signalUsedByTransitionOutputActions( id ) ) continue;
        var array_name = id + "[" + idx1 + "]";
        if( idx2 != null ) array_name += "[" + idx2 + "]";

        all_outputs.push( id );
        all_output_names.push( array_name );
    }

    var actions = place_node.getElementsByTagName( "signalOutputAction" );

    for( j = 0; j < MAX_PL_OUT; ++j ) {
        var row = win.document.getElementById( "output" + (j+1) );

        var sel = row.getElementsByTagName( "select" )[0];
        sel.options.add( new Option( ' ', ' ' ) );
        for( i = 0; i < all_outputs.length; ++i ) {
            sel.options.add( new Option( all_output_names[i], all_outputs[i] ));
        }

        var inputs = row.getElementsByTagName( "input" );
        var value = inputs[0];
        var condition = inputs[1];

        if( j < actions.length ) {
            row.style.visibility = "visible";
            row.style.display = "table-row";
            sel.value = actions[j].getAttribute("idRef");

            var val = actions[j].getElementsByTagName( "value" )[0];
            if( val != null )
                value.value = val.getElementsByTagName("text")[0].textContent;
            else value.value = "";
            value.title = value.value;

            var cond = actions[j].getElementsByTagName( "condition" )[0];
            if( cond != null )
                condition.value = 
                    cond.getElementsByTagName("text")[0].textContent;
            else condition.value = "";
            condition.title = condition.value;
        }
        else {
            if( j == actions.length ) {
               row.style.visibility = "visible";
               row.style.display = "table-row";
            }
            else {
               row.style.visibility = "collapse";
               row.style.display = "none";
            }
            sel.value = "";
            value.value = "";
            condition.value = "";
        }
    }
}


function updatePlace( win )
{
    if( sel_node == null || node_type != "place" ) return;

    win.document.forms[0].place_id.value = sel_node.getAttribute('id');
    var pname = sel_node.getElementsByTagName( "name" )[0];
    var text = pname.getElementsByTagName( "text" )[0];
    win.document.forms[0].place_name.value = text.textContent;
    var init_marking = sel_node.getElementsByTagName( "initialMarking" )[0];
    text = init_marking.getElementsByTagName( "text" )[0];
    win.document.forms[0].initial_marking.value = text.textContent;

    var comment = sel_node.getElementsByTagName( "comment" )[0];
    if( comment != null ) {
        text = comment.getElementsByTagName( "text" )[0];
        if( text != null && text.textContent != null )
            win.document.forms[0].comment.value = text.textContent;
        else win.document.forms[0].comment.value = "";
    }
    else win.document.forms[0].comment.value = "";

    var bound = sel_node.getElementsByTagName( "bound" )[0];
    if( bound == null ) win.document.forms[0].bound.value = "";
    else {
        text = bound.getElementsByTagName( "text" )[0];
        if( text != null )
            win.document.forms[0].bound.value = text.textContent;
        else win.document.forms[0].bound.value = bound.textContent;
    }

    var timedomain = sel_node.getElementsByTagName( "timedomain" )[0];
    if( timedomain != null ) {
        text = timedomain.getElementsByTagName( "text" )[0];
        win.document.forms[0].timedomain.value = text.textContent;
    }
    else win.document.forms[0].timedomain.value = "";

    updatePlaceOutputActions( win, sel_node );
}


function updateAsyncChannel( win )
{
    if( sel_node == null || node_type != "place" ||
        !isAsyncChannel( sel_node ) ) return;

    win.document.forms[0].place_id.value = sel_node.getAttribute('id');
    var pname = sel_node.getElementsByTagName( "name" )[0];
    var text = pname.getElementsByTagName( "text" )[0];
    win.document.forms[0].place_name.value = text.textContent;

    var ac_type = sel_node.getElementsByTagName( "actype" )[0];
    win.document.forms[0].ac_type.value = ac_type.textContent;

    var comment = sel_node.getElementsByTagName( "comment" )[0];
    if( comment != null ) {
        text = comment.getElementsByTagName( "text" )[0];
        if( text != null && text.textContent != null )
            win.document.forms[0].comment.value = text.textContent;
        else win.document.forms[0].comment.value = "";
    }
    else win.document.forms[0].comment.value = "";
}

function addComment( node )
{
    var comment = pnml.createElement( "comment" );
    var text = pnml.createElement( "text" );
    text.appendChild( pnml.createTextNode( "" ) );
    comment.appendChild( text );
    var graphics = pnml.createElement( "graphics" );
    var offset = pnml.createElement( "offset" );
    offset.setAttribute( "x", "-30" );
    offset.setAttribute( "y", "20" );
    graphics.appendChild(offset);
    comment.appendChild(graphics);
    node.appendChild( comment );
    return comment;
}



function validateRange( signal, value )
{
    var min, max;
    var sig = findNode( "signal", signal );
    if( sig == null ) return value;
    if( sig.getAttribute( "type" ) == 'boolean' ) {
        min = 0;
        max = 1;
    }
    else {
        min = Number(sig.getAttribute( "min" ));
        max = Number(sig.getAttribute( "max" ));
    }
    if( value < min ) return min;
    if( value > max ) return max;
    return value;
}
 


function addSignalOutputAction( node )
{
    var soa;
    var soa_list = node.getElementsByTagName( "signalOutputActions" );
    if( soa_list.length < 1 ) {
        soa = pnml.createElement( "signalOutputActions" );
        node.appendChild( soa );
    }
    else soa = soa_list[0];

    var oa = pnml.createElement( "signalOutputAction" );

    var value = pnml.createElement( "value" );

    var cs = pnml.createElement( "concreteSyntax" );
    cs.setAttribute( "language", "iopt" );
    cs.appendChild( pnml.createElement( "text" ) );
    value.appendChild( cs );
    oa.appendChild( value );

    if( node.nodeName == "place" ) {
        var cond  = pnml.createElement( "condition" );
        cs = pnml.createElement( "concreteSyntax" );
        cs.setAttribute( "language", "iopt" );
        cs.appendChild( pnml.createElement( "text" ) );
        cond.appendChild( cs );
        oa.appendChild( cond );
    }

    soa.appendChild( oa );

    return oa;
}



function savePlaceOutputActions( win, place )
{
    var i, j;

    var actions = place.getElementsByTagName( "signalOutputAction" );
    var rem = [];

    for( j = 0; j < MAX_PL_OUT; ++j ) {
        var row = win.document.getElementById( "output" + (j+1) );
        var sel = row.getElementsByTagName( "select" )[0];
        var signal = sel.value;
        if( sel.selectedIndex >= 0 && signal > ' ' ) {
            var name = sel.options[sel.selectedIndex].text;
            var is_array = false;
            var inputs = row.getElementsByTagName( "input" );
            var value = inputs[0].value;
            var condition = inputs[1].value;
            if( name.indexOf( "[" ) > 0 && findNode( "array", signal ) ) 
                is_array = true;
            oa = actions[j];
            if( oa == null ) oa = addSignalOutputAction( place );
            oa.setAttribute( "idRef", signal );
            if( is_array ) oa.setAttribute( "array", "true" );
            var val = oa.getElementsByTagName( "value" )[0];
            val.getElementsByTagName("text")[0].textContent = value;
            var cond = oa.getElementsByTagName( "condition" )[0];
            cond.getElementsByTagName("text")[0].textContent = condition;
        }
        else if( j < actions.length ) rem.push( j );
    }

    // Remove unnused actions
    for( i = rem.length-1; i >= 0; --i ) {
        actions[i].parentNode.removeChild( actions[rem[i]] );
    }
}



function savePlace( win )
{
    var id = win.document.forms[0].place_id.value;
    sel_node = findNode( "place", id );
    if( sel_node == null || node_type != "place" ) return;

    var pname = sel_node.getElementsByTagName( "name" )[0];
    var text = pname.getElementsByTagName( "text" )[0];
    if( text.textcontent != win.document.forms[0].place_name.value ) {
        text.textContent = win.document.forms[0].place_name.value;
        updateAllExpressionsText();
    }

    var init_marking = sel_node.getElementsByTagName( "initialMarking" )[0];
    text = init_marking.getElementsByTagName( "text" )[0];
    text.textContent = Number(win.document.forms[0].initial_marking.value);

    var comment = sel_node.getElementsByTagName( "comment" )[0];
    if( comment == null ) comment = addComment( sel_node );
    text = comment.getElementsByTagName( "text" )[0];
    text.textContent = win.document.forms[0].comment.value;
   
    var newTextValue = Number(win.document.forms[0].timedomain.value);
    if (newTextValue == 0) newTextValue = -1;
    saveNodeWithText( sel_node, "timedomain", newTextValue, 20, 0 );
 
    var bound = sel_node.getElementsByTagName( "bound" )[0];
    if( bound != null ) {
        text = bound.getElementsByTagName( "text" )[0];
        if( text != null )
            text.textContent = Number(win.document.forms[0].bound.value);
        else
            bound.textContent = Number(win.document.forms[0].bound.value);
    }

    savePlaceOutputActions( win, sel_node );

    redrawNet();
    saveHistory();
}

function saveAsyncChannel( win )
{
    var id = win.document.forms[0].place_id.value;
    sel_node = findNode( "place", id );
    if( sel_node == null || node_type != "place" ||
        !isAsyncChannel(sel_node) ) return;

    var pname = sel_node.getElementsByTagName( "name" )[0];
    var text = pname.getElementsByTagName( "text" )[0];
    text.textContent = win.document.forms[0].place_name.value;

    var place_type = sel_node.getElementsByTagName( "placetype" )[0];
    place_type.textContent = "asyncchannel";

    var type_val = win.document.forms[0].ac_type.value;
    var ac_type = sel_node.getElementsByTagName( "actype" )[0];
    ac_type.textContent = type_val;

    var comment = sel_node.getElementsByTagName( "comment" )[0];
    if( comment == null ) comment = addComment( sel_node );
    text = comment.getElementsByTagName( "text" )[0];
    text.textContent = win.document.forms[0].comment.value;

    redrawNet();
    saveHistory();
}


function saveNodeWithText( node, nodeLabel, newTextValue, x, y)
{
    var changedNode = node.getElementsByTagName( nodeLabel )[0];
    if (newTextValue == -1) {
        if (changedNode != null) {
                var text = changedNode.getElementsByTagName( "text" )[0];
            text.parentNode.removeChild( text );
            var offset = changedNode.getElementsByTagName( "offset" )[0];
            offset.parentNode.removeChild( offset );
            var graphics = changedNode.getElementsByTagName( "graphics" )[0];
            graphics.parentNode.removeChild( graphics );
            changedNode.parentNode.removeChild( changedNode );
        }
    }
    else {
        if (changedNode != null) {
                var text = changedNode.getElementsByTagName( "text" )[0];
                text.textContent = newTextValue;
        }
        else {
            changedNode = pnml.createElement( nodeLabel );
            var text = pnml.createElement( "text" );
            text.appendChild( pnml.createTextNode( newTextValue ) );
            changedNode.appendChild( text );
            var graphics = pnml.createElement( "graphics" );
            var offset = pnml.createElement( "offset" );
            offset.setAttribute( "x", x );
            offset.setAttribute( "y", y );
            graphics.appendChild(offset);
            changedNode.appendChild(graphics);
            node.appendChild( changedNode );
        }
    }
}

function saveSimpleNode( nodeLabel, newValue )
{
    var changedNode = sel_node.getElementsByTagName( nodeLabel )[0];
    if (newValue == -1) {
        if (changedNode != null) 
            changedNode.parentNode.removeChild( changedNode );
    }
    else {
        if (changedNode != null) 
                changedNode.textContent = newValue;
        else {
            changedNode = pnml.createElement( nodeLabel );
            changedNode.appendChild( pnml.createTextNode( newValue ) );
            sel_node.appendChild( changedNode );
        }
    }
}

function updateTransitionActions( win, tr_node )
{
    var i, j;
    all_outputs = [];
    var signals = pnml.getElementsByTagName( "signal" );
    for( i = 0; i < signals.length; ++i ) {
        var id = signals[i].getAttribute( "id" );
        if( signals[i].parentNode.nodeName == "output" &&
            !signalUsedByEvents( id ) &&
            !signalDefinedByPlaceOutputActions( id ) )
            all_outputs.push( id );
    }

    var actions = tr_node.getElementsByTagName( "signalOutputAction" );

    for( j = 0; j < MAX_TR_OUT; ++j ) {
        var row = win.document.getElementById( "output" + (j+1) );

        var sel = row.getElementsByTagName( "select" )[0];
        sel.options.add( new Option( ' ', ' ' ) );
        for( i = 0; i < all_outputs.length; ++i ) {
            sel.options.add( new Option( all_outputs[i], all_outputs[i] ) );
        }

        var inputs = row.getElementsByTagName( "input" );
        var value = inputs[0];

        if( j < actions.length ) {
            row.style.visibility = "visible";
            row.style.display = "table-row";
            sel.value = actions[j].getAttribute("idRef");

            var val = actions[j].getElementsByTagName( "value" )[0];
            if( val != null )
                value.value = val.getElementsByTagName("text")[0].textContent;
            else value.value = "";
            value.title = value.value;
        }
        else {
            if( j == actions.length ) {
                row.style.visibility = "visible";
                row.style.display = "table-row";
            }
            else {
                row.style.visibility = "collapse";
                row.style.display = "none";
            }
            sel.value = "";
            value.value = "";
        }
    }
}

function updateTransition( win )
{
    if( sel_node == null || node_type != "transition" ) return;

    var i, j, sel;
    var all_events = pnml.getElementsByTagName( "event" );
    var tinEvents = sel_node.getElementsByTagName( "inputEvents" )[0];
    var toutEvents = sel_node.getElementsByTagName( "outputEvents" )[0];
    var tin_events = [];
    if( tinEvents!= null )
        tin_events = tinEvents.getElementsByTagName("event");
    var tout_events = [];
    if( toutEvents != null )
        tout_events = toutEvents.getElementsByTagName("event");

    win.document.forms[0].input_events.options.add( new Option( "-", "-") );
    win.document.forms[0].output_events.options.add( new Option( "-", "-") );

    for( i = 0; i < all_events.length; ++i ) {
        var id = all_events[i].getAttribute('id');

        if( all_events[i].parentNode.nodeName == 'input' ) {
            sel = false;
            for( j = 0; j < tin_events.length; ++j ) {
                if( id == tin_events[j].getAttribute("idRef") ) {
                    sel = true;
                    break;
                }
            }
            win.document.forms[0].input_events.options.add(
                new Option( id, id, sel, sel ) );
        }
        else if( all_events[i].parentNode.nodeName == 'output' ) {
            sel = false;
            for( j = 0; j < tout_events.length; ++j ) {
                if( id == tout_events[j].getAttribute("idRef") ) {
                    sel = true;
                    break;
                }
            }
            win.document.forms[0].output_events.options.add(
                new Option( id, id, sel, sel ) );
        }
    }

    win.document.forms[0].transition_id.value = sel_node.getAttribute('id');
    var tname = sel_node.getElementsByTagName( "name" )[0];
    var text = tname.getElementsByTagName( "text" )[0];
    win.document.forms[0].transition_name.value = text.textContent;
    var comment = sel_node.getElementsByTagName( "comment" )[0];
    if( comment != null ) {
        text = comment.getElementsByTagName( "text" )[0];
        if( text != null && text.textContent != null )
            win.document.forms[0].comment.value = text.textContent;
        else win.document.forms[0].comment.value = "";
    }

    var timedomain = sel_node.getElementsByTagName( "timedomain" )[0];
    if( timedomain != null ) {
        text = timedomain.getElementsByTagName( "text" )[0];
        win.document.forms[0].timedomain.value = text.textContent;
    }
    else win.document.forms[0].timedomain.value = "";

    var priority = sel_node.getElementsByTagName( "priority" );
    if( priority.length == 1 && priority[0].textContent != null ) {
        win.document.forms[0].priority.value = priority[0].textContent;
    }
    else win.document.forms[0].priority.value = "1";

    var str = "";
    var guard = sel_node.getElementsByTagName( "signalinputguard" )[0];
    if( guard != null ) {
        var expr = guard.getElementsByTagName( "expression" )[0];
        if( expr != null ) str = exprToString( expr );
    }
    win.document.forms[0].guards.value = str;
    win.document.forms[0].guards.title = str;

    updateTransitionActions( win, sel_node );
}



function updateTransEvents( options, parent_node ) 
{
    var i, sel_opts = [];
    for( i = 0; i < options.length; ++i ) {
        if( options[i].selected && options[i].value != "-" )
            sel_opts.push( options[i].value );
    }

    var event_list = parent_node.getElementsByTagName( "event" );
    while( sel_opts.length > event_list.length ) {
        parent_node.appendChild( pnml.createElement( "event" ) );
    }

    event_list = parent_node.getElementsByTagName( "event" );
    for( i = 0; i < sel_opts.length; ++i ) {
        event_list[i].setAttribute( "idRef", sel_opts[i] );
    }

    while( sel_opts.length < event_list.length ) {
        parent_node.removeChild( event_list[event_list.length-1] );
    }
}



function addInputGuard( trans )
{
    var sig;
    var sig_list = trans.getElementsByTagName( "signalInputGuards" );
    if( sig_list.length < 1 ) {
        sig = pnml.createElement( "signalInputGuards" );
        trans.appendChild( sig );
    }
    else sig = sig_list[0];

    var ig = pnml.createElement( "signalinputguard" );
    var cs = pnml.createElement( "concreteSyntax" );
    cs.setAttribute( "language", "iopt" );
    ig.appendChild( cs );
    cs.appendChild( pnml.createElement( "text" ) );

    sig.appendChild( ig );

    return ig;
}



function saveTransitionOutputActions( win, tr )
{
    var i, j;

    var actions = tr.getElementsByTagName( "signalOutputAction" );
    var rem = [];

    for( j = 0; j < MAX_TR_OUT; ++j ) {
        var row = win.document.getElementById( "output" + (j+1) );
        var signal = row.getElementsByTagName( "select" )[0].value;
        if( signal > ' ' ) {
            var inputs = row.getElementsByTagName( "input" );
            var value = inputs[0].value;
            oa = actions[j];
            if( oa == null ) oa = addSignalOutputAction( tr );
            oa.setAttribute( "idRef", signal );
            var val = oa.getElementsByTagName( "value" )[0];
            val.getElementsByTagName("text")[0].textContent = value;
        }
        else if( j < actions.length ) rem.push( j );
    }

    // Remove unnused actions
    for( i = rem.length-1; i >= 0; --i ) {
        actions[i].parentNode.removeChild( actions[rem[i]] );
    }
}


function saveTransition( win )
{
    var id = win.document.forms[0].transition_id.value;
    sel_node = findNode( "transition", id );
    if( sel_node == null || node_type != "transition" ) return;

    var tname = sel_node.getElementsByTagName( "name" )[0];
    var text = tname.getElementsByTagName( "text" )[0];
    text.textContent = win.document.forms[0].transition_name.value;

    var comment = sel_node.getElementsByTagName( "comment" )[0];
    text = comment.getElementsByTagName( "text" )[0];
    text.textContent = win.document.forms[0].comment.value;

    var newTextValue = Number(win.document.forms[0].timedomain.value);
    if (newTextValue == 0) newTextValue = -1;
    saveNodeWithText( sel_node, "timedomain", newTextValue, 20, 0 );

    var priority = sel_node.getElementsByTagName( "priority" );
    if( priority.length == 1 ) {
        priority[0].textContent = Number(win.document.forms[0].priority.value);
    }

    var in_ev_opts = win.document.forms[0].input_events.options;
    var inputEvents = sel_node.getElementsByTagName( "inputEvents" )[0];
    if( inputEvents == null ) {
        inputEvents = pnml.createElement( "inputEvents" );
        sel_node.appendChild( inputEvents );
    }
    updateTransEvents( in_ev_opts, inputEvents );

    var out_ev_opts = win.document.forms[0].output_events.options;
    var outputEvents = sel_node.getElementsByTagName( "outputEvents" )[0];
    if( outputEvents == null ) {
        outputEvents = pnml.createElement( "outputEvents" );
        sel_node.appendChild( outputEvents );
    }
    updateTransEvents( out_ev_opts, outputEvents );

    saveTransitionOutputActions( win, sel_node );

    redrawNet();
    saveHistory();
}



function updateArc( win )
{
    if( sel_node == null || node_type != "arc" ) return;

    win.document.forms[0].arc_id.value = sel_node.getAttribute('id');
    var arc_type = sel_node.getElementsByTagName( "type" )[0];
    win.document.forms[0].arc_type.value = arc_type.textContent;
    var inscription = sel_node.getElementsByTagName( "value" )[0];
    if( inscription != null )
        win.document.forms[0].inscription.value = inscription.textContent;
}



function saveArc( win )
{
    var id = win.document.forms[0].arc_id.value;
    sel_node = findNode( "arc", id );
    if( sel_node == null || node_type != "arc" ) return;

    var type_val = win.document.forms[0].arc_type.value;

    var ac_target = findNode( "*", sel_node.getAttribute("target") );
    var ac_source = findNode( "*", sel_node.getAttribute("source") );

    if( isAsyncChannel( ac_target ) || isAsyncChannel( ac_source ) )
        type_val = "channel";
    if( type_val == "test" && ac_target.nodeName != "transition" )
        type_val = "normal";

    var arc_type = sel_node.getElementsByTagName( "type" )[0];
    arc_type.textContent = type_val;
    var inscription = sel_node.getElementsByTagName( "value" )[0];
    var ins = Number(win.document.forms[0].inscription.value);
    if( ins < 1 ) ins = 1;
    inscription.textContent = ins;

    redrawNet();
    saveHistory();
}



function updateSignal( win )
{
    if( sel_node == null || node_type != "signal" ) return;

    win.document.forms[0].signal_id.value = sel_node.getAttribute('id');
    win.document.forms[0].signal_mode.value = sel_node.parentNode.nodeName;
    win.document.forms[0].signal_type.value = sel_node.getAttribute('type');
    win.document.forms[0].signal_value.value = sel_node.getAttribute('value');
    win.document.forms[0].range_min.value = sel_node.getAttribute('min');
    win.document.forms[0].range_max.value = sel_node.getAttribute('max');
    if( sel_node.getAttribute('gpio_nr') > 0 )
	win.document.forms[0].phys_io.value = sel_node.getAttribute('gpio_nr');
    else win.document.forms[0].phys_io.value = "";

    var row = win.document.getElementById( "wrap_td");
    if( sel_node.parentNode.nodeName == 'output' ) {
        row.style.visibility = "visible";
        row.style.display = "table-row";
        win.document.forms[0].wrap.checked =
            Number(sel_node.getAttribute('wrap'));
    }
    else {
        row.style.visibility = "collapse";
        row.style.display = "none";
    }

    var ref = win.document.getElementById( "references" );

    var crefs = "";
    var ref_nodes = pnml.evaluate(
                "//net/*[signalOutputActions/signalOutputAction/@idRef='" + 
                    sel_node.getAttribute("id") + "']/name/text", pnml, null,
                    XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    for( var i = 0; i < ref_nodes.snapshotLength; ++i ) {
        var ref_node = ref_nodes.snapshotItem(i);
        if( crefs == "" ) crefs = "Changed in ";
        else crefs += ", ";
        crefs += ref_node.parentNode.parentNode.nodeName + "-" +
                 ref_node.parentNode.parentNode.getAttribute("id") + ":" +
                 ref_node.textContent;
    }
    if( crefs != "" ) crefs += "; ";

    var urefs = "";
    var ref_nodes = pnml.evaluate(
                "//net/*[*//expression//@idRef='" + 
                    sel_node.getAttribute("id") + "']/name/text", pnml, null,
                    XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    for( var i = 0; i < ref_nodes.snapshotLength; ++i ) {
        var ref_node = ref_nodes.snapshotItem(i);
        if( urefs == "" ) urefs = "Used in ";
        else urefs += ", ";
        urefs += ref_node.parentNode.parentNode.nodeName + "-" +
                 ref_node.parentNode.parentNode.getAttribute("id") + ":" +
                 ref_node.textContent;
    }
    if( urefs != "" ) urefs += "; ";

    var erefs = "";
    var ref_nodes = pnml.evaluate( "//net/*/event[@signal='" + 
                    sel_node.getAttribute("id") + "']", pnml, null,
                    XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    for( var i = 0; i < ref_nodes.snapshotLength; ++i ) {
        var ref_node = ref_nodes.snapshotItem(i);
        if( erefs == "" ) erefs = "Used by ";
        else erefs += ", ";
        erefs += ref_node.parentNode.nodeName + "-event:" +
                 ref_node.getAttribute("id");
    }
    if( erefs != "" ) erefs += "; ";

    ref.textContent = crefs + urefs + erefs;
}


function saveSignal( win )
{
    var id = win.document.forms[0].signal_id.value;
    sel_node = findNode( "signal", id );
    if( sel_node == null || node_type != "signal" ) return;

    var type = win.document.forms[0].signal_type.value;
    var value = Number(win.document.forms[0].signal_value.value);
    var min = Number(win.document.forms[0].range_min.value);
    var max = Number(win.document.forms[0].range_max.value);
    var gpio = Number(win.document.forms[0].phys_io.value);

    if( type == 'boolean' ) { min = 0; max = 1; }
    if( max < min ) { aux = min; min = max; max = aux; }
    if( value < min ) value = min;
    if( value > max ) value = max;
    if( gpio < 0 ) gpio = 0;

    sel_node.setAttribute( "type", type );
    sel_node.setAttribute( "value", value );
    sel_node.setAttribute( "min", min );
    sel_node.setAttribute( "max", max );
    sel_node.setAttribute( "gpio_nr", gpio );

    if( sel_node.parentNode.nodeName == 'output' ) {
        sel_node.setAttribute( "wrap", Number(win.document.forms[0].wrap.checked) );
    }

    redrawNet();
    saveHistory();
}



function updateEvent( win )
{
    if( sel_node == null || node_type != "event" ) return;

    var signals = sel_node.parentNode.getElementsByTagName( "signal" );
    for( var i = 0; i < signals.length; ++i ) {
        var id = signals[i].getAttribute('id');
        if( sel_node.parentNode.nodeName == "output" &&
           (signalDefinedByPlaceOutputActions( id ) ||
            signalDefinedByTransitionOutputActions( id )) ) continue;
        win.document.forms[0].event_signal.options.add( new Option( id, id ) );
    }

    win.document.forms[0].event_id.value = sel_node.getAttribute('id');
    win.document.forms[0].event_mode.value = sel_node.parentNode.nodeName;
    win.document.forms[0].autonomous.checked =
       (sel_node.getAttribute('autonomous') == "true");
    win.document.forms[0].event_edge.value = sel_node.getAttribute('edge');
    win.document.forms[0].event_level.value = sel_node.getAttribute('level');
    win.document.forms[0].event_signal.value = sel_node.getAttribute('signal');

    var ref = win.document.getElementById( "references" );
    var refs = "";
    var ref_nodes = pnml.evaluate( "//net/transition[*/event/@idRef='" + 
                    sel_node.getAttribute("id") + "']/name/text", pnml, null,
                    XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );  
    for( var i = 0; i < ref_nodes.snapshotLength; ++i ) {
        var ref_node = ref_nodes.snapshotItem(i);
        if( refs == "" ) refs = "Used by transitions ";
        else refs += ", ";
        refs += "tr-" + ref_node.parentNode.parentNode.getAttribute("id") +
                ":" + ref_node.textContent;
    }
    if( refs != "" ) refs += "; ";

    ref.textContent = refs;
}



function saveEvent( win )
{
    var id = win.document.forms[0].event_id.value;

    sel_node = findNode( "event", id );
    if( sel_node == null || node_type != "event" ) return;

    var autonomous = win.document.forms[0].autonomous.checked;

    if( autonomous == true ) {
        sel_node.removeAttribute( "edge" );
        sel_node.removeAttribute( "level" );
        sel_node.removeAttribute( "signal" );
        sel_node.setAttribute( "autonomous", "true" );
    }
    else {
        sel_node.setAttribute( "edge", win.document.forms[0].event_edge.value );
        sel_node.setAttribute( "level",
            Number(win.document.forms[0].event_level.value) );
        sel_node.setAttribute( "signal",
            win.document.forms[0].event_signal.value);
        sel_node.removeAttribute( "autonomous" );
    }

    redrawNet();
    saveHistory();
}


function findConnectedArcs( nodes, internal )
{
    var conn_arcs = [];
    if( nodes.length < 1 ) return conn_arcs;

    var arcs = pnml.getElementsByTagName( "arc" );
    for( var i = 0; i < arcs.length; ++i ) {
        var source = arcs[i].getAttribute( "source" );
        var target = arcs[i].getAttribute( "target" );
        var source_conn = false;
        var target_conn = false;
        for( j = 0; j < nodes.length; ++j ) {
            var id = nodes[j].getAttribute( "id" );
            if( id == source ) source_conn = true;
            if( id == target ) target_conn = true;
        }
        if( internal && ( source_conn && target_conn ) ||
           !internal && ( source_conn || target_conn ) )
           conn_arcs.push( arcs[i] );
    }

    return conn_arcs;
}



function deleteSelection()
{
    var i;
    var nodes = multiple_sel;
    if( nodes.length < 1 && sel_node != null ) nodes.push( sel_node );
    if( nodes.length < 1 ) return;

    // Remove arcs fisrt:
    var arcs = findConnectedArcs( nodes, false );
    for( i = 0; i < arcs.length; ++i ) {
        arcs[i].parentNode.removeChild( arcs[i] );
    }
    // Remove places and transitions
    for( i = 0; i < nodes.length; ++i ) {
        if( nodes[i].nodeName != 'signal' && nodes[i].nodeName != 'event' )
            nodes[i].parentNode.removeChild( nodes[i] );
    }
    // Remove all events not used by the remaining transitions
    for( i = 0; i < nodes.length; ++i ) {
        if( nodes[i].nodeName == 'event' &&
            !eventInUse( nodes[i].getAttribute("id") ) )
            nodes[i].parentNode.removeChild( nodes[i] );
    }
    // Remove all signals not used by the remaining events/places/transitions
    for( i = 0; i < nodes.length; ++i ) {
        if( (nodes[i].nodeName == 'signal' || nodes[i].nodeName == 'array') &&
            !signalInUse( nodes[i].getAttribute("id") ) )
            nodes[i].parentNode.removeChild( nodes[i] );
    }

    unselect();
    redrawNet();
    saveHistory();
    statusbar.value = "Deleted " + nodes.length + " nodes.";
}



function duplicateNodes( nodes, arcs, ancestor )
{
    var i;
    var copy = [];
    for( i = 0; i < nodes.length; ++i ) {
        copy[i] = nodes[i].cloneNode( true );
        if( copy[i].nodeName == "signal" || copy[i].nodeName == "event" ) {
            while( findNode( copy[i].nodeName, copy[i].getAttribute("id") ) )
                copy[i].setAttribute( "id", copy[i].getAttribute("id") + "_c" );
        }
        else copy[i].setAttribute( "id", node_nr++ );

        var pname = copy[i].getElementsByTagName( "name" )[0];
        if( pname != null ) {
            var text = pname.getElementsByTagName( "text" )[0];
            if( findNodeByName( copy[i].nodeName, text.textContent ) ) {
                var rep = 2;
                do new_text = text.textContent + "_" + rep++
                while( findNodeByName( copy[i].nodeName, new_text ) );
                text.textContent = new_text;
            }
        }
        var pos = copy[i].getElementsByTagName( "position" )[0];
        pos.setAttribute( "x", 10 + Number(pos.getAttribute("x")) );
        pos.setAttribute( "y", 10 + Number(pos.getAttribute("y")) );
        if( ancestor != null ) ancestor.appendChild( copy[i] );
        else nodes[i].parentNode.appendChild( copy[i] );
        multiple_sel.push( copy[i] );
        multiple_sel_pos.push( pos );
    }
    msel_mode = "done";

    for( i = 0; i < arcs.length; ++i ) {
        var new_arc = arcs[i].cloneNode( true );
        new_arc.setAttribute( "id", node_nr++ );
        var source = arcs[i].getAttribute( "source" );
        var target = arcs[i].getAttribute( "target" );
        for( var j = 0; j < nodes.length; ++j ) {
            var id = nodes[j].getAttribute( "id" );
            if( source == id )
                new_arc.setAttribute( "source", copy[j].getAttribute("id") );
            if( target == id )
                new_arc.setAttribute( "target", copy[j].getAttribute("id") );
        }
        if( ancestor != null ) ancestor.appendChild( new_arc );
        else arcs[i].parentNode.appendChild( new_arc );
    }
}



function duplicateSelection()
{
    var nodes = multiple_sel;
    if( nodes.length < 1 && sel_node != null ) nodes.push( sel_node );
    if( nodes.length < 1 ) return;

    var arcs = findConnectedArcs( nodes, true );

    unselect();
    duplicateNodes( nodes, arcs, null );
    redrawNet();
    saveHistory();
    statusbar.value = "Duplicated " + nodes.length + " nodes.";
}



function boundingBox( node_pos )
{
    var min_x = Infinity;
    var min_y = Infinity;
    var max_x = -Infinity;
    var max_y = -Infinity;
    for( var i = 0; i < node_pos.length; ++i ) {
        x = Number(node_pos[i].getAttribute("x"));
        y = Number(node_pos[i].getAttribute("y"));
        if( x < min_x ) min_x = x;
        if( x > max_x ) max_x = x;
        if( y < min_y ) min_y = y;
        if( y > max_y ) max_y = y;
    }
    var bbox = [];
    bbox[0] = min_x;
    bbox[1] = max_x;
    bbox[2] = min_y;
    bbox[3] = max_y;
    return bbox;
}


function rotateSelection( ccw )
{
    var i, j;

    if( multiple_sel.length < 1 && sel_node != null ) {
        multiple_sel.push( sel_node );
        multiple_sel_pos.push( sel_position );
        msel_mode = "done";
    }
    if( multiple_sel.length < 1 ) return;

    var bbox = boundingBox( multiple_sel_pos );
    var center_x = (bbox[0] + bbox[1]) / 2;
    var center_y = (bbox[2] + bbox[3]) / 2;

    for( i = 0; i < multiple_sel_pos.length; ++i ) {
        var x = Number(multiple_sel_pos[i].getAttribute("x"));
        var y = Number(multiple_sel_pos[i].getAttribute("y"));
        if( ccw == 1 ) {
            multiple_sel_pos[i].setAttribute("x", center_x + y - center_y );
            multiple_sel_pos[i].setAttribute("y", center_y + center_x - x );
        }
        else {
            multiple_sel_pos[i].setAttribute("x", center_x + center_y - y );
            multiple_sel_pos[i].setAttribute("y", center_y + x - center_x );
        }
    }

    // Transform arc bezier curve control points:
    var arcs = pnml.evaluate("//net//arc[count(graphics/offset)>1]/graphics",
               pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );
    for( i = 0; i < arcs.snapshotLength; ++i ) {
        var source_id = arcs.snapshotItem(i).parentNode.getAttribute("source");
        var target_id = arcs.snapshotItem(i).parentNode.getAttribute("target");
        var offsets = arcs.snapshotItem(i).getElementsByTagName("offset");
        var nodes = [];
        nodes[0] = findNode( "*", source_id );
        nodes[1] = findNode( "*", target_id );
        for( j = 0; j < 2; ++j ) {
            if( multiple_sel.indexOf( nodes[j] ) >= 0 ) {
                var x = Number(offsets[j].getAttribute("x"));
                var y = Number(offsets[j].getAttribute("y"));
                if( ccw == 1 ) {
                    offsets[j].setAttribute( "x", y );
                    offsets[j].setAttribute( "y", -x );
                }
                else {
                    offsets[j].setAttribute( "x", -y );
                    offsets[j].setAttribute( "y", x );
                }
            }
        }
    }

    redrawNet();
    saveHistory();
}



function mirrorSelection( vert )
{
    var i, j;

    if( multiple_sel.length < 1 && sel_node != null ) {
        multiple_sel.push( sel_node );
        multiple_sel_pos.push( sel_position );
        msel_mode = "done";
    }
    if( multiple_sel.length < 1 ) return;

    var bbox = boundingBox( multiple_sel_pos );
    var center_x = (bbox[0] + bbox[1]) / 2;
    var center_y = (bbox[2] + bbox[3]) / 2;

    for( i = 0; i < multiple_sel_pos.length; ++i ) {
        if( vert == 1 ) {
            var y = Number(multiple_sel_pos[i].getAttribute("y"));
            multiple_sel_pos[i].setAttribute("y", center_y - (y - center_y) );
        }
        else {
            var x = Number(multiple_sel_pos[i].getAttribute("x"));
            multiple_sel_pos[i].setAttribute("x", center_x - (x - center_x) );
        }
    }

    // Transform arc bezier curve control points:
    var arcs = pnml.evaluate("//net//arc[count(graphics/offset)>1]/graphics",
               pnml, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null );
    for( i = 0; i < arcs.snapshotLength; ++i ) {
        var source_id = arcs.snapshotItem(i).parentNode.getAttribute("source");
        var target_id = arcs.snapshotItem(i).parentNode.getAttribute("target");
        var offsets = arcs.snapshotItem(i).getElementsByTagName("offset");
        var nodes = [];
        nodes[0] = findNode( "*", source_id );
        nodes[1] = findNode( "*", target_id );
        for( j = 0; j < 2; ++j ) {
            if( multiple_sel.indexOf( nodes[j] ) >= 0 ) {
                if( vert == 1 ) {
                    var y = Number(offsets[j].getAttribute("y"));
                    offsets[j].setAttribute( "y", -y );
                }
                else {
                    var x = Number(offsets[j].getAttribute("x"));
                    offsets[j].setAttribute( "x", -x );
                }
            }
        }
    }

    redrawNet();
    saveHistory();
}

function isPositiveInteger(str) {
    var number = ~~Number(str);
    return String(number) === str && number > 0;
}

function changeTd()
{
  var newtd = prompt("Time-domain:","1");

  if ( !isPositiveInteger(newtd) )
    return;

    var i;
    var nodes = multiple_sel;
    if( nodes.length < 1 && sel_node != null ) nodes.push( sel_node );
    if( nodes.length < 1 ) return;

    // Change places and transitions time-domains
    var numChanged = 0;
    for( i = 0; i < nodes.length; ++i ) {
        if( nodes[i].nodeName == 'transition' || ( nodes[i].nodeName == 'place' && !isAsyncChannel( nodes[i] ) ) ) { 
            saveNodeWithText( nodes[i], "timedomain", newtd, 20, 0 );
            numChanged++;
        }
    }

    unselect();
    redrawNet();
    saveHistory();
    statusbar.value = "Time-domain changed in " + numChanged + " nodes.";
}

function setEditMode( mode )
{
    edit_mode = mode;
    unselect();
    source_node_id = null;
    statusbar.value = EditModesStr[mode];
    redrawNet();
}


function saveHistory()
{
    undo_history.push( pnml.documentElement.cloneNode( true ) );
    redo_list = [];
    changed = true;
}


function undo()
{
    if( undo_history.length > 1 ) {
        redo_list.push( undo_history.pop() );
        pnml.removeChild( pnml.documentElement );
        pnml.appendChild( undo_history[undo_history.length-1].cloneNode(true) );
        unselect();
        setEditMode( EditModes.Select );
    }
//statusbar.value = "UNDO history size = " + undo_history.length + " redo size = " + redo_list.length;
}


function redo()
{
    if( redo_list.length > 0 ) {
        pnml.removeChild( pnml.documentElement );
        pnml.appendChild( redo_list.pop() );
        undo_history.push( pnml.documentElement.cloneNode( true ) );
        unselect();
        setEditMode( EditModes.Select );
    }
}


function setSnap( evt )
{
    snap_to_grid = evt.target.checked;
    statusbar.value = "Snap " + (snap_to_grid ? "On" : "Off");
}


function setGrid( evt )
{
    show_grid = evt.target.checked;
    statusbar.value = "Grid " + (show_grid ? "On" : "Off");
    redrawNet();
}


function initClipboard()
{
    if( clipboard_window != null && clipboard_window.closed != true ) return;

    clipboard_window = window.open('clipboard.html', 'iopt_clipboard',
        'left=2000,width=420,height=480,location=0,status=0,toolbar=0', false );
}


function clipboardCut()
{
    if( multiple_sel.length < 1 && sel_node != null ) {
        multiple_sel.push( sel_node );
        multiple_sel_pos.push( sel_position );
    }

    if( multiple_sel.length < 1 ) return;
    if( clipboard_window == null || clipboard_window.closed ) initClipboard();
    else {
        clipboardCopy();
        deleteSelection();
    }
}



function clipboardCopy()
{
    var nodes = [];

    if( multiple_sel.length < 1 && sel_node != null ) {
        multiple_sel.push( sel_node );
        multiple_sel_pos.push( sel_position );
    }

    for( var i = 0; i < multiple_sel.length; ++i ) {
        nodes.push(multiple_sel[i]);
    }

    if( nodes.length < 1 ) return;
    var arcs = findConnectedArcs( nodes, true );
    clipboard_data = nodes.concat( arcs );

    if( clipboard_window == null || clipboard_window.closed ) initClipboard();
    else clipboard_window.clipboardPut( clipboard_data );
    statusbar.value = "Copied " + nodes.length + " nodes to clipboard";
}



function toArray( nodelist )
{
    var res = [];
    for( var i = 0; i < nodelist.length; ++i ) res[i] = nodelist[i];
    return res;
}


function clipboardPaste()
{
    unselect();
    clipboard_data = [];
    initClipboard();
    if( clipboard_window == null ) return;

    clipboard_data = clipboard_window.clipboardGet();
    var arcs = [];
    var nodes = [];
    var in_se = [];
    var out_se = [];
    for( var i = 0; i < clipboard_data.length; ++i ) {
        if( clipboard_data[i].nodeName=="arc" ) arcs.push( clipboard_data[i] );
        else if( clipboard_data[i].nodeName == "input" )
            in_se = toArray( clipboard_data[i].childNodes );
        else if( clipboard_data[i].nodeName == "output" )
            out_se = toArray( clipboard_data[i].childNodes );
        else nodes.push( clipboard_data[i] );
    }

    var net_node = pnml.getElementsByTagName("net")[0];
    var input_node = net_node.getElementsByTagName("input")[0];
    var output_node = net_node.getElementsByTagName("output")[0];
    duplicateNodes( nodes, arcs, net_node );
    duplicateNodes( in_se, [], input_node );
    duplicateNodes( out_se, [], output_node );
    redrawNet();
    saveHistory();
    statusbar.value = "Pasted " + nodes.length + " nodes from clipboard";
}



function annotMove( evt )
{
    var x, y, btn;

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
        x = evt.changedTouches[0].pageX;
        y = evt.changedTouches[0].pageY;
        btn = 0;
    }
    else {
        x = evt.pageX;
        y = evt.pageY;
        btn = evt.button;
    }

    evt.preventDefault();

    switch( evt.type ) {
        case "mousedown":
        case "touchstart":
            start_x = x;
            start_y = y;
            annotation_node = null;
            annotation_pos = null;
            annotation_off = null;
            annotation_text = null;
            if( btn > 0 ) {
                setEditMode( EditModes.Select );
                return;
            }
            var node_id = evt.target.getAttribute( "id" );
            var node_descr = evt.target.getAttribute( "descr" );
            if( node_id == null || node_descr == null ) return;
            var node = findNode( "*", node_id );
            if( node == null ) return;
            annotation_node = node.getElementsByTagName( node_descr )[0];
            msel_start_x = x;
            msel_start_y = y;
            annotation_off= annotation_node.getElementsByTagName( "offset" )[0];
            annotation_pos= annotation_node.getElementsByTagName("position")[0];
	    if( node_descr == "inscription" ) annotation_text =
                annotation_node.getElementsByTagName("value")[0].textContent;
            else annotation_text =
                annotation_node.getElementsByTagName("text")[0].textContent;
            moved = false;
            break;
        case "mousemove":
        case "touchmove":
            if( annotation_pos != null ) {
                annotation_pos.setAttribute( "x", x );
                annotation_pos.setAttribute( "y", y );
                moved = true;
                changed = true;
            }
            else if( annotation_off != null ) {
                var off_x = x - msel_start_x;
                var ox = off_x + Number(annotation_off.getAttribute("x"));
                if( ox < -MAX_OFF ) ox = -MAX_OFF;
                if( ox > +MAX_OFF ) ox = +MAX_OFF;
                annotation_off.setAttribute( "x", ox);

                var off_y = y - msel_start_y;
                var oy = off_y + Number(annotation_off.getAttribute("y"));
                if( oy < -MAX_OFF ) oy = -MAX_OFF;
                if( oy > +MAX_OFF ) oy = +MAX_OFF;
                annotation_off.setAttribute( "y", oy);

                msel_start_x = x;
                msel_start_y = y;
                moved = true;
                changed = true;
            }
            if( annotation_node != null  ) {
                if( !(chrome||safari) || evt.type == "mousemove" ) redrawNet();
                else evt.target.setAttribute( "transform",
                    "translate(" + (x-start_x) + "," + (y-start_y) + ")" );

            }
            break;
        case "mouseup":
        case "touchend":
            annotation_node = null;
            annotation_pos = null;
            annotation_off = null;
            annotation_text = null;
            redrawNet();
            if( moved ) saveHistory();
            moved = false;
            break;
    }

    if( annotation_node != null ) {
        statusbar.value = "Edit annotation: " +
            annotation_node.parentNode.nodeName + "[" + 
            annotation_node.parentNode.getAttribute("id") + "]." +
            annotation_node.nodeName + " = '" + annotation_text + "'";
    }

}



function createArcOffsets( arc )
{
    var graphics = arc.getElementsByTagName("graphics" );
    if( graphics.length < 1 ) {
         graphics = pnml.createElement( "graphics" );
         arc.appendChild( graphics );
    }
    else graphics = graphics[0];

    var offset = pnml.createElement("offset");
    offset.setAttribute( "x", "0" );
    offset.setAttribute( "y", "0" );
    graphics.appendChild( offset );

    offset = pnml.createElement("offset");
    offset.setAttribute( "x", "0" );
    offset.setAttribute( "y", "0" );
    graphics.appendChild( offset );
}



function arc_move( evt )
{
    var btn, ex, ey;

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
            evt.touches.length == 1 && evt.typr == "touchend" ) return;
        ex = evt.changedTouches[0].pageX;
        ey = evt.changedTouches[0].pageY;
        btn = 0;
    }
    else {
        ex = evt.pageX;
        ey = evt.pageY;
        btn = evt.button;
    }

    evt.preventDefault();
    // statusbar.value = "EditArc " + evt.type + " x=" + ex + " y=" + ey;

    switch( evt.type ) {
        case "mousedown":
        case "touchstart":
            start_x = ex;
            start_y = ey;
            if( btn != 0 || sel_node == null || node_type != 'arc' ||
                evt.target.getAttribute("idx") == null ) return;
            edit_mode = EditModes.EditArc;
            arc_point_idx = Number(evt.target.getAttribute( "idx" ))-1;
            arc_graphics = sel_node.getElementsByTagName("graphics")[0];
            if( arc_graphics == null ||
                arc_graphics.getElementsByTagName("offset").length < 2 )
                createArcOffsets( sel_node );
            moved = false;
            break;
        case "mousemove":
        case "touchmove":
            if( edit_mode == EditModes.EditArc && arc_graphics != null ) {
                var i = arc_point_idx;
                var off_x = ex - msel_start_x;
                var off_y = ey - msel_start_y;
                var points = arc_graphics.getElementsByTagName("offset");
                var x = Number(points[i].getAttribute( "x" ));
                var y = Number(points[i].getAttribute( "y" ));
                points[i].setAttribute( "x", x + off_x );
                points[i].setAttribute( "y", y + off_y );
                moved = true;

                if( !chrome || evt.type == "mousemove" ) redrawNet();
                else evt.target.setAttribute( "transform",
                    "translate(" + (ex-start_x) + "," + (ey-start_y) + ")" );
            }
            break;
        case "mouseup":
        case "touchend":
            if( edit_mode == EditModes.EditArc && arc_graphics != null ) {
                var points = arc_graphics.getElementsByTagName("offset");
                if( points.length >= 2 ) {
                    var x1 = Number(points[0].getAttribute( "x" ));
                    var y1 = Number(points[0].getAttribute( "y" ));
                    var x2 = Number(points[1].getAttribute( "x" ));
                    var y2 = Number(points[1].getAttribute( "y" ));
                    if( Math.abs(x1) < 10 && Math.abs(y1) < 10 &&
                        Math.abs(x2) < 10 && Math.abs(y2) < 10 ) {
                        points[1].parentNode.removeChild( points[1] );
                        points[0].parentNode.removeChild( points[0] );
                    }
                }
            }
            if( !chrome || !moved || evt.type == "mouseup" )
                edit_mode = EditModes.Select;
            arc_point_idx = 0;
            arc_graphics = null;
            if( moved ) saveHistory();
            moved = false;
            redrawNet();
            break;
    }

    msel_start_x = ex;
    msel_start_y = ey;
}



function keyPressed( evt )
{
    var pass = false;

    var key = String.fromCharCode(evt.which).toUpperCase();

    if( evt.keyCode == 27 ) setEditMode( EditModes.Select ); // Escape
    else if( evt.which == 8 ) deleteSelection(); // BackSpace
    else if( evt.ctrlKey ) switch( key ) {
        case 'Z': undo(); break;
        case 'Y': redo(); break;
        case 'X': clipboardCut(); break;
        case 'C': clipboardCopy(); break;
        case 'V': clipboardPaste(); break;
        case 'S': save(); break;
        case 'Q': cancel(); break;
        case 'A': selectAll(); break;
        case 'I': invertSelection(); break;
        case 'D': duplicateSelection(); break;
        case 'P': setEditMode(EditModes.Place); break;
        case 'T': setEditMode(EditModes.Transition); break;
        case 'R': setEditMode(EditModes.Arc); break;
        case 'H': setEditMode(EditModes.AsyncChannel); break;
        case 'E': setEditMode(EditModes.Erase); break;
        case 'N': setEditMode( edit_mode == EditModes.Annotations ?
                               EditModes.Select : EditModes.Annotations );break;
        case 'B': setEditMode(EditModes.InSignal); break;
        case 'L': setEditMode(EditModes.OutSignal); break;
        case 'M': setEditMode(EditModes.InEvent); break;
        default : pass = true;
    }
    if( pass == false ) evt.preventDefault();
}



function touch_cancel( evt )
{
    redrawNet();
}


function catch_touch( evt )
{
    if( evt.touches.length > 1 ||
        evt.touches.length == 1 && evt.typr == "touchend" ) return;

    var id = evt.target.getAttribute("id");
    if( id == "background" || id == "sel_area" ) bg_move( evt );
    else node_move( evt );
}


function backupExpr( expr )
{
    if( expr == null ) backup_expr = null;
    else backup_expr = expr.cloneNode( true );
}



function getBackupExpr()
{
    if( expr_stvec_mode == false ) return backup_expr;
    var expr = backup_expr.cloneNode( true );
    var op = expr.getElementsByTagName( "operand" );
    for( var i = 0; i < op.length; ++i ) {
        var o = op[i];
        if( o.getAttribute("type") == "input-signal" ||
	    o.getAttribute("type") == "output-signal" &&
	    signalDefinedByPlaceOutputActions(Number(o.getAttribute("idRef")))||
	    o.getAttribute("type") == "array-item" ) {
	    o.setAttribute( "type", "literal" );
	    o.setAttribute( "value", "0" );
	}
    }
    return expr;
}


function getEditExpression()
{
    if( sel_edit_expr == null ) return null;
    var expr_elem = sel_edit_expr.getElementsByTagName( "expression" )[0];
    return expr_elem;
}



function editExpression( parent_elem, input )
{
    sel_edit_expr = parent_elem;
    edit_expr_input = input;
    if( sel_edit_expr != null ) openDialog( 700, 300, "expr_editor.html" );
}



function editGuard( input )
{
    if( sel_node == null || sel_node.nodeName != "transition" ) return;
    var guard = sel_node.getElementsByTagName( "signalinputguard" )[0];
    if( guard == null ) guard = addInputGuard( sel_node );
    editExpression( guard, input );
}



function editCondition( input, n )
{
    if( sel_node == null || sel_node.nodeName != "place" ) return;

    var sel_action = null;
    var actions = sel_node.getElementsByTagName( "signalOutputAction" );
    if( n <= actions.length ) sel_action = actions[n-1];
    else if( n == actions.length+1 )
        sel_action = addSignalOutputAction( sel_node );
    if( sel_action != null ) {
        var cond = sel_action.getElementsByTagName( "condition" )[0];
        if( cond != null ) editExpression( cond, input );
    }
}



function editSigValue( input, n )
{
    if( sel_node == null || 
        (sel_node.nodeName != "place" && sel_node.nodeName != "transition") )
        return;

    var sel_action = null;
    var actions = sel_node.getElementsByTagName( "signalOutputAction" );
    if( n <= actions.length ) sel_action = actions[n-1];
    else if( n == actions.length+1 )
        sel_action = addSignalOutputAction( sel_node );
    if( sel_action != null ) {
        var value = sel_action.getElementsByTagName( "value" )[0];
        expr_stvec_mode = (sel_node.nodeName == "transition");
        if( value != null ) editExpression( value, input );
    }
}


function openDialog( wid, hei, doc )
{
    var div = document.createElement( "div" );
    div.setAttribute( "id", "dialog_bg" );
    div.style.position = "absolute";
    div.style.left = 0;
    div.style.top = 0;
    div.style.width = "100%";
    div.style.height = "100%";
    div.style.opacity = 0.75;
    div.style.background = "lightgray";
    document.body.appendChild( div );

    var div2 = document.createElement( "div" );
    div2.setAttribute( "id", "dialog_fg" );
    div2.style.position = "absolute";
    div2.style.left = "30%";
    div2.style.top = "30%";
    div2.style.width = wid+10;
    div2.style.height = hei+10;
    div2.style.background = "lightgray";
    div2.style.padding = 10;
    div2.style.opacity = 1.0;
    div2.style.textAlign = "center";

    div2.innerHTML = '<iframe id="dialog_frame" src="' + doc +
                     '" width="' + wid + '" height="' + hei + 
                     '" scrolling="no"></iframe>';

    document.body.appendChild( div2 );
    div2.focus();
}



function closeDialog()
{
    document.body.removeChild( document.getElementById( "dialog_fg") );
    document.body.removeChild( document.getElementById( "dialog_bg") );
    expr_stvec_mode = false;
}



function exprToString( expr )
{
    var res = exprToStrXsltProc.transformToDocument( expr );
    if( res == null || res.documentElement == null ) return "";
    return res.documentElement.textContent.replace( /\n/g, "" );
}


function saveExpression( expr )
{
    closeDialog();
    if( sel_node == null || sel_edit_expr == null ) return;

    var ioptcs = null;
    var csl = sel_edit_expr.getElementsByTagName( "concreteSyntax" );
    for( var i = 0; i < csl.length; ++i ) {
        if( csl[i].getAttribute( "language" ) == "iopt" ) {
            ioptcs = csl[i];
            break;
        }
    }

    if( ioptcs == null ) {
        ioptcs = pnml.createElement( "concreteSyntax" );
        ioptcs.setAttribute( "language", "iopt" );
        sel_edit_expr.appendChild( ioptcs );
    }
    else {
        while( ioptcs.firstChild != null )
            ioptcs.removeChild( ioptcs.firstChild );
    }

    var text = pnml.createElement( "text" );
    text.textContent = exprToString( expr );
    ioptcs.appendChild( text );
    ioptcs.appendChild( expr );

    if( edit_expr_input != null ) edit_expr_input.value = text.textContent;

    redrawNet();
    saveHistory();
}


function validatePnml() {
  //basta haver um no com TD definido para todos os nos terem de ter TD definido
  var countNodes = 0;
  var nodesWithTD = 0;
  var places = getPlaceList();
  for( var i = 0; i < places.length; ++i ) {
    if ( !isAsyncChannel( places[i] ) ) {
      countNodes++;
      var timedomain = getNodeText( places[i], "timedomain" );
      if (timedomain) nodesWithTD++;
    }
  }
  var transitions = getTransitionList();
  for( var i = 0; i < transitions.length; ++i ) {
    countNodes++;
    var timedomain = getNodeText( transitions[i], "timedomain" );
    if (timedomain) nodesWithTD++;
  }
  if ( nodesWithTD != 0 && countNodes != nodesWithTD ) {
    alert("If one place or transition has time-domain defined, all places and transitions must have time-domain defined.");
    return false;
  }
  //cada AC tem de ter pelo menos um arco de entrada e um de saida
  //todos os slaves de um AC tem de ter o mm td
  //o master e os slaves tem de ter diferentes TDs
  var arcs = pnml.getElementsByTagName( "arc" );
  var places = getPlaceList();
  for( var j = 0; j < places.length; ++j ) {
    if ( isAsyncChannel( places[j] ) ) {
      var found_in_arc = false;
      var found_out_arc = false;
      var master_td = -1;
      var slave_td = -2;
      var id = places[j].getAttribute( "id" );
      var name = getNodeText( places[j], "name" );
      for( var i = 0; i < arcs.length; ++i ) {
        var sourceId =  arcs[i].getAttribute("source");
        var targetId =  arcs[i].getAttribute("target");
        if ( id == targetId ) {
          found_in_arc = true;
          var sourceNode = findNode( "*", sourceId );
          master_td = getNodeText( sourceNode, "timedomain" );
          if ( !master_td ) {
            alert("Invalid Asynchronous-Channel <<" + name + " " + id + ">>. Master transition must have time domain defined.");
            return false;
          }
        }
        if ( id == sourceId ) {
          found_out_arc = true;
          var targetNode = findNode( "*", targetId );
          var td = getNodeText( targetNode, "timedomain" );
          if ( !td ) {
            alert("Invalid Asynchronous-Channel <<" + name + " " + id + ">>. Slave transitions must have time domain defined.");
            return false;
          }
          if (slave_td == -2) slave_td = td;
          else {
            if (slave_td != td) {
              alert("Invalid Asynchronous-Channel <<" + name + " " + id + ">>. Slave transitions must have equal time domains.");
              return false;
            }
          }
        }
        if ( master_td == slave_td) {
          alert("Invalid Asynchronous-Channel <<" + name + " " + id + ">>. Master and slave transitions must have different time domains.");
          return false;
        }
      }
      if ( !found_in_arc || !found_out_arc ) {
        alert("Invalid Asynchronous-Channel <<" + name + " " + id + ">>. Must have input and output arcs.");
        return false;
      }
    }
  }

  //o master do report é slave do simple
  for( var j = 0; j < places.length; ++j ) {
    var id = places[j].getAttribute( "id" );
    var name = getNodeText( places[j], "name" );
    if ( isRecOrUnfAsyncChannel( places[j] ) ) {
      var existing = findArcWithTarget( id );
      var source = existing.getAttribute( "source" );
      if( !existsArcChannelWithTarget( source ) ) {
        alert( "The source transition of the (acknowledge or notenable) asynchronous channel <<" + name + " " + id +">> must be target transition of another asynchronous channel" );
        return false;
      }
    }
  }
  return true;
}



function runPlugin( plug_sel )
{
    pluginForm( plug_sel.value );
    plug_sel.value = "";
}



function pluginForm( plugin )
{
    plugin_name = plugin;
    if( plugin_name == null ) return;
    plugin_doc = loadXMLDoc("plugins/" + plugin_name );
    if( plugin_doc == null ) return;

    openDialog( 600, 400, "plugin-form.php?plugin=" + plugin_name );
}



function applyPlugin( form )
{
    var form_doc = document.getElementById( "dialog_frame" ).contentDocument;
    if( form_doc == null ) return;
    var inputs = form_doc.getElementsByTagName( "input" );
    var selects = form_doc.getElementsByTagName( "select" );

    var params = plugin_doc.getElementsByTagName( "param" );
    for( var i = 0; i < params.length; ++i ) {
        var name = params[i].getAttribute( "name" );
        var type = params[i].getAttribute( "type" );
        var input = null;

        if( type == "selection" ) {
            if( multiple_sel.length < 1 && sel_node != null ) {
                multiple_sel.push( sel_node );
                multiple_sel_pos.push( sel_position );
            }

            var node_types = params[i].getElementsByTagName( "node-type" );

            for( var t = 0; t < node_types.length; ++t ) {
                var type = node_types[t].textContent;
                for( var j = 0; j < multiple_sel.length; ++j ) {
                    var id = multiple_sel[j].getAttribute( "id" );
                    if( id == null ) continue;
                    if( type != '*' && multiple_sel[j].nodeName != type ) 
                        continue;
                    var selnode = plugin_doc.createElement( "node" );
                    selnode.setAttribute( "type", multiple_sel[j].nodeName );
                    selnode.setAttribute( "id", id );
                    params[i].appendChild( selnode );
                }
            }
            for( var t = node_types.length-1; t >= 0; --t ) {
                params[i].removeChild( node_types[t] );
            }
            continue;
        }

        for( var j = 0; j < inputs.length; ++j ) {
            if( inputs[j].getAttribute( "name" ) == name ) {
                input = inputs[j];
                break;
            }
        }
        if( input == null ) for( var j = 0; j < selects.length; ++j ) {
            if( selects[j].getAttribute( "name" ) == name ) {
                input = selects[j];
                break;
            }
        }
        if( input != null ) {
            if( type != 'boolean' )
                params[i].setAttribute( "value", input.value );
            else params[i].setAttribute( "value", input.checked );
        }

        if( type == "enum" ) {
            while( params[i].firstChild )
                params[i].removeChild( params[i].firstChild );
        }
    }

    closeDialog();

    var topnode = pnml.getElementsByTagName( "pnml" )[0];
    topnode.appendChild( plugin_doc.documentElement.cloneNode(true) );

    var plug_data = output.getElementsByTagName( "pnml-editor-plugin" )[0];

    var res = saveXMLDoc( "plugin-upload.php?plugin=" + plugin_name, pnml );
    if( res > 200 ) {
        plug_data.parentNode.removeChild( plug_data );
        alert( "Error " + res + " uploading plugin data" );
        return;
    }

    var output = loadXMLDoc("plugin-exec.php?plugin=" + plugin_name );
    if( output == null ) {
        plug_data.parentNode.removeChild( plug_data );
        alert( "Error executing plugin " + plugin_name );
        return;
    }

    var next_plugin = null;

    if( plug_data != null ) {
        var msg = plug_data.getElementsByTagName( "error-msg" )[0];

        if( msg != null ) {
            alert( msg.textContent );
            return;
        }
        plug_data.parentNode.removeChild( plug_data );

        var nextp = plug_data.getElementsByTagName( "next_plugin" )[0];
        if( nextp != null ) {
            pluginForm( nextp.textContent );
            return;
        }
    }

    unselect();
    pnml.removeChild( pnml.documentElement );
    pnml.appendChild( output.documentElement.cloneNode(true) );
    saveHistory();
    redrawNet();
    changed = true;
}



function updatePNMLVersion( pnml )
{
    var actions = pnml.getElementsByTagName( "signalOutputAction" );
    for( var i = 0; i < actions.length; ++i ) {
        var v = actions[i].getAttribute( "value" );
        if( v == null ) continue;

        // Remove/unlink old syntax:
        actions[i].removeAttribute( "value" );
        var cs = actions[i].getElementsByTagName( "concreteSyntax" )[0];
        if( cs ) actions[i].removeChild( cs );

        // Convert to new syntax:
        var value = pnml.createElement( "value" );
        var vcs =  pnml.createElement( "concreteSyntax" );
        vcs.setAttribute( "language", "iopt" );
        value.appendChild( vcs );
        actions[i].appendChild( value );
        var text = pnml.createElement( "text" );
        text.appendChild( pnml.createTextNode( v ) );
        vcs.appendChild( text );
        var expr = pnml.createElement( "expression" );
        vcs.appendChild( expr );
        var oper = pnml.createElement( "operand" );
        oper.setAttribute( "type", "literal" );
        oper.setAttribute( "value", v );
        oper.setAttribute( "seq", 1 );
        expr.appendChild( oper );

        var cond = pnml.createElement( "condition" );
        if( cs == null ) {
            cs = pnml.createElement( "concreteSyntax" );
            cs.setAttribute( "language", "iopt" );
        }
        cond.appendChild( cs );
        actions[i].appendChild( cond );
        changed = true;
    }

    if( changed ) redrawNet();
}

