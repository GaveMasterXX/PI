<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
    }
    else die("<p>No Document - please check if your browser has cookie support enabled.</p>");

    header("Content-type: image/svg+xml");
    header("Pragma: no-cache");

    $xslDoc = new DOMDocument();
    if( $_GET["edit"] ) $xslDoc->load("xsl/iopt2svg-edit.xslt");
    else $xslDoc->load("xsl/iopt2svg.xsl");
    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','width','2048');
    $proc->setParameter('','height','2048');

    echo $proc->transformToXML($pnmlDoc);
?>
