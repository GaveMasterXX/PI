<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);
    $xpath = new DOMXPath( $pnmlDoc );

    echo "<HTML>\n";
    echo "<HEAD>\n";
    echo "<TITLE> IOPT State Space Query Editor </TITLE>\n";
    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n";
    echo "<script src='query_script.js'></script>\n";
    echo "<link href='../css/style.css' rel='stylesheet' type='text/css' media='screen' />\n";
    echo "</HEAD>\n";
    echo "<BODY onload='init()'>\n";
 
    echo "<center>\n";
    echo "<p><font size='+2'><b> State-space Query Editor</b></font></p>\n";
    echo "<table width='90%' border='3' cellpadding='2' rules='none'>\n";
    echo "<tr><th align='center' colspan='2'> Model " . $_SESSION["pnml_file"] . "</th></tr>\n";
    echo "<tr><td align='center'>Values:</td><td>\n";
    

    $places = $xpath->query( "//pnml/net/place/name/text" );
    echo " Places:\n";
    echo "<select name='place' onchange='add_place(this)'>\n";
    echo "<option selected> </option>\n";
    foreach( $places as $p ) {
         echo "<option value='state-&gt;m.p_" .
	      $p->parentNode->parentNode->getAttribute( "id" ) . "'>";
	 echo $p->textContent;
         echo "</option>\n";
    }
    echo "</select>\n";

    echo "&nbsp;&nbsp;&nbsp;\n";

    $trans = $xpath->query( "//pnml/net/transition/name/text" );
    echo " Transitions: \n";
    echo "<select name='transition' onchange='add_transition(this)'>\n";
    echo "<option selected> </option>\n";
    foreach( $trans as $t ) {
         echo "<option value='state-&gt;t.t_" .
	      $t->parentNode->parentNode->getAttribute( "id" ) . "'>";
	 echo $t->textContent;
         echo "</option>\n";
    }
    echo "</select>\n";

    echo "&nbsp;&nbsp;&nbsp;\n";

    $signal = $xpath->query( "//pnml/net/output/event/@signal" );
    $eos = array();
    echo " Event Output Signals: \n";
    echo "<select name='eos' onchange='add_signal(this)'>\n";
    echo "<option selected> </option>\n";
    foreach( $signal as $s ) {
         if( $eos[ $s->textContent ] == 1 ) continue;
         echo "<option value='state-&gt;o." . $s->textContent . "'>";
	 echo $s->textContent;
         echo "</option>\n";
         $eos[ $s->textContent ] = 1;
    }
    echo "</select>\n";

    echo "<br/> Literal: \n";
    echo "<select name='constant' onchange='add_constant(this)'>\n";
    echo "<option selected> </option>\n";
    echo "<option> 0 </option>\n";
    echo "<option> 1 </option>\n";
    echo "<option> 2 </option>\n";
    echo "<option> 3 </option>\n";
    echo "<option> 4 </option>\n";
    echo "<option> 5 </option>\n";
    echo "<option> 6 </option>\n";
    echo "<option> 7 </option>\n";
    echo "<option> 8 </option>\n";
    echo "<option> 9 </option>\n";
    echo "</select>\n";
    echo "<input type='text' name='const' numeric='1' size='20' onkeypress='keypress(this, event);'></input>\n";

    echo "</td></tr>\n";

    echo "<tr><td align='center'>Operators:</td><td>\n";

    echo " Comparation: \n";
    echo "<select name='cmp' onchange='add_comparation(this)'>\n";
    echo "<option selected> </option>\n";
    echo "<option value='=='> = </option>\n";
    echo "<option value='!='> &lt;&gt; </option>\n";
    echo "<option value='&lt'> &lt </option>\n";
    echo "<option value='&gt'> &gt </option>\n";
    echo "<option value='&lt='> &lt= </option>\n";
    echo "<option value='&gt='> &gt= </option>\n";
    echo "</select>\n";
    echo "&nbsp;&nbsp;&nbsp;\n";

    echo " Aritmetic: \n";
    echo "<select name='math' onchange='add_math(this)'>\n";
    echo "<option selected> </option>\n";
    echo "<option value='+'> + </option>\n";
    echo "<option value='-'> - </option>\n";
    echo "<option value='*'> * </option>\n";
    echo "<option value='/'> / </option>\n";
    echo "<option value='%'> MOD </option>\n";
    echo "</select>\n";
    echo "&nbsp;&nbsp;&nbsp;\n";

    echo " Logic: \n";
    echo "<select name='lop' onchange='add_logic(this)'>\n";
    echo "<option selected> </option>\n";
    echo "<option value=' !'> NOT </option>\n";
    echo "<option value=' && '> AND </option>\n";
    echo "<option value=' || '>  OR  </option>\n";
    echo "</select>\n";

    echo "<br />\n";

    echo " Sub-expression: \n";
    echo "<select name='sub' onchange='add_subexpr(this)'>\n";
    echo "<option selected> </option>\n";
    echo "<option value='('> ( </option>\n";
    echo "<option value=')'> ) </option>\n";
    echo "</select>\n";

    echo "</td></tr>\n";
    echo "<tr><td align='right'>Reachability:</td><td>";
    echo "State <input type='text' name='reach' numeric='1' size='8' onkeypress='keypress(this, event);'></input> is reachable</td></tr>\n";
    echo "<tr><td align='center'>Edit:</td><td>\n";

    echo "<input type='button' name='erase' value='Erase' onclick='erase()'></input>\n";
    echo "&nbsp;&nbsp;&nbsp;\n";
    echo "<input type='button' name='clear' value='Clear All' onclick='clear_all()'></input>\n";
    echo "&nbsp;&nbsp;&nbsp;\n";
    echo "<input type='button' name='undo' value='Undo' onclick='undo()'></input>\n";
    echo "</td></tr>\n";
    echo "<tr><td align='center'>Query:</td><td align='center'>\n";
    echo "<textarea id='query_str' rows='3' cols='100' readonly='1'></textarea>\n";
    echo "</td></tr>\n";
    echo "</table>\n";

    echo "<p>\n";
    // echo "<input type='button' name='code' value='Show Code' onclick='show_code()'></input>\n";
    echo "<input type='button' name='save' value='Save' onclick='save()'></input>\n";
    echo "&nbsp; &nbsp; &nbsp;\n";
    echo "<input type='button' name='exit' value='Exit' onclick='cancel()'></input>\n";
    echo "</p>\n";

    echo "<p>Query list: &nbsp; &nbsp; &nbsp; Selected query:\n";
    echo "<input type='text' name='selected' id='selected' value='1' size='2' readonly='1'></input><br />\n";
    echo "<iframe name='queries_list' id='queries_list' src='get_queries.php' width='80%' height='40%'>Loading...</iframe>\n";
    echo "</p></center>\n";


    echo "</BODY>\n";
    echo "</HTML>\n";

?>
