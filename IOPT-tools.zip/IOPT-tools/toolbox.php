<html>
<head>
    <title> IOPT Tools - PNML Editor</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body bgcolor="gray">
<input type="image" src="icons/select.png" onclick="parent.setEditMode(0);" title="Select [Esc]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/annot.png" onclick="parent.setEditMode(10);" title="Edit Annotations [Ctrl-N]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/scroll.png" onclick="parent.setEditMode(13);" title="Scroll/Drag Page" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />
<input type="image" src="icons/all.png" onclick="parent.selectAll();" title ="Select All [Ctrl-A]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/invert.png" onclick="parent.invertSelection();" title="Invert Selection [Ctrl-I]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />
<input type="image" src="icons/undo.png" onclick="parent.undo();" title="Undo [Ctrl-Z]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/redo.png" onclick="parent.redo();" title="Redo [Ctrl-Y]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />
<input type="image" src="icons/erase.png" onclick="parent.setEditMode(5);" title="Point to Erase Node(s-shift) [Ctrl-E]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/delete.png" onclick="parent.deleteSelection();" title="Delete Selection [BackSpace]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />

<input type="image" src="icons/cut.png" onclick="parent.clipboardCut();" title="Cut Selection to Clipboard [Ctrl-X]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/copy.png" onclick="parent.clipboardCopy();" title="Copy Selection to Clipboard [Ctrl-C]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/paste.png" onclick="parent.clipboardPaste();" title="Paste Clipboard Content [Ctrl-V]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />
<input type="image" src="icons/cw.png" onclick="parent.rotateSelection(0);" title="Rotate Selection 90º CW" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/ccw.png" onclick="parent.rotateSelection(1);" title="Rotate Selection 90º CCW" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/dup.png" onclick="parent.duplicateSelection();" title="Duplicate Selection [Ctrl-D]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br/>
<input type="image" src="icons/mirror.png" onclick="parent.mirrorSelection(0);" title="Horizontal Mirror Selection" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/vmirror.png" onclick="parent.mirrorSelection(1);" title="Vertical Mirror Selection" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/fusion.png" onclick="parent.nodeFusion();" title="Node Fusion: Merge the 2 selected Transition/Places." onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<br/>&nbsp;<br/>
<input type="image" src="icons/place.png" onclick="parent.setEditMode(1);" title="Add Place(s-shift) [Ctrl-P]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/trans.png" onclick="parent.setEditMode(2);" title="Add Transitions(s-shift) [Ctrl-T]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/arcs.png" onclick="parent.setEditMode(3);" title="Add Arcs [Ctrl-R]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /></br />

<input type="image" src="icons/ac.png" onclick="parent.setEditMode(4);" title="Add Asynchronous-Channel [Ctrl-H]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/td.png" onclick="parent.changeTd();" title="Change selected nodes time-domain" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /></br />

<input type="image" src="icons/compl.png" onclick="parent.complementPlace();" title="Create Selected Place's Complementary Place" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/redlight.png" onclick="parent.createInvariantSectionLock( true );" title="Create a Semaphore for a critical-section composed by the selected Places" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/lock.png" onclick="parent.createInvariantSectionLock( false );" title="Lock a Marking-Invariant-Section composed by the selected Places" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<br />&nbsp;<br/>
<input type="image" src="icons/insig.png" onclick="parent.setEditMode(6);" title="Add Input Signal" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/outsig.png" onclick="parent.setEditMode(7);" title="Add Output Signal" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/array.png" onclick="parent.setEditMode(12);" title="Add Array/Table" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />
<input type="image" src="icons/inevent.png" onclick="parent.setEditMode(8);" title="Add Input Event" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/outevent.png" onclick="parent.setEditMode(9);" title="Add Output Event" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" /><br />
<!--button onclick="parent.setEditMode(4);"> Async Channel </button-->
&nbsp;<br/>
<input type="image" src="icons/save.png" onclick="parent.save();" title="Save Model [Ctrl-S]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<input type="image" src="icons/exit.png" onclick="parent.cancel();" title="Quit [Ctrl-Q]" onmouseover="style.opacity=0.5;" onmouseout="style.opacity=1.0;" onmouseup="style.opacity=0.5;" onmousedown="style.opacity=1.0;" />
<p>Plug-ins:<br/>
<select onchange="parent.runPlugin(this);">
  <option value="" selected="1"> </option>"
<?php
   $files = scandir( "plugins" );
   foreach( $files as $f ) {
      if( strstr( $f, ".xml" ) == FALSE ) continue;
      $name = substr( $f, 0, -4 );
      echo "  <option value='$f'>" . $name .  "</option>\n";
   }
?>
</select>
</p>
</body>
</html>
