<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();
    if( isset($_SESSION["username"]) ) $user = $_SESSION["username"];
    else {
	header( "Location: login.php" );
	exit();
    }
?>

<html>
<head>
    <title>IOPT Tools</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<center>
<p><font size="+2"><b> IOPT Tools <?php echo "($user)" ?> </b></font> &nbsp; &nbsp; <a href="login.php">Logout</a><br />

<?php
    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset($_POST["logout"]) ) {
	unset( $_SESSION["username"] );
	header( "Location: login.php" );
	exit();
    }

    if( isset( $_POST["create"]) ) {
	unset( $_SESSION["pnml_file"] );

	$net_name = addslashes(str_replace( "..", "__", $_POST["net_name"]));
	if( strlen( $net_name ) < 2 ) die( "Invalid net name" );
	if( !ctype_alpha( $net_name[0] ) ) $net_name = "N_" . $net_name;

	$pnml_file = $net_name . ".pnml";
	$filename = $user_dir . "/files/" . $pnml_file;
	if( file_exists($filename) ) die( "Error: Duplicate model/file name" );

	$fptr = fopen( $filename, "w" );
	$res = file( "empty.pnml" );
	foreach( $res as $r ) {
	    fprintf( $fptr, str_replace( "empty", $net_name, $r ) );
	}
	fclose( $fptr );

	$_SESSION["pnml_file"] = $pnml_file;

	$fptr = fopen( "log/upload.log", "a" );
	fwrite( $fptr, date("Y/m/d g:i") . " create: " . $pnml_file . " - " . $_SERVER["REMOTE_ADDR"] . " - " . $_SERVER["HTTP_USER_AGENT"] . "\n" );
	fclose( $fptr );
    }
    else if( isset( $_POST["upload"]) && isset( $_FILES["pnml_file"]) ) {
	if ($_FILES["pnml_file"]["error"] > 0) {
	    echo "Upload error: " . $_FILES["pnml_file"]["error"] . "<br />";
	    unset( $_SESSION["pnml_file"] );
	}
	else {
	    $pnml_file = addslashes(str_replace( "..", "__", $_FILES["pnml_file"]["name"]));
	    $_SESSION["pnml_file"] = $pnml_file;
            move_uploaded_file( $_FILES["pnml_file"]["tmp_name"],
	                        $user_dir . "/files/" . $pnml_file );
	}

	$fptr = fopen( "log/upload.log", "a" );
	fwrite( $fptr, date("Y/m/d g:i") . " upload: " . $pnml_file . " - " . $_SERVER["REMOTE_ADDR"] . " - " . $_SERVER["HTTP_USER_AGENT"] . "\n" );
	fclose( $fptr );
    }
    else if( isset( $_POST["pnml_file"] ) ) {
	$pnml_file = addslashes(str_replace( "..", "__", $_POST["pnml_file"]));
	$_SESSION["pnml_file"] = $pnml_file;
    }
    else if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file=$_SESSION["pnml_file"];
    }

    if( isset($pnml_file) ) {
	echo "Net file:<b> $pnml_file </b></p>\n";
	if( file_exists( $user_dir . "/files/" . $pnml_file) ) {
	    echo '<iframe border="1" width="90%" height="65%" scrolling="yes" src="show_iopt.php?edit=1" style="width:90%; height:65%; overflow:scroll; -webkit-overflow-scrolling:touch;"></iframe>' . "\n";
	}
    }

    if( isset($pnml_file) ) { 
	echo "<p><button onclick=\"document.location='pnml_editor.php'\">Edit Model</button>\n";
	echo "<button onclick=\"document.location='simulator.php';\">Simulator</button>\n";
	echo "<button onclick=\"document.location='debugger.php';\">Debugger</button>\n";
	echo "<button onclick=\"window.open('ss_init_marking.php', 'State Space');\">Generate State Space</button>";
	echo "<button onclick=\"document.location='query.php'\"> Query Editor </button>\n";
	echo "<button onclick=\"document.location='query_res.php'\"> Query Results </button>\n";
	echo "<button onclick=\"document.location='code_gen.php'\">Generate C Code</button>\n";
	echo "<button onclick=\"document.location='vhdl_gen.php'\">Synthesize VHDL Code</button>\n";
	//echo "<button onclick=\"document.location='ml_slnk_gen.php'\">Simulink System Block</button><br />\n";
	echo "<button onclick=\"document.location='download.php'\"> Download Model File </button>\n";
	echo "<button onclick=\"document.location='export_snoopy.php?lang=C'\"> Export Snoopy/C </button>\n";
	echo "<button onclick=\"document.location='export_snoopy.php?lang=VHDL'\"> Export Snoopy/VHDL </button>\n";
	echo "<button onclick=\"document.location='decompose_gals.php'\"> Decompose GALS </button>\n";
	echo "<button onclick=\"window.open('hippo.php','HIPPO');\"> HIPPO </button>\n";
	echo "<button onclick=\"document.location='manage-files.php'\"> Model List </button>\n";
	echo "<button onclick=\"window.open('../iopt_usermanual.pdf','Manual');\"> User Manual </button></p>\n";
    }
?>

<form method="post" action="index.php" enctype="multipart/form-data">
    <table border="1" width="90%">
	<tr>
	    <th colspan=2> Model actions: </th>
	</tr>
	<tr>
	    <td> Start new model: <input type="text" size="50%" name="net_name" /></td>
	    <td><input type="submit" name ="create" value="Create" /></td>
	</tr>
	<tr>
	    <td> Upload model file: <input type="file" size="50%" name="pnml_file" /></td>
	    <td><input type="submit" name="upload" value="Upload" /></td>
	</tr>
    </table>
</form>

<p> Important note: IOPT-Tools require the latest Browser versions: Firefox >= 10, Chrome >= 12, Safari, Opera </p>

</center>

</body>
</html>
