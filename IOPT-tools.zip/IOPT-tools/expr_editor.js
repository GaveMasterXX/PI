// PNML Editor
// 2012 (C) GRES Research Group - FCT/UNL - Uninova


var code_iframe = null;
var expr_doc = null;
var exprXsltProcessor = null;
var top_expression = null;
var expression = null;
var operation = null;
var places = null;
var input_signals = null;
var output_signals = null;
var arrays = null;
var op_mode = true;
var counter = 1;
var selected_item = null;


function startup()
{
    counter = 1;
    expr_doc = document.implementation.createDocument("","expr-doc",null);
    putExpression( parent.getEditExpression() );
    expr_doc.documentElement.appendChild( top_expression );
    expression = top_expression;
    expression.setAttribute( "selected", "true" );

    var xsl=loadXMLDoc("xsl/show-expr.xslt");
    exprXsltProcessor = new XSLTProcessor();
    exprXsltProcessor.importStylesheet(xsl);
    places = null;
    input_signals = null;
    output_signals = null;
    arrays = null;
    selected_item = null;
    fillNetData(
       parent.getPlaceList(),
       parent.getSignalList("input"),
       parent.getSignalList("output"),
       parent.getArrayList()
    );

    setOperandMode( top_expression.firstChild == null );
    window.focus();

    code_iframe = document.getElementById("code").contentDocument;

    document.forms[0].paste.disabled = (parent.getBackupExpr() == null);
    showExpression();
}


function loadXMLDoc( dname )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Web browser does not support XMLHttpRequest." );
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}


function removeTextNodes( node )
{
    var children = node.childNodes;
    for( var i = children.length-1; i >= 0; --i ) {
        if( children[i].nodeType == Node.TEXT_NODE )
	    node.removeChild( children[i] );
	else removeTextNodes( children[i] );
    }
}



function putExpression( expr )
{
     if( top_expression != null )
         top_expression.parentNode.removeChild( top_expression );
     if( expr != null ) top_expression = expr.cloneNode( true );
     else top_expression = expr_doc.createElement( "expression" );

     removeTextNodes( top_expression );

     expr_doc.documentElement.appendChild( top_expression );
     top_expression.setAttribute( "selected", "true" );
     counter = 1;
     var items = top_expression.getElementsByTagName( "*" );
     for( var i = 0; i < items.length; ++i ) {
	 if( items[i].nodeName != "expression" )
	     items[i].setAttribute( "seq", counter++ );
     }
}



function getExpression()
{
     expression.removeAttribute( "selected" );
     var res = top_expression.cloneNode( true );
     expression.setAttribute( "selected", "true" );
     return res;
}



function showExpression()
{
    code_iframe.removeChild( code_iframe.lastChild );
    var res = exprXsltProcessor.transformToDocument( expr_doc );
    code_iframe.appendChild( res.documentElement );

    if( selected_item != null ) {
        var sel_id = Number(selected_item.getAttribute( "seq" ));
        var items = code_iframe.getElementsByTagName( "code" );
	for( var i = 0; i < items.length; ++i ) {
	    if( items[i].getAttribute( "id" ) == "cursor" ) {
		items[i].style.color = "black";
		items[i].style.textDecoration = "none";
	    }
	    else if( Number(items[i].getAttribute( "seq" )) == sel_id )
		items[i].style.color = "red";
	}
    }
}



function fillNetData( plist, ilist, olist, alist )
{
    var i;

    places = plist;
    input_signals = ilist;
    output_signals = olist;
    arrays = alist;

    var pl = document.forms[0].places;
    pl.options.add( new Option( "Places" , "" ) );
    for( i = 0; i < places.length; ++i ) {
         var id = places[i].getAttribute( "id" );
	 var name = places[i].getElementsByTagName( "name" )[0];
	 var tname = name.getElementsByTagName( "text" )[0].textContent;
         pl.options.add( new Option( tname + " " + id, id ) );
    }

    var is = document.forms[0].inputs;
    is.options.add( new Option( "Inputs" , "" ) );
    for( i = 0; i < ilist.length; ++i ) {
         is.options.add( new Option( ilist[i], ilist[i] ) );
    }

    var os = document.forms[0].outputs;
    os.options.add( new Option( "Outputs" , "" ) );
    for( i = 0; i < olist.length; ++i ) {
         os.options.add( new Option( olist[i], olist[i] ) );
    }

    var ai = document.forms[0].arrays;
    ai.options.add( new Option( "Arrays/Tables" , "" ) );
    if( alist != null ) for( i = 0; i < alist.length; ++i ) {
         var idx1 = arrays[i].getAttribute( "index1" );
	 if( idx1 == "" || idx1 =="-" ) continue;
         var idx2 = arrays[i].getAttribute( "index2" );
	 var id = arrays[i].getAttribute( "id" );
	 var name = id + "[" + idx1 + "]";
	 if( idx2 > "" && idx2 != "-" ) name += "[" + idx2 + "]";
         ai.options.add( new Option( name, id ) );
    }

    // Update place names (in case the name has changed)
    var operands = top_expression.getElementsByTagName( "operand" );
    for( i = 0; i < operands.length; ++i ) {
        if( operands[i].getAttribute( "type" ) != "place-marking" ) continue;
	var id = operands[i].getAttribute( "idRef" );
	for( j = 0; j < pl.options.length; ++j ) {
	    if( pl.options[j].value == id ) {
		operands[i].setAttribute( "name", pl.options[j].text );
		break;
	    }
	}
    }

    // Update array names (in case the index has changed)
    var operands = top_expression.getElementsByTagName( "operand" );
    for( i = 0; i < operands.length; ++i ) {
        if( operands[i].getAttribute( "type" ) != "array-item" ) continue;
	var id = operands[i].getAttribute( "idRef" );
	for( j = 0; j < ai.options.length; ++j ) {
	    if( ai.options[j].value == id ) {
		operands[i].setAttribute( "name", ai.options[j].text );
		break;
	    }
	}
	for( j = 0; j < arrays.length; ++j ) {
	    if( arrays[j].getAttribute("id") == id ) {
		operands[i].setAttribute( "idx1",
		   arrays[j].getAttribute("index1") );
		if( arrays[j].getAttribute("index2") > "" &&
		    arrays[j].getAttribute("index2") != "-" )
		    operands[i].setAttribute( "idx2",
			arrays[j].getAttribute("index2") );
		else operands[i].removeAttribute("idx2");
		break;
	    }
	}
    }
}



function setOperandMode( op )
{
    op_mode = op;
    if( op == false ) operation = null;
    document.forms[0].places.disabled = !op;
    document.forms[0].inputs.disabled = !op;
    document.forms[0].outputs.disabled = !op;
    document.forms[0].arrays.disabled = !op;
    document.forms[0].literals.disabled = !op;
    document.forms[0].numbers.disabled = !op;
    document.forms[0].arithmetic.disabled = op;
    document.forms[0].compare.disabled = op;
    document.forms[0].logic.disabled = op;
    document.forms[0].subexpr.disabled = (selected_item != null);
    document.forms[0].save.disabled = (operation != null) ||
				      (expression != top_expression &&
				       expression.firstChild == null)
    document.forms[0].erase.disabled = (top_expression.firstChild == null);
}


function selectPlace( sel )
{
    if( sel.value == "" ) return;

    if( selected_item != null ) {
        if( selected_item.nodeName == "operand" ) {
	    selected_item.setAttribute( "type", "place-marking" );
	    selected_item.setAttribute( "idRef", sel.value );
	    selected_item.setAttribute( "name",
				sel.options[sel.options.selectedIndex].text );
	}
    }
    else {
	var place = expr_doc.createElement( "operand" );
	place.setAttribute( "type", "place-marking" );
	place.setAttribute( "idRef", sel.value );
	place.setAttribute( "name", 
			    sel.options[sel.options.selectedIndex].text );
	place.setAttribute( "seq", counter++ );
	if( operation != null ) operation.appendChild( place );
	else expression.appendChild( place );
	setOperandMode( false );
    }
    sel.value = "";
    showExpression();
}


function selectInput( sel )
{
    if( sel.value == "" ) return;

    if( selected_item != null ) {
        if( selected_item.nodeName == "operand" ) {
	    selected_item.setAttribute( "type", "input-signal" );
	    selected_item.setAttribute( "idRef", sel.value );
	}
    }
    else {
	var input = expr_doc.createElement( "operand" );
	input.setAttribute( "type", "input-signal" );
	input.setAttribute( "idRef", sel.value );
	input.setAttribute( "seq", counter++ );
	if( operation != null ) operation.appendChild( input );
	else expression.appendChild( input );
	setOperandMode( false );
    }
    showExpression();
    sel.value = "";
}


function selectOutput( sel )
{
    if( sel.value == "" ) return;

    if( selected_item != null ) {
        if( selected_item.nodeName == "operand" ) {
	    selected_item.setAttribute( "type", "output-signal" );
	    selected_item.setAttribute( "idRef", sel.value );
	}
    }
    else {
	var output = expr_doc.createElement( "operand" );
	output.setAttribute( "type", "output-signal" );
	output.setAttribute( "idRef", sel.value );
	output.setAttribute( "seq", counter++ );
	if( operation != null ) operation.appendChild( output );
	else expression.appendChild( output );
	setOperandMode( false );
    }
    showExpression();
    sel.value = "";
}


function selectArray( sel )
{
    if( sel.value == "" ) return;

    var idx1 = null;
    var idx2 = null;
    for( var i = 0; i < arrays.length; ++i ) {
        if( arrays[i].getAttribute( "id" ) == sel.value ) {
	    idx1 = arrays[i].getAttribute( "index1" );
	    idx2 = arrays[i].getAttribute( "index2" );
	    if( idx2 == "" || idx2 == "-" ) idx2 = null;
	    break;
	}
    }

    if( selected_item != null ) {
        if( selected_item.nodeName == "operand" ) {
	    selected_item.setAttribute( "type", "array-item" );
	    selected_item.setAttribute( "idRef", sel.value );
	    selected_item.setAttribute( "idx1", idx1 );
	    if( idx2 == null ) selected_item.removeAttribute( "idx2" );
	    else selected_item.setAttribute( "idx2", idx2 );
	}
    }
    else {
	var aitem = expr_doc.createElement( "operand" );
	aitem.setAttribute( "type", "array-item" );
	aitem.setAttribute( "idRef", sel.value );
	aitem.setAttribute( "idx1", idx1 );
	if( idx2 != null ) aitem.setAttribute( "idx2", idx2 );
	aitem.setAttribute( "seq", counter++ );
	if( operation != null ) operation.appendChild( aitem );
	else expression.appendChild( aitem );
	setOperandMode( false );
    }
    showExpression();
    sel.value = "";
}


function selectLiteral( sel )
{
    if( sel.value == "" ) return;

    if( selected_item != null ) {
        if( selected_item.nodeName == "operand" ) {
	    selected_item.setAttribute( "type", "literal" );
	    selected_item.setAttribute( "value", Number(sel.value) );
	    selected_item.removeAttribute( "idRef" );
	}
    }
    else {
	var literal = expr_doc.createElement( "operand" );
	literal.setAttribute( "type", "literal" );
	literal.setAttribute( "value", Number(sel.value) );
	literal.setAttribute( "seq", counter++ );
	if( operation != null ) operation.appendChild( literal );
	else expression.appendChild( literal );
	setOperandMode( false );
    }
    showExpression();
    sel.value = "";
}


function selectOperator( sel )
{
    if( sel.value == "" ) return;

    if( selected_item != null ) {
        if( selected_item.nodeName == "operation" )
	    selected_item.setAttribute( "operator", sel.value );
    }
    else {
	operation = expr_doc.createElement( "operation" );
	operation.setAttribute( "operator", sel.value );
	operation.setAttribute( "seq", counter++ );
	expression.appendChild( operation );
	setOperandMode( true );
    }
    showExpression();
    sel.value = "";
}


function subExpression( sel )
{
    if( sel.value == "" || selected_item != null ) return;

    if( sel.value == "close" ) {
        if( expression != top_expression && expression.childNodes.length > 0 &&
	    operation == null ) {
	    expression.removeAttribute( "selected" );
	    expression = expression.parentNode;
	    if( expression.nodeName == "operation" )
		expression = expression.parentNode;
	    expression.setAttribute( "selected", "true" );
	    setOperandMode( false );
	}
    }
    else if( op_mode ) {
	var subexpr = expr_doc.createElement( "operand" );
	subexpr.setAttribute( "type", "subexpression" );
	if( sel.value == "openinv" )
	   subexpr.setAttribute( "invert", "yes" );
	if( sel.value == "opensym" )
	   subexpr.setAttribute( "symmetric", "yes" );
	subexpr.setAttribute( "seq", counter++ );
	if( operation != null ) operation.appendChild( subexpr );
	else expression.appendChild( subexpr );
	operation = null;
	expression.removeAttribute( "selected" );
	expression = subexpr;
	expression.setAttribute( "selected", "true" );
	setOperandMode( true );
    }

    sel.value = "";
    showExpression();
}


function eraseOp()
{
    if( top_expression.firstChild == null ) return;

    if( selected_item != null ) {
        selected_item = null;
	showExpression();
	return;
    }

    if( expression.firstChild == null ) {
	if( expression != top_expression ) {
	    var up = expression.parentNode;
	    up.removeChild( up.lastChild );
	    if( up.nodeName == "operation" ) {
	        operation = up;
	        expression = up.parentNode;
	    }
	    else expression = up;
	    expression.setAttribute( "selected", "true" );
	    setOperandMode( true );
	}
	else return;
    }
    else {
	if( operation != null ) {
	    expression.removeChild( operation );
	    setOperandMode( false );
	}
	else {
	    var last = expression.lastChild;

	    if( last.nodeName == "operand" &&
	        last.getAttribute("type") == "subexpression" ) {
		// Enter inside closed parenthesis (without operation)
		expression.removeAttribute( "selected" );
		expression = last.firstChild;
		expression.setAttribute( "selected", "true" );
		setOperandMode( false );
	    }
	    else if( last.nodeName == "operation" &&
	             last.firstChild != null &&
		     last.firstChild.getAttribute("type") == "subexpression" ) {
		// Enter inside closed parenthesis (with operation)
		expression.removeAttribute( "selected" );
		expression = last.firstChild.firstChild;
		expression.setAttribute( "selected", "true" );
		setOperandMode( false );
	    }
	    else {
		if( expression.childNodes.length == 1 )
		    expression.removeChild( expression.firstChild );
		else {
		    operation = last;
		    operation.removeChild( operation.firstChild );
		}
		setOperandMode( true );
	    }
	}
    }

    showExpression();
}


function saveExpr()
{
    parent.saveExpression( getExpression() );
}



function copyExpr()
{
    parent.backupExpr( getExpression() );
    document.forms[0].paste.disabled = false;
}


function pasteExpr()
{
    putExpression( parent.getBackupExpr() );
    showExpression();
}


function select( item )
{
    if( item == null ) {
        if( selected_item != null ) {
	    selected_item = null;
	    setOperandMode( operation != null );
	}
    }
    else {
        var sel_seq = Number(item.getAttribute( "seq" ));
	var items = top_expression.getElementsByTagName( "*" );
	for( var i = 0; i < items.length; ++i ) {
	    if( sel_seq == Number(items[i].getAttribute("seq" )) ) {
	        selected_item = items[i];
		break;
	    }
	}

	setOperandMode( selected_item.nodeName != "operation" );
    }

    showExpression();
}


