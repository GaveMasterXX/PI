// PNML Editor - Clipboard management
// 2012 (C) GRES Research Group - FCT/UNL - Uninova


var viewarea = null;
var view_doc = null;
var iframe_elem = null;
var clipXsltProcessor = null;
var clipboardDoc = null;
var netNode = null;
var statusbar = null;


function startClipboard()
{
    clipboardDoc = loadXMLDoc("empty.pnml");
    netNode = clipboardDoc.getElementsByTagName( "net" )[0];
    view_doc = document.getElementById("viewarea").contentDocument;
    view_elem = view_doc.documentElement;
    var xsl=loadXMLDoc("xsl/iopt2svg.xsl");
    clipXsltProcessor = new XSLTProcessor();
    clipXsltProcessor.importStylesheet(xsl);
    netNode.setAttribute( "id", "clipboard" );
    statusbar = document.getElementById("clipboard_status");
    var clipboard_data = window.opener.clipboard_data;
    if( clipboard_data.length > 0 ) clipboardPut( clipboard_data );
}



function drawClipboard()
{
    var nodes = view_elem.childNodes;
    for( var i = nodes.length-1; i >= 0; i-- ) {
        view_elem.removeChild(nodes[i]);
    }

    // code for Mozilla, Firefox, Opera, etc.
    if (document.implementation && document.implementation.createDocument)
    {
	var res = clipXsltProcessor.transformToFragment(clipboardDoc,view_doc);
	view_elem.appendChild( res );
    }
}



function loadXMLDoc( dname )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Web browser does not support XMLHttpRequest." );
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}


function saveXMLDoc( dname, doc )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Web browser does not support XMLHttpRequest." );
    xhttp.open( "POST", dname, false );
    xhttp.setRequestHeader("Content-Type", "text/xml"); 
    xhttp.send(doc);
    return xhttp.status;
}


function clipboardPut( nodes ) 
{
    var i;
    var old = netNode.childNodes;
    for( i = old.length-1; i >= 0 ; --i ) netNode.removeChild( old[i] );

    var inputNode = clipboardDoc.createElement("input");
    var outputNode = clipboardDoc.createElement("output" );
    netNode.appendChild( inputNode );
    netNode.appendChild( outputNode );
    
    for( i = 0; i < nodes.length; ++i ) {
        if( nodes[i].parentNode.nodeName == 'input' )
	   inputNode.appendChild( nodes[i].cloneNode( true ) );
        else if( nodes[i].parentNode.nodeName == 'output' )
	   outputNode.appendChild( nodes[i].cloneNode( true ) );
	else netNode.appendChild( nodes[i].cloneNode( true ) );
    }

    statusbar.value = "Content: " + nodes.length + " nodes/arcs.";
    drawClipboard();
}


function clipboardGet()
{
    return netNode.childNodes;
}


function saveClipboard()
{
    saveXMLDoc( "save_clipboard.php", clipboardDoc );
    statusbar.value = "Saved to saved_clipboard.pnml";
}



function openSaved()
{
    clipboardDoc = loadXMLDoc( "get_clipboard.php" );
    netNode = clipboardDoc.getElementsByTagName( "net" )[0];
    drawClipboard();
    statusbar.value = "Read saved_clipboard.pnml";
}

