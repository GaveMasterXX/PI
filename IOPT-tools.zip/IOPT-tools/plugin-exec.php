<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = $_SESSION["pnml_file"];
        $model_file = $user_dir . "/files/" . $out_file;
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) {
	   header( "Invalid file name", true, 403 );
	   exit();
	}
    }
    else {
        header( "No PNML Document", true, 404 );
        exit();
    }

    $plugin_name = addslashes(str_replace( "..", "__", $_GET["plugin"]));
    $plugin_file = "plugins/" . $plugin_name;
    $in_file  = $model_file . "_in_" . $plugin_name;
    $out_file = $model_file . "_out_" . $plugin_name;

    if( !file_exists( $plugin_file ) ) {
        header( "Plugin $plugin_name not found", true, 404 );
        exit();
    }

    if( !file_exists( $in_file ) ) {
        header( "Plugin input data not found", true, 404 );
        exit();
    }

    $plugDoc = new DOMDocument();
    $plugDoc->load($plugin_file);
    $xpath = new DOMXPath( $plugDoc );
    $code = $xpath->query( "/pnml-editor-plugin/code" );
    if( $code->length != 1 ) {
        header( "Invalid plugin $plugin_name code path", true, 403 );
        exit();
    }
    $path = $code->item(0)->getAttribute( "path" );
    unset( $xpath );
    unset( $plugDoc );

    if( file_exists( $out_file ) ) unlink( $out_file );

    $last = exec( "$path $in_file $out_file", $output, $res );
    unlink( $in_file );

    if( $res != 0 ) {
	if( file_exists( $out_file ) ) unlink( $out_file );
	header( "Error executing plugin ($last/$res)", true, 500 );
	exit();
    }

    header("Content-type: text/xml");
    readfile( $out_file );
    unlink( $out_file );
?>

