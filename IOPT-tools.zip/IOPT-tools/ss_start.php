<?php
    // Author: 2011-2013 (C) Fernando J. G. Pereira

    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    $file_list = array(
	array("net_types.h",    "xsl/iopt2c_inc.xsl",        ""),
	array("net_functions.c","xsl/iopt2c_func.xsl",       "net_types.h"),
	array("ss_types.h",     "xsl/iopt2ss_inc.xsl",       "net_types.h"),
	array("ss_exec_step.c", "xsl/iopt2ss_exec.xsl",      "ss_types.h"),
	array("ss_hashtable.c", "xsl/iopt2ss_hashtable.xsl", "ss_types.h"),
	array("ss_compat.c",    "xsl/iopt2ss_compat.xsl",    "ss_types.h"),
	array("ss_main.c",      "xsl/iopt2ss_main.xsl",      "ss_types.h")
    );

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $dir = $user_dir . "/ss_gen/" . $out_file;
    if( !file_exists($dir) )  mkdir( $dir );
    copy( "ssMakefile", $dir . "/Makefile" );

    $progress_file = $dir . "/progress.txt";
    if( file_exists( $progress_file ) ) {
	$proc = intval( file($progress_file)[0] );
	if( $proc > 0 ) posix_kill( $proc, 9 );
    }

    $pnmlDocInit = new DOMDocument();
    $pnmlDocClean = new DOMDocument();
    $pnmlDoc = new DOMDocument();

    $pnmlDocInit->load($pnml_file);

    //aplicar a cleanIDs.xsl para remver simbolos de pontuacao dos IDs/nomes 
    $xslClean = new DOMDocument;
    $xslClean->load('xsl/cleanIDs.xsl');
    $procClean = new XSLTProcessor;
    $procClean->importStyleSheet($xslClean); 
    $pnmlDocClean->loadXML( $procClean->transformToXML($pnmlDocInit) );

    //aplicar a replace_acs.xsl e obter o novo pnml
    $xslReplace = new DOMDocument;
    $xslReplace->load('xsl/replace_acs.xsl');
    $procReplace = new XSLTProcessor;
    $procReplace->importStyleSheet($xslReplace); 
    $pnmlDoc->loadXML(  $procReplace->transformToXML($pnmlDocClean) );

    $xpath = new DOMXPath( $pnmlDoc );
    $num_components = 0;
    $nodelist = $xpath->query( "//pnml/net/transition/timedomain/text" );
    foreach( $nodelist as $node ) {
	if( $node->nodeValue > $num_components )
	    $num_components = $node->nodeValue;
    }

    foreach( $file_list as $item ) {
	$xslDoc = new DOMDocument();
	$xslDoc->load($item[1]);
	$proc = new XSLTProcessor();
	$proc->importStylesheet($xslDoc);
	$proc->setParameter('','inc_file',$item[2]);
	$proc->setParameter('','use_bounds',"0");
	$proc->setParameter('','numComponents',$num_components);
	$res = $proc->transformToURI($pnmlDoc, $dir . "/" . $item[0] );
	unset( $xsldoc );
	unset( $proc );
	if( $res == FALSE ) {
	    echo "<error-msg>Error generating file " . $item[0] . "</error-msg>\n";
	    break;
	}
    }

    $query_file = $user_dir . "/queries/" . $out_file;
    if( !file_exists($query_file) ) copy( "empty_queries.xml", $query_file );

    $net = $xpath->query( "//pnml/net" )->item(0);
    unset( $xpath );
    $net_name = $net->getAttribute( "name" );

    $queryDoc = new DOMDocument();
    $queryDoc->load($query_file);
    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/gen_queries.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','inc_file','ss_types.h');
    $proc->setParameter('','net',$net_name );
    $res = $proc->transformToURI($queryDoc, $dir . "/" . "ss_query.c" );
    unset( $xsldoc );
    unset( $proc );
    unset( $queryDoc );
    if( $res == FALSE ) {
	echo "<error-msg>Error generating file ss_query.cpp </error-msg>\n";
	break;
    }

    $orig_dir = getcwd();
    chmod( $dir, 0777 );
    chdir( $dir );

    $last = exec( "make ss_gen clean", $output, $res );
    if( $res != 0 ) {
        echo "<error-msg>Error compiling state-space generator program ($last/$res)</error-msg>\n";
	die();
    } 

    $cmd = "./ss_gen";
    if( isset($_POST["custom_marking"]) ) {
	$xpath = new DOMXPath( $pnmlDocInit );
	$pnames = $xpath->query( "//pnml/net/place/name/text" );
	foreach( $pnames as $pname ) {
	    $id = $pname->parentNode->parentNode->getAttribute( "id" );
	    $name = "'" . $pname->textContent . "'" ;
	    if( isset($_POST["p_$id"]) ) 
		$cmd = $cmd . " " . $name . " " . $_POST["p_$id"];
	}
    }

    $file_io = array(
	//0 => array( "file", "/dev/null", "r" ),
	1 => array( "file", "ss.xml", "w" ),
	2 => array( "file", "progress.txt", "w" )
    );

    $proc = proc_open( $cmd . "&" , $file_io, $pipes, $dir );
    if( !is_resource($proc) ) 
        die( "Cannot start state space generator pregram !" );
    proc_close( $proc );
    header( "Location: ss_progress.php" );
?>

