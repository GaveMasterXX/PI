<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
        $query_file = $user_dir . "/queries/" . $out_file;
    }
    else die("<p>No PNML Document</p>");

    if( !file_exists($query_file) ) {
        $file = fopen( $query_file, "w" );
	if( $file == null ) die( "Cannot create queries file\n" );
	fprintf( $file, "<?xml version='1.0' encoding='utf-8' ?>\n" );
	fprintf( $file, "<?xml-stylesheet href='xsl/show_queries.xsl' type='text/xsl' ?>\n" );
	fprintf( $file, "<queries>\n" );
	for( $i = 1; $i <= 32; ++$i ) fprintf( $file, "  <query id='$i' reach_state='-1' />\n" );
	fprintf( $file, "</queries>\n" );
	fclose( $file );
    }

    $_SESSION["read_queries_time"] = filemtime( $query_file );

    header("Content-type: text/xml");
    readfile( $query_file );
?>
