<?php
    // Author: 2014 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    header('Content-Type: application/javascript');

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $tdset = array();
    $td_cnt = 0;
    $xpath = new DOMXPath( $pnmlDoc );
    $tdlist = $xpath->query( "//pnml/net/place/timedomain/text" );
    foreach( $tdlist as $tdn ) {
        $td = $tdn->textContent;
        if( !isset($tdset[$td]) ) {
	    $tdset[$td] = true;
	    ++$td_cnt;
	}
    }
    if( $td_cnt > 1 ) {
	//aplicar a replace_acs.xsl e obter o novo pnml
	$xslReplace = new DOMDocument;
	$xslReplace->load('xsl/replace_acs_simul.xsl');
	$procReplace = new XSLTProcessor;
	$procReplace->importStyleSheet($xslReplace); 
	$trPnmlDoc = new DOMDocument();
	$trPnmlDoc->loadXML(  $procReplace->transformToXML($pnmlDoc) );
	unset( $pnmlDoc );
	$pnmlDoc = $trPnmlDoc;
    }

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2js.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);

    echo $proc->transformToXML($pnmlDoc);
?>
