<?php
    // Author: 2013 (C) Fernando J. G. Pereira

    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $dir = $user_dir . "/ss_gen/" . $out_file;
    if( !file_exists($dir) ) {
	header( "Location: ss_init_marking.php" );
	exit();
    }

    $orig_dir = getcwd();
    chdir( $dir );
  
    if( !file_exists("progress.txt") ) {
	header( "Location: ss_init_marking.php" );
	exit();
    }

    $done = false;
    $size = 0;
    $proc = intval( file("progress.txt")[0] );
    if( $proc > 0 ) $done = !posix_kill( $proc, 10 );

    if( $done ) $size = filesize("ss.xml");
    else usleep( 25000 );

    if( file_exists( "query_results.txt" ) ) {
	if( !$done ) sleep( 1 );
	$query_file = $user_dir . "/queries/" . $out_file . ".res";
	rename( "query_results.txt", $orig_dir . "/" . $query_file );
    }
?>

<HTML>
<HEAD>
    <title> State Space Generation Progress </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php if( !$done ) echo "<meta http-equiv='refresh' content='5'>\n"; ?>
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script language="javascript">
function scroll_top()
{
    var log = document.getElementById('log');
    log.scrollTop = log.scrollHeight;
}

function loadXMLDoc( dname )
{
    var xhttp;
    xhttp= new XMLHttpRequest();
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}
</script>
</HEAD>

<?php 
    echo "<BODY onload=\"scroll_top();\"";
    if( $done ) echo " onunload=\"loadXMLDoc('ss_operation.php?Close=1');\"";
    echo ">\n";
    echo "<center>\n";
    echo "<h1>User: " . $_SESSION["username"] .
         " Model: " . $out_file . "</h1>\n";
    if( !$done ) {
	echo "<h2>Calculating State Space - Please Wait</h2>\n";
    }
?>

    <p>&nbsp;</p>
    <form method="get" action="ss_operation.php">
    <p><input type="submit" name="Close" value="Close"> &nbsp;
<?php 
    if( $done ) {
         if( $size < 128*1024 )
	     echo "\t<input type='submit' name='View' value='View Graph'> &nbsp;\n";
         echo "\t<input type='submit' name='Download' value='Download File'>\n";
	 printf( "&nbsp; File size: %.3f Mb\n", $size/1024/1024);
    }
    else echo "Progress: <input type='submit' name='Interrupt' value='Interrupt'>\n";

?>
    </p>
    </form>

    <textarea id="log" type="text" rows="30" cols=120">
<?php
    $output = file("progress.txt" );
    foreach( $output as $line ) echo $line;
?>
    </textarea>
</center>
</BODY>
