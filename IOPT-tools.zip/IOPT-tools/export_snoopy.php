<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
    }
    else die("<p>No PNML Document</p>");

    if( !file_exists($pnml_file) ) die( "<p>File not found.</p>" );

    $tmp_file = $user_dir . "/code_gen/" . $out_file . ".snoopy";

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);
    $xslDoc = new DOMDocument();
    if( $_GET["lang"] == "VHDL" )
         $xslDoc->load("xsl/exportSnoopyVHDL.xsl");
    else $xslDoc->load("xsl/exportSnoopyC.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->transformToURI($pnmlDoc, $tmp_file );
    unset( $xsldoc );
    unset( $proc );

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($pnml_file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
//    header('Content-Length: ' . filesize($pnml_file));
    ob_clean();
    flush();

    $pipe = popen( "xmllint --format '$tmp_file'", "r" );
    while( !feof( $pipe ) ) {
       $ln = fgets( $pipe );
       echo str_replace( "\n", "\r\n", $ln );
    }

    unlink( $tmp_file );
?>
