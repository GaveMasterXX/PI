<?php
    // Author: 2014 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();
    if( isset($_SESSION["username"]) ) $user = $_SESSION["username"];
    else {
	header( "Location: login.php" );
	exit();
    }

    if( isset( $_SESSION["pnml_file"] ) ) $pnml_file=$_SESSION["pnml_file"];
    else {
	header( "Location: index.php" );
	exit();
    }

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    $filename = $user_dir . "/files/" . $pnml_file;

    $fields = array(
	'model' => $pnml_file,
	'user' => $user,
	'file' => file_get_contents( $filename )
    );

    $options = array(
	'http' => array(
	    'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
	    'method'  => 'POST',
	    'content' => http_build_query($fields),
	),
    );

    $url = "http://fa.iie.uz.zgora.pl/net/load/";
//    $url = "http://gres.uninova.pt/~fjp/iopt-tools/test-upload.php";

    $context  = stream_context_create($options);
    $result = file_get_contents( $url, false, $context );
    echo "<base href=\"http://fa.iie.uz.zgora.pl/net/load/\" />\n";
    echo($result);
?>
