<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $dir = $user_dir . "/code_gen/" . $out_file;
    if( !file_exists($dir) ) mkdir( $dir );

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $tdset = array();
    $td_cnt = 0;
    $xpath = new DOMXPath( $pnmlDoc );
    $tdlist = $xpath->query( "//pnml/net/place/timedomain/text" );
    foreach( $tdlist as $tdn ) {
        $td = $tdn->textContent;
        if( !isset($tdset[$td]) ) {
	    $tdset[$td] = true;
	    ++$td_cnt;
	}
    }
    if( $td_cnt > 1 ) {
        echo( "<p>GALS Model: Please decompose and generate code for each component.</p>" );
	die( "<p><a href='index.php'> Return to model </a></p>" );
    }

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2vhdl.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->transformToURI($pnmlDoc, $dir . "/" . "controller.vhdl" );

    $xslDoc->load("xsl/iopt2vhdl-main.xsl");
    $proc->importStylesheet($xslDoc);
    $proc->transformToURI($pnmlDoc, $dir . "/" . "main.vhdl" );

    $xslDoc->load("xsl/iopt2vhdl-defs.xsl");
    $proc->importStylesheet($xslDoc);
    $proc->transformToURI($pnmlDoc, $dir . "/" . "component_defs.vhdl" );

    unset( $xsldoc );
    unset( $proc );

    $zipname = $user_dir . "/code_gen/" . $out_file . ".zip";
    if( file_exists($zipname) ) unlink( $zipname );
    $zipfile = new ZipArchive();
    $zipfile->open( $zipname, ZIPARCHIVE::CREATE );
    $zipfile->addEmptyDir( $out_file );
    $zipfile->addFile( $dir . "/controller.vhdl", $out_file . "/" . $out_file . "_controller.vhdl" );
    $zipfile->addFile( $dir . "/main.vhdl", $out_file . "/" . $out_file . "_main.vhdl" );
    $zipfile->addFile( $dir . "/component_defs.vhdl", $out_file . "/" . $out_file . "_component_defs.vhdl" );
    $zipfile->close();

    unlink( $dir . "/controller.vhdl"  );
    unlink( $dir . "/component_defs.vhdl"  );
    rmdir( $dir );

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename( $zipname ) );
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize( $zipname ) );
    ob_clean();
    flush();
    readfile( $zipname );
    unlink( $zipname );
?>
