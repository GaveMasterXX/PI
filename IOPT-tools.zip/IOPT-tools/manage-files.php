<?php
   // Author: 2011-2013 (C) Fernando J. G. Pereira

   header("Pragma: no-cache");
   session_start();

   if( isset($_SESSION["username"]) ) $user = $_SESSION["username"];
   else {
	header( "Location: login.php" );
	exit();
   }
   if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
   else $user_dir = ".";

   if( isset( $_GET["deleteFile"] ) ) {
        $filename = $user_dir . "/files/" . 
		    addslashes(str_replace( "..", "--", $_GET["deleteFile"] ));
	$lastdel = $user_dir . "/files/#last_deleted";
	unlink( $lastdel );
	rename( $filename, $lastdel );
   }
   else if( isset($_GET["renameFile"]) && isset($_GET["newName"]) ) {
        $filename = $user_dir . "/files/" .
		    addslashes(str_replace( "..", "--", $_GET["renameFile"] ));
        $newname = $user_dir . "/files/" . 
		    addslashes(str_replace( "..", "--", $_GET["newName"] ) );
	if( !file_exists( $newname ) ) rename( $filename, $newname );
   }
   else if( isset($_GET["duplicateFile"]) && isset($_GET["newName"]) ) {
        $filename = $user_dir . "/files/" .
		    addslashes(str_replace( "..", "--", $_GET["duplicateFile"] ));
        $newname = $user_dir . "/files/" . 
		    addslashes(str_replace( "..", "--", $_GET["newName"] ) );
	if( !file_exists( $newname ) ) copy( $filename, $newname );
   }

   $files = array();

   $i = 0;
   $ent = opendir( $user_dir . "/files" );
   while( $file = readdir( $ent ) ) {
	if( $file[0] != '.' && $file != 'CVS') {
	      $files[$i++] = $file;
	}
   }
   closedir( $ent );

   if( $i < 1 ) {
	header( "Location: index.php" );
	exit( 0 );
   }

   natcasesort( $files );
?>

<html>
<head>
    <title>IOPT Tools</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script language="javascript">

function deleteFile()
{
    var files = document.getElementById( "pnml_file" );
    if( files.selectedIndex < 0 ) return;
    
    var filename = files.options[files.selectedIndex].value;

    if( confirm( "Delete file " + filename + " ?" ) ) {
         document.location.href = "manage-files.php?deleteFile=" + 
	                          encodeURIComponent(filename);
    }
}


function renameFile()
{
    var files = document.getElementById( "pnml_file" );
    if( files.selectedIndex < 0 ) return;
    
    var filename = files.options[files.selectedIndex].value;

    var newname =  prompt( "Rename file " + filename + " ?", filename );
    if( newname == null || newname == filename ) return;

    document.location.href = "manage-files.php?renameFile=" + 
			      encodeURIComponent(filename) +
			      "&newName=" +
			      encodeURIComponent(newname);
}



function duplicateFile()
{
    var files = document.getElementById( "pnml_file" );
    if( files.selectedIndex < 0 ) return;
    
    var filename = files.options[files.selectedIndex].value;

    var newname =  prompt( "Duplicate file " + filename + " to ?", filename );
    if( newname == null || newname == filename ) return;

    document.location.href = "manage-files.php?duplicateFile=" + 
			      encodeURIComponent(filename) +
			      "&newName=" +
			      encodeURIComponent(newname);
}



function showModel( evt )
{
    var frm = document.getElementById( "show_model" );
    frm.src = "show_model.php?model=" +
	      encodeURIComponent(evt.target[evt.target.selectedIndex].value);
}

</script>

</head>

<body>
<center>
<h2>IOPT Tools <?php echo "($user)" ?></h2>
<form method="post" action=index.php>
<table width="90%" height="80%" border="1">
<tr>
<td align="center" width="25%">
<p>Available files: </p>
<select id="pnml_file" name="pnml_file" size='20' onchange="showModel(event);">
<?php
   foreach( $files as $file ) {
       echo "<option value='$file'> $file </option>\n";
   }
?>
</select>
<td align="center">
    <iframe id="show_model" width="100%" height="100%" src="background.svg" scrolling="no"></iframe>
</td>
</td>
</tr>
<tr height="6%"><td align="center" colspan="2">
<input type="submit" name="open" value="Open File" />
<input type="button" name="delete" value="Delete File" onclick="deleteFile()"/>
<input type="button" name="rename" value="Rename File" onclick="renameFile()"/>
<input type="button" name="duplicate" value="Duplicate File" onclick="duplicateFile()"/>
<input type="button" name="chg_pass" value="Download Backup" onclick="document.location.href='backup_models.php';" />
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<input type="submit" name="logout" value="Logout" />
<input type="button" name="chg_pass" value="Change Password" onclick="document.location.href='change_pass.php';" />
</td></tr>
</table>
</form>
<p> Important note: IOPT-Tools require the latest Browser versions: Firefox >= 10, Chrome >= 12, Safari, Opera <br/>
For information about the tools please download the <a href="../iopt_usermanual.pdf" target="_new"> User Manual </a>.</p>
</center>
</body>
</html>
