<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) {
	     header( "Invalid file name", true, 403 );
	     exit();
	}
        $query_file = $user_dir . "/queries/" . $out_file;
    }
    else {
        header( "<p>No PNML Document</p>", true, 404 );
	exit();
    }

    $read_queries_time = $_SESSION["read_queries_time"];
    if( file_exists( $query_file ) &&
        filemtime( $query_file ) > $read_queries_time ) {
        header( "<p>File changed since open</p>", true, 409 );
        exit();
    }

    unlink( $query_file );
    $file = fopen( $query_file, "w" );
    fwrite( $file, $HTTP_RAW_POST_DATA );
    fclose( $file );

    $_SESSION["read_queries_time"] = filemtime( $query_file );
?>
