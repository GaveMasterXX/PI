<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = $_SESSION["pnml_file"];
        $model_file = $user_dir . "/files/" . $out_file;
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    clearstatcache();
    $_SESSION["open_time"] = filemtime( $model_file );

    header("Content-type: text/xml");
    readfile( $model_file );
?>
