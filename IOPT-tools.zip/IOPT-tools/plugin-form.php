<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
    }
    else die("<p>No Document - please check if your browser has cookie support enabled.</p>");

    if( !isset($_GET["plugin"]) ) die( "<p>Error: No plugin.</p>" );
    $plugin_name = addslashes(str_replace( "..", "__", $_GET["plugin"]));

    header("Pragma: no-cache");

    $xslDoc = new DOMDocument();
    $xslDoc->load("plugins/show-plugin-params.xsl");
    $form = new DOMDocument();
    $form->load("plugins/" . $plugin_name );

    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);

    echo $proc->transformToXML($form);
?>
