<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = $_SESSION["pnml_file"];
        $model_file = $user_dir . "/files/" . $out_file;
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) {
	   header( "Invalid file name", true, 403 );
	   exit();
	}
    }
    else {
        header( "<p>No PNML Document</p>", true, 404 );
        exit();
    }

    $plugin_name = addslashes(str_replace( "..", "__", $_GET["plugin"]));
    $plug_file = $model_file . "_in_" . $plugin_name;

    if( file_exists( $plug_file ) ) unlink( $plug_file );
    $file = popen( "xmllint --format --output '$plug_file' -", "w" );
    if( $file == NULL ) {
	header( "<p>Error writing document</p>", true, 403 );
	exit();
    }
    fwrite( $file, $HTTP_RAW_POST_DATA );
    fclose( $file );

?>

