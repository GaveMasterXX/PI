<?php
    // Author: 2013 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $xpath = new DOMXPath( $pnmlDoc );

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/decomposegals.xsl");
    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);

    echo "<HTML>\n";
    echo "<HEAD>\n";
    echo "<TITLE> IOPT Decompose Time domains </TITLE>\n";
    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n";
    echo "<link href='../css/style.css' rel='stylesheet' type='text/css' media='screen' />\n";
    echo "</HEAD>\n";
    echo "<BODY>\n";

    $model = basename( $_SESSION["pnml_file"], ".pnml" );

    echo "<H1> IOPT $model - Decompose Time domains </H1>\n";
    echo "<P> Time-domain component models created: </P>\n";

    $tdset = array();

    echo "<list>\n";
    $tdlist = $xpath->query( "//pnml/net/*/timedomain/text" );
    foreach( $tdlist as $tdn ) {
        $td = $tdn->textContent;
        if( isset($tdset[$td]) ) continue;
        $tdset[$td] = true;
	$comp = $model . "_TD-" . $td;
	echo "<li> Component model: $comp </li>\n";
	$proc->setParameter('','td', $td);
	$res = $proc->transformToURI(
	    $pnmlDoc,
	    $user_dir . "/files/" . $model . "_TD-" . $td . ".pnml"
	);
	if( $res == FALSE ) die( "Error generating $comp\n" );
    }
    echo "</list>\n";

    echo "<p><a href='index.php'> Return to model </a></p>\n";

    echo "</BODY>\n";
    echo "</HTML>\n";

    unset( $xsldoc );
    unset( $proc );
    unset( $queryDoc );
    unset( $pnmlDoc );
?>
