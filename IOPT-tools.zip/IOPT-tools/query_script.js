// IOPT Tools
// Author: 2011 (C) Fernando J. G. Pereira

var query = new Array();
var exp_oper = 0;
var level = 0;

var last_query = new Array();
var last_exp_oper = 0;
var last_level = 0;

var query_text = null;
var queries_xmldoc = null;
var selected_query = 1;
var changed = false;
var valid = false;



function loadXMLDoc( dname )
{
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else xhttp= new ActiveXObject("Microsoft.XMLHTTP");
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}


function saveXMLDoc( dname, doc )
{
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else xhttp= new ActiveXObject("Microsoft.XMLHTTP");
    xhttp.open( "POST", dname, false );
    xhttp.setRequestHeader("Content-Type", "text/xml"); 
    xhttp.send(doc);
    return xhttp.status;
}


function backup()
{
    last_query = query.slice(0);
    last_exp_oper = exp_oper;
    last_level = level;
    changed = true;
}



function init()
{
    query_text = document.getElementById("query_str");
    queries_xmldoc = loadXMLDoc( "get_queries.php" );
    clear_all();
    changed = false;
    open_query( 1 );
}



function add_place( place )
{
    if( exp_oper == 0 ) {
        backup();
	query.push( new Array('place', place.value, place.options[place.selectedIndex].text) );
	exp_oper = 1;
	displayQuery();
    }
    place.value = "";
}



function add_transition( trans )
{
    if( exp_oper == 0 ) {
        backup();
	query.push( new Array( 'transition', trans.value, trans.options[trans.selectedIndex].text) );
	exp_oper = 1;
	displayQuery();
    }
    trans.value = "";
}



function add_signal( sig )
{
    if( exp_oper == 0 ) {
        backup();
	query.push( new Array('signal', sig.value, sig.options[sig.selectedIndex].text) );
	exp_oper = 1;
	displayQuery();
    }
    sig.value = "";
}



function add_logic( oper )
{
    if( (oper.value == " !") != (exp_oper == 1) ) {
        backup();
	query.push( new Array('logic', oper.value, oper.options[oper.selectedIndex].text) );
	exp_oper = 0;
	displayQuery();
    }
    oper.value = "";
}



function add_math( oper )
{
    if( exp_oper == 1 ) {
        backup();
	query.push( new Array('math', oper.value, oper.options[oper.selectedIndex].text) );
	exp_oper = 0;
	displayQuery();
    }
    oper.value = "";
}



function add_comparation( oper )
{
    if( exp_oper == 1 ) {
        backup();
	query.push( new Array('cmp', oper.value, oper.options[oper.selectedIndex].text) );
	exp_oper = 0;
	displayQuery();
    }
    oper.value = "";
}



function add_subexpr( oper )
{
    if( exp_oper == 0 && oper.value == '(' && level < 10 ) {
        backup();
	query.push( new Array('subexpr', oper.value, oper.options[oper.selectedIndex].text) );
	++level;
	displayQuery();
    }
    else if( exp_oper == 1 && oper.value == ')' && level > 0 ) {
        backup();
	query.push( new Array('subexpr', oper.value, oper.options[oper.selectedIndex].text) );
	--level;
	displayQuery();
    }
    oper.value = "";
}



function add_constant( c )
{
    if( exp_oper == 0 ) {
        backup();
	query.push( new Array('literal', Number(c.value), Number(c.value) ) );
	exp_oper = 1;
	displayQuery();
    }
    c.value = "";
}


function keypress( text, event )
{
    if( event.keyCode == 10 || event.keyCode == 13 ) {
	if( exp_oper == 0 && !isNaN(Number(text.value)) ) {
	    backup();

	    if( text.name == 'const' ) {
		query.push( new Array('literal',
				      Number(text.value), Number(text.value)) );
	    }
	    else if( text.name == 'reach' && query.length < 2 ) {
		query.push( new Array('reach',
				      'state->flag',
				      'REACH('+Number(text.value)+')',
				      Number(text.value)) );
	    }

	    exp_oper = 1;
	    displayQuery();
	}
	text.value = '';
    }
}


function erase()
{
    if( query.length > 0 ) {
        backup();
        if( query[query.length-1][0] == 'subexpr' ) {
	    if( query[query.length-1][1] == 'open' ) --level;
	    else ++level;
	}
        else exp_oper = !exp_oper;
	query.pop();
    }
    displayQuery();
}


function clear_all()
{
    backup();
    query = new Array();
    level = 0;
    exp_oper = 0;
    query_text.value = "";
    displayQuery();
}


function undo()
{
    if( changed == false ) return;

    aux = query.slice(0);
    query = last_query.slice(0);
    last_query = aux;

    aux = exp_oper;
    exp_oper = last_exp_oper;
    last_exp_oper = aux;

    aux = level;
    level = last_level;
    last_level = aux;

    displayQuery();
}


function displayQuery()
{
    valid = (query.length == 0 || exp_oper == 1 && level == 0 );

    str = "";
    for( i = 0; i < query.length; ++i ) {
        str += query[i][2];
        str += " ";
    }
    query_text.value = str;
    query_text.style.color = valid ? 'green' : 'red';
}


function show_code()
{
    str = "";
    if( query.length == 0 ) str = "Empty Query\n";
    else if( level > 0 ) str = "Unbalanced parentesis\n";

    str += "(";
    for( i = 0; i < query.length; ++i ) str += query[i][1];
    str += ")";
    alert( str );
}



function cancel()
{
    if( changed ) {
        if( confirm( "Save changes ?" ) ) {
	    save();
	    if( changed ) return;
	}
    }
    document.location.href = "index.php";
}



function save()
{
    if( changed == false ) return;

    if( valid == 0 ) {
        alert( "Syntax Error" );
	return;
    }

    query_node =
	queries_xmldoc.getElementsByTagName( "query" )[selected_query-1];
    elem = query_node.childNodes;
    for (i=elem.length-1;i >= 0; i--) query_node.removeChild( elem[i] );

    query_node.setAttribute( "reach_state", "-1" );

    for( i = 0; i < query.length; ++i ) {
        elem = queries_xmldoc.createElement( "elem" );
	elem.setAttribute( "type", query[i][0] );
	elem.setAttribute( "value", query[i][2] );
	elem.setAttribute( "code", query[i][1] );
	if( query[i][0] == 'reach' ) {
	    elem.setAttribute( "state", query[i][3] );
	    query_node.setAttribute( "reach_state", query[i][3] );
	}
	query_node.appendChild( elem );
    }

    ser = new XMLSerializer();
    output = ser.serializeToString( queries_xmldoc );
    var res = saveXMLDoc( "save_queries.php", output );
    if( res == 409 ) alert( "Cannot save: Queries changed by other user." );
    else if( res > 200 ) alert( "Error saving queries" );
    else {
        changed = false;
	iframe = document.getElementById("queries_list").contentDocument;
	iframe.location.reload();
    }
}


function checkRadio()
{
    iframe = document.getElementById("queries_list").contentDocument;
    radio = iframe.getElementById( "query_" +  selected_query );
    radio.checked = true;
}



function open_query( id )
{
    if( changed ) {
        if( confirm( "Save changes ?" ) ) save();
    }

    document.getElementById("selected").value = id;
    selected_query = id;

    query_node =
	queries_xmldoc.getElementsByTagName( "query" )[selected_query-1];

    query = new Array();
    elems = query_node.getElementsByTagName( "elem" );
    for( i = 0; i < elems.length; ++i ) {
	type  = elems[i].getAttribute("type");
        value = elems[i].getAttribute("value");
        code  = elems[i].getAttribute("code");
        state = elems[i].getAttribute("state");
	query.push( new Array(type, code, value, state) );
    }

    level = 0;
    exp_oper = (query.length > 0);
    backup();
    displayQuery();
    changed = false;
}


