// IOPT Remote Debugger
// 2015 (C) GRES Research Group - FCT/UNL - Uninova
// Author: Fernando J. G. Pereira


var password = "";
var model_name = "";
var model_version = "";
var data_channel = null;
var event_stream = null;
var upd_timeout = null;
var trace_mode = null;
var step_time = 0;

var netname = "";
var curr_version = "";
var marking = null;
var input_signals = null;
var prev_input_signals = null;
var input_events = null;
var output_signals = null;
var output_events = null;
var transitions = null;
var breakpoints = null;
var forced_inputs = {};
var place_names = null;
var transition_names = null;

var sim_history = new Array();
var history_pos = 1;

var drawingarea = null;
var drawingwindow = null;
var state_frame = null;
var toolbox = null;
var statusbar = null;
var trace_status = null;
var ip_addr = null;
var history_step = null;
var history_size = null;

var play_interval = null;
var play_delay = 500;

var gr_places = new Array();
var gr_marking = new Array();
var gr_transitions = new Array();
var gr_input_signals = new Array();
var gr_output_signals = new Array();
var gr_input_events = new Array();
var gr_output_events = new Array();
var svg_doc = null;

var scroll_page = false;
var button_pressed = false;
var start_x = 0;
var start_y = 0;

var gui_window = null;

var backupVarArrays = null;
var restoreVarArrays = null;
var calculateInputEvents = null;
var calculateOutputEvents = null;




function sendCommand( cmd, param, callback )
{
    if( ip_addr == null ) return;

    var cmd_url = "http://" + ip_addr + "/" + cmd + "?pw=" +
                  encodeURIComponent(password);
    if( param != null ) {
        for( var i in param ) 
	    cmd_url += "&" + i + "=" + Number(param[i]);
    }

    // console.log( "url=" + cmd_url );

    var xhttp = new XMLHttpRequest ();
    xhttp.open ("GET", cmd_url, true);
    xhttp.onreadystatechange = function() {
        if( xhttp.readyState >=2 && xhttp.status >= 300 ) {
	    alert( "Error " + xhttp.status + " " + xhttp.statusText );
	}
	else if( xhttp.readyState == 4 && xhttp.status == 200 ) {
	   if( callback ) callback( JSON.parse(xhttp.responseText) );
	}
    }
    xhttp.send ("");
}



function loadXMLDoc( dname )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Error: Web Browser does not support XMLHttpRequest !" );
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}


function drawNet()
{
    var nodes = drawingarea.childNodes;
    for( var i=nodes.length-1; i >= 0; i-- ) {
        drawingarea.removeChild( nodes[i] );
    }
    drawingarea.appendChild( svg_doc.documentElement );
}



function receiveEvent( obj )
{
    var i, j, k = 0;

    // Ignore data during history replay/navigation.
    if( play_interval != null || history_pos < sim_history.length ) return;

    // console.log( obj );
    copyArray( prev_input_signals, input_signals );

    for( i in obj.in ) { input_signals[i] = obj.in[i]; ++k }
    for( i in obj.out ) { output_signals[i] = obj.out[i]; ++k }
    for( i in obj.m ) { marking[i] = obj.m[i]; ++k; }
    for( i in transitions ) { 
	if( obj.tf != null && obj.tf[i] != null ) {
	    transitions[i] = obj.tf[i];
	    ++k
	}
	else transitions[i] = 0;
    }

    if( obj.TraceMode ) readTraceMode( obj );
    if( obj.Breakpoint ) alert( "Beakpoint at " + 
                                transition_names[obj.Breakpoint] +
				" (" + obj.Breakpoint + ")" );

    if( obj.steps != null && obj.steps > 0 ) step_time += obj.steps;
    if( k < 1 ) return;

    calculateInputEvents();
    output_events = calculateOutputEvents( transitions );

    saveHistoryStep( step_time );
    step_time = 0;
    if( upd_timeout == null ) upd_timeout = setTimeout( updateState, 40 );
}


function reopenEventStream()
{
    setTimeout( openEventStream, 500 );
}


function openEventStream( obj )
{
    if( event_stream == null && obj != null ) 
        data_channel = "http://" + ip_addr + obj.url;

    if( event_stream != null ) event_stream.close();

    event_stream = new EventSource( data_channel +
                                    "?pw=" + encodeURIComponent(password) );
    event_stream.onmessage = function( evt ) {
        receiveEvent( JSON.parse( evt.data ) );
    }
    event_stream.onerror = function( evt ) {
       event_stream.close();
    };
}


function readTraceMode( obj )
{
    trace_mode = obj.TraceMode;
    trace_status.value = trace_mode;
    trace_status.style.backgroundColor = (trace_mode=='Paused')     ? "red" :
                               (trace_mode=='StepByStep') ? "yellow" : "green";
}



function uploadForcedState()
{
    sendCommand( "SetOutputs", output_signals );
    sendCommand( "SetMarking", marking );
}



function checkModelCompat( obj )
{
    curr_version = document.getElementById("curr_version").value;
    netname = state_frame.getElementById("netname").value;
    if( obj.model != netname ) {
        alert( "Error: Wrong remote model " + obj.model );
	return;
    }
    if( obj.version != curr_version ) {
        alert( "WARNING: Inconsistent model versions " + obj.version +
	       " vs " + curr_version );
    }

    sendCommand( "GetTraceMode", null, readTraceMode );

    closeDialog();
    sendCommand( "GetDataChannel", null, openEventStream );
}



function connectBoard( addr, pass )
{
    ip_addr = addr;
    password = pass;
    sendCommand( "GetModelName", null, checkModelCompat );
    document.getElementById("ip_addr").value = addr;
}



function startDebugger()
{
    state_frame = document.getElementById("state").contentDocument;
    toolbox = document.getElementById("toolbox").contentDocument;
    statusbar = document.getElementById("status");
    trace_status = document.getElementById("trace_status");
    drawingwindow = document.getElementById("drawingarea").contentWindow;
    drawingarea =
        document.getElementById("drawingarea").contentDocument.documentElement;
    toolbox.getElementById("toolbox-title").textContent = "Remote Debugger:";
    var speed = toolbox.getElementById("speed");
    var option = toolbox.createElement("option");
    option.text = "Native";
    option.value = 0;
    speed.add( option );
    speed.disabled = true;
    speed.value = 0;

    openDialog( 400, 300, "connect-board.html" );

    svg_doc = loadXMLDoc( "show_iopt.php?edit=1" );
    drawNet();

    netname = state_frame.getElementById("netname").value;
    history_step = toolbox.getElementById( "history_step" );
    history_size = toolbox.getElementById( "history_size" );

    backupVarArrays = eval( netname + "_backupVarArrays" );
    restoreVarArrays = eval( netname + "_restoreVarArrays" );
    calculateInputEvents = eval( netname + "_generateInputEvents" );
    calculateOutputEvents = eval( netname + "_calculateOutputEvents" );

    marking = eval( netname + "_marking" );
    input_signals = eval( netname + "_input_signals" );
    prev_input_signals = eval( netname + "_prev_input_signals" );
    input_events = eval( netname + "_input_events" );
    output_signals = eval( netname + "_output_signals" );
    output_events = eval( netname + "_output_events" );
    transitions = eval( netname + "_tfired" );
    place_names = eval( netname + "_place_names" );
    transition_names = eval( netname + "_transition_names" );
    resetBreakpoints();
    resetForcedInputs();

    findGraphicObjects();

    resetHistory();
}



function resetBreakpoints()
{
    breakpoints = clone(transitions);
    for( var i in breakpoints ) breakpoints[i] = false;
    sendCommand( "SetBreakpoints" );
}



function resetForcedInputs()
{
    forced_inputs = {};
    sendCommand( "ForceInputs" );
}



function findNode( type, id, elem )
{
    var items = drawingarea.getElementsByTagName( elem );
    for( var i = 0; i < items.length; ++i ) {
        if( items[i].getAttribute( "node-type" ) == type &&
	    items[i].getAttribute( "id" ) == id ) return items[i];
    }
    return null;
}


function findGraphicObjects()
{
    var i, obj;

    for( i in marking ) {
        obj = findNode( "place", i.slice(2), "circle" );
	if( obj != null ) gr_places[i] = obj;
	else {
	    obj = findNode( "place", i.slice(2), "path" );
	    if( obj != null ) gr_places[i] = obj;
	}
	if( obj != null ) {
	    var siblings = obj.parentNode.getElementsByTagName("text");
	    for( var j = 0; j < siblings.length; ++j ) {
	        if( siblings[j].getAttribute("id") == "marking" ) {
	            gr_marking[i] = siblings[j];
		    gr_marking[i].textContent= "";
		    break;
	        }
	    }
	}
    }
    for( i in transitions ) {
        obj = findNode( "transition", i.slice(2), "rect" );
	if( obj != null ) gr_transitions[i] = obj;
    }
    for( i in input_signals ) {
        obj = findNode( "signal", i, "circle" );
	if( obj != null ) gr_input_signals[i] = obj;
    }
    for( i in input_events ) {
        obj = findNode( "event", i, "polygon" );
	if( obj != null ) gr_input_events[i] = obj;
    }
    for( i in output_signals ) {
        obj = findNode( "signal", i, "circle" );
	if( obj != null ) gr_output_signals[i] = obj;
    }
    for( i in output_events ) {
        obj = findNode( "event", i, "polygon" );
	if( obj != null ) gr_output_events[i] = obj;
    }
}


function showStatus( msg )
{
     statusbar.value = msg;
}


function updateState()
{
    for( var i in marking ) {
        var p = state_frame.getElementById( "place_" + i );
	p.value = marking[i];
    }
    for( var i in input_signals ) {
        var p = state_frame.getElementById( "input_" + i );
	if( p.getAttribute("type") == "checkbox" )
	    p.checked = input_signals[i];
	else
	    p.value = input_signals[i];
    }
    for( var i in input_events ) {
        var p = state_frame.getElementById( "event_" + i );
	if( p != null ) p.checked = input_events[i];
    }
    for( var i in output_signals ) {
        var p = state_frame.getElementById( "output_" + i );
	p.value = output_signals[i];
    }

    history_step.value = history_pos;
    history_size.value = sim_history.length;

    updateGraphics();

    if( gui_window != null ) gui_window.updateState();
    upd_timeout = null;
}


function updateGraphics()
{
    var i, ready, enabled;

    for( i in gr_places ) {
	gr_places[i].setAttribute( "fill",
	    marking[i] > 1 ? "magenta" : marking[i] > 0 ? "red" : "yellow" );
    }

    for( i in gr_marking ) {
	if( marking[i] > 0 ) gr_marking[i].textContent = marking[i];
	else gr_marking[i].textContent = "";
    }

    for( i in gr_transitions ) {
        ready = eval( netname + "_t" + i.slice(2) + "_ready()" );
        enabled = eval( netname + "_t" + i.slice(2) + "_enabled( marking )" );
	gr_transitions[i].setAttribute( "fill",
	    ready & enabled ? "green" :
	    enabled ? "orange" :
	    ready ? "yellow" : "cyan" );

	gr_transitions[i].setAttribute( "stroke",
	    breakpoints[i] ? "red" : "black" );
	gr_transitions[i].setAttribute( "stroke-width", 1+breakpoints[i]*2 );
    }

    for( i in gr_input_signals ) {
	gr_input_signals[i].setAttribute( "fill",
	    input_signals[i] > 0 ? "green" : "#60DADA" );
	gr_input_signals[i].setAttribute( "stroke",
	    (forced_inputs[i] != null) ? "red" : "black" );
	gr_input_signals[i].setAttribute( "stroke-width", 
	                                  1+(forced_inputs[i]!=null)*2 );
    }

    for( var i in gr_input_events ) {
	gr_input_events[i].setAttribute( "fill",
	    input_events[i] > 0 ? "green" : "#60DADA" );
    }

    for( i in gr_output_signals ) {
	gr_output_signals[i].setAttribute( "fill",
	    output_signals[i] > 0 ? "red" : "#90D090" );
    }

    for( i in gr_output_events ) {
	gr_output_events[i].setAttribute( "fill",
	    output_events[i] > 0 ? "red" : "#90D090" );
    }
}


function readInputs( redraw, evt )
{
    var p = evt.target;
    var id = p.getAttribute("id").substr( 6 );

    if( history_pos < sim_history.length ) {
        alert( "Cannot force inputs during history navigation !" );
	return;
    }

    if( p.getAttribute("type") == "checkbox" )
	forced_inputs[id] = Number(p.checked);
    else {
	var min = state_frame.getElementById( "min_input_" + id );
	var max = state_frame.getElementById( "max_input_" + id );
	forced_inputs[is] = Number(p.value) | 0;
	if( forced_inputs[id] < Number(min.value) ) {
	    forced_inputs[id] = Number(min.value);
	    p.value = forced_inputs[id];
	}
	else if( forced_inputs[id] > Number(max.value) ) {
		forced_inputs[id] = Number(max.value);
		p.value = forced_inputs[id];
	}
    }
    showStatus( "Force input " + id + " = " + forced_inputs[id] );
    sendCommand( "ForceInputs", forced_inputs );
    /*
    for( var i in input_events ) {
        var p = state_frame.getElementById( "event_" + i );
	if( p != null ) input_events[i] = p.checked;
    }
    */
}


function initialState()
{
    stopRun();
    pauseReplayHistory();
    sendCommand( "Reset", null, reopenEventStream );
    showStatus( "Initial State" );
    updateState();
}


function forceState()
{
    stopRun();
    for( var i in marking ) {
        var p = state_frame.getElementById( "place_" + i );
	marking[i] = Math.floor(Number(p.value));
	if( marking[i] < 0 ) marking[i] = 0;
    }
    resetHistory();
    sendCommand( "SetMarking", marking );
    pauseReplayHistory();
    updateState();
    showStatus( "Force State" );
}


function saveHistoryStep( steps )
{
     if( sim_history.length > 1000000 ) {
         alert( "History size too large. Please clear History" );
	 stopRun();
	 return;
     }

     var tr = clone( transitions );
     if( trace_mode == "Paused" ) tr["Paused"] = 1;

     var state = {
         'n_steps'       : steps,
         'marking'       : clone( marking ),
	 'transitions'   : tr,
         'input_signals' : clone( input_signals ),
         'output_signals': clone( output_signals ),
	 'input_events'  : clone( input_events ),
	 'output_events' : clone( output_events ),
	 'var_arrays'    : backupVarArrays() 
    };

    sim_history.push( state );
    history_pos = sim_history.length;
}


function copyArray( dest, source )
{
    for( var i in source ) dest[i] = source[i];
}


function loadHistoryStep( keep_forced_in )
{
    if( keep_forced_in != true && Object.keys(forced_inputs).length > 0 ) {
        alert( "WARNING: Forced Inputs Released" );
        resetForcedInputs();
	updateGraphics();
    }
    copyArray( marking,        sim_history[history_pos-1].marking );
    copyArray( input_signals,  sim_history[history_pos-1].input_signals );
    copyArray( input_events,   sim_history[history_pos-1].input_events );
    copyArray( output_signals, sim_history[history_pos-1].output_signals );
    copyArray( output_events,  sim_history[history_pos-1].output_events );
    copyArray( transitions,    sim_history[history_pos-1].transitions );
    copyArray( prev_input_signals, input_signals );
    restoreVarArrays( sim_history[history_pos-1].var_arrays );
}


function truncHistory()
{
    while( sim_history.length > history_pos ) sim_history.pop();
    history_step.value = history_pos;
    history_size.value = sim_history.length;
}


function undoStep()
{
    var prev_inputs = {};

    stopRun();
    pauseReplayHistory();

    if( sim_history.length > 1 ) {
	copyArray( prev_inputs,  input_signals );
	sim_history.pop();
	history_pos = sim_history.length;
	loadHistoryStep( true );
	copyArray( input_signals, prev_inputs );
    }
    uploadForcedState();
    updateState();
    showStatus( "Undo 1 Step" );
}



function execStep( nsteps )
{
    pauseReplayHistory();
    sendCommand( "ExecStep", {"n": nsteps} );

    if( history_pos < sim_history.length ) {
        if( confirm( "Truncate history and run from current state ?" ) ) {
	    stopRun();
	    uploadForcedState();
	    truncHistory();
	}
	else endHistory();
    }

    showStatus( "Execute " + nsteps + " Step(s)" );
}



function stopRun()
{
    sendCommand( "Pause", null, readTraceMode );
}


function startRun( step_delay )
{
    pauseReplayHistory();

    if( history_pos < sim_history.length ) {
        if( confirm( "Truncate history and run from current state ?" ) ) {
	    stopRun();
	    uploadForcedState();
	    truncHistory();
	}
	else endHistory();
    }

    sendCommand( "Start", 0, readTraceMode );
}


function rewindHistory()
{
    history_pos = 1;
    if( trace_mode != 'Paused' ) stopRun();
    pauseReplayHistory();
    loadHistoryStep();
    updateState();
    showStatus( "Rewind" );
}


function backHistory()
{
    --history_pos;
    if( history_pos < 1 ) history_pos = 1;
    if( trace_mode != 'Paused' ) stopRun();
    pauseReplayHistory();
    loadHistoryStep();
    updateState();
    showStatus( "Back History" );
}


function forwardHistory()
{
    if( history_pos >= sim_history.length ) return;
    if( trace_mode != 'Paused' ) stopRun();
    ++history_pos;
    copyArray( input_signals, sim_history[history_pos-1].input_signals );
    setTimeout( doForwardHistory, play_delay/2 );
    updateState();
}


function doForwardHistory()
{
    loadHistoryStep();
    updateState();
    if( play_interval != null ) {
        if( history_pos == sim_history.length ) {
	    clearInterval( play_interval );
	    play_interval = null;
	    showStatus( "Replay End" );
	}
    }
    else showStatus( "Forward History" );
}


function endHistory()
{
    pauseReplayHistory();
    history_pos = sim_history.length;
    loadHistoryStep();
    updateState();
    showStatus( "End History" );
}


function resetHistory()
{
    stopRun();
    pauseReplayHistory();

    sim_history = new Array();
    if( event_stream != null ) saveHistoryStep();
    history_pos = sim_history.length;
    updateState();
    showStatus( "Reset History" );
}


function replayHistory( step_delay )
{
    stopRun();
    if( history_pos >= sim_history.length ) rewindHistory();
    play_delay = step_delay;
    if( play_interval ) clearInterval( play_interval );
    play_interval = setInterval( forwardHistory, play_delay );
    showStatus( "Replaying" );
}


function pauseReplayHistory()
{
    if( play_interval != null ) {
        clearInterval( play_interval );
	showStatus( "Pause Replay" );
    }
    play_interval = null;
    play_delay = 500;
}


function historyGoTo( pos )
{
    if( trace_mode != 'Paused' ) stopRun();
    pauseReplayHistory();

    history_pos = pos;
    if( history_pos < 1  ) history_pos = 1;
    if( history_pos > sim_history.length ) history_pos = sim_history.length;
    loadHistoryStep();
    updateState();
    showStatus( "Go To Step " + pos );
}


function showHistoryTable()
{
    if( trace_mode != 'Paused' ) stopRun();
    pauseReplayHistory();

    var win = window.open( "sim-history.html", "sim-history" );
}


function exportHistory()
{
    var text = "# Simulation History: " + netname + "\r\n";
    text += "\"Step\"; ";

    for( var i in sim_history[0] ) {
        for( var j in sim_history[0][i] ) {
	    if( i == "marking" )
		text += "\"" + place_names[j] + "("+j+")" + "\"; ";
	    else if( i == "transitions" )
		text += "\"" + transition_names[j] + "("+j+")" + "\"; ";
	    else text += "\"" + j + "\"; ";
	}
    }
    text += "\r\n";

    for( var s in sim_history ) {
	text += s + "; ";
        var state = sim_history[s];
	for( var i in state ) {
	    for( var j in state[i] ) {
		text += Number(state[i][j]) + "; ";
	    }
	}
	text += "\r\n";
    }

    window.open( "data:text/csv;charset=utf-8," + encodeURIComponent(text),
                 netname + "_simhist.csv" );
}


function loadHistory()
{
    alert( "loadHistory not yet implemented !" );
}


function getWaveforms()
{
    var waveform = [];

    for( var i in sim_history[0] ) {
        for( var j in sim_history[0][i] ) {
	    var signal = {};
	    signal.name = j;
	    if( i == "marking" ) signal.name += "/" + place_names[j];
	    if( i == "transitions" ) signal.name += "/" + transition_names[j];

	    signal.type = (i=="input_signals"||i=="input_events") ? "input" :
	                  (i=="output_signals"||i=="output_events") ? "output" :
	                  "internal";
	    signal.subtype = (i == "marking") ? "place" :
			     (i=="input_signals"||i=="output_signals")?"signal":
			     (i=="input_events" ||i=="output_events") ?"event" :
			     (i=="transitions") ? "transition" : i;
	    signal.minValue = 0;
	    signal.maxValue = 1;
	    if( signal.subtype == "place" ) {
		for( var step = 0; step < sim_history.length; ++step ) {
		    if( Number(sim_history[step][i][j]) > signal.maxValue )
		        signal.maxValue = Number(sim_history[step][i][j]);

		}
	    }
	    else if( signal.subtype == "signal" ) {
		var min = state_frame.getElementById("min_"+signal.type+"_"+j);
		var max = state_frame.getElementById("max_"+signal.type+"_"+j);
		if( min != null ) signal.minValue = Number(min.value);
		if( max != null ) signal.maxValue = Number(max.value);
	    }
	    signal.behaviourVector = [];
	    signal.viewMode = "normal";
	    if( signal.maxValue > 1 ) signal.viewMode = "simpleComp";
	    signal.numericalBase = "d";
	    signal.visibility = 1;

	    for( var step = 0; step < sim_history.length; ++step ) {
	        signal.behaviourVector.push( Number(sim_history[step][i][j]) );
	    }

	    waveform.push( signal );
	}
    }

    return waveform;
}


function exportWaveforms()
{
    var waveform = getWaveforms();

    window.open( "data:text/json;charset=utf-8," +
                 encodeURIComponent(JSON.stringify(waveform,null,2)),
                 netname + "_simhist.json" );
}


function exitSimulator()
{
    if( play_interval ) pauseReplayHistory();
    else document.location = "index.php";
}


function bg_click( evt )
{
    evt.preventDefault();
}


function pickNode( type, evt )
{
    evt.preventDefault();
}


function bg_move( evt )
{
    var btn, x, y;

    evt.preventDefault();
    evt.stopPropagation();

    if( scroll_page == false ) return;

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
	    evt.touches.length == 1 && evt.typr == "touchend" ) return;
	btn = 0;
	x = evt.changedTouches[0].screenX;
	y = evt.changedTouches[0].screenY;
    }
    else {
        btn = evt.button;
	x = evt.screenX;
	y = evt.screenY;
    }

    if( btn != 0 || evt.type == "mouseup" || evt.type == "touchend" ) {
        button_pressed = false;
	scroll_page = false;
    }

    if( evt.type == "mousedown" || evt.type == "touchstart" )
	button_pressed = true;
    else if( button_pressed ) drawingwindow.scrollBy( start_x-x, start_y-y );
    start_x = x;
    start_y = y;
}


function node_move( evt )
{
    if( scroll_page ) {
        bg_move( evt );
	return;
    }

    var btn = 0;
    var target = evt.target;

    if( (evt.type != "mousedown" && evt.type != "touchstart") ||
        play_interval != null ) return;
    if( evt.type == "touchstart" ) {
        if( evt.touches.length > 1 ) return;
	evt.preventDefault();
	btn = 0;
    }
    else btn = evt.button;

    var node_type = target.getAttribute("node-type");
    var id = target.getAttribute("id");

    if( node_type == "transition" ) {
	var tid = "t_" + id;
	if( breakpoints[tid] != null ) {
	    breakpoints[tid] = !breakpoints[tid];
	    sendCommand( "SetBreakpoints", breakpoints );
	    updateGraphics();
	    showStatus( (breakpoints[tid] ? "Set" : "Clear") + " Breakpoint " +
			transition_names[tid] + "(" + tid + ")" );
	}
	return;
    }

    if( node_type == "signal" ) {
	if( input_signals[id] == null ) return;
	if( forced_inputs[id] != null ) {
	    delete forced_inputs[id];
	    showStatus( "Release input " + id );
	}
	else {
	    forced_inputs[id] = input_signals[id];
	    showStatus( "Force input " + id + " = " + forced_inputs[id] );
	}
	sendCommand( "ForceInputs", forced_inputs );
	updateGraphics();
	return;
    }

    if( node_type == "event" ) {
        /*
	// Only Autonomous Events
        if( state_frame.getElementById( "event_" + id ) == null ) return;

	if( input_events[id] != null ) {
	    input_events[id] = !input_events[id];
	    updateState();
	    showStatus( input_events[id] ? "Set Event " + id :
					   "Reset Event " + id );
	}
	return;
	*/
    }

    if( node_type == "array" && btn == 0 ) {
	window.open( "sim-array-contents.html?id="+id , "sim-array-content" );
	return;
    }

    //showStatus( evt.type + " " + evt.target.getAttribute("node-type") + " " + evt.target.getAttribute( "id") );
}


function scrollPage()
{
    scroll_page = true;
}


function openDialog( wid, hei, doc )
{
    var div = document.createElement( "div" );
    div.setAttribute( "id", "dialog_bg" );
    div.style.position = "absolute";
    div.style.left = 0;
    div.style.top = 0;
    div.style.width = "100%";
    div.style.height = "100%";
    div.style.opacity = 0.75;
    div.style.background = "lightgray";
    document.body.appendChild( div );

    var div2 = document.createElement( "div" );
    div2.setAttribute( "id", "dialog_fg" );
    div2.style.position = "absolute";
    div2.style.left = "30%";
    div2.style.top = "30%";
    div2.style.width = wid+10;
    div2.style.height = hei+10;
    div2.style.background = "lightgray";
    div2.style.padding = 10;
    div2.style.opacity = 1.0;
    div2.style.textAlign = "center";

    div2.innerHTML = '<iframe id="dialog_frame" src="' + doc +
                     '" width="' + wid + '" height="' + hei + 
                     '" scrolling="no"></iframe>';

    document.body.appendChild( div2 );
    div2.focus();
}



function closeDialog()
{
    document.body.removeChild( document.getElementById( "dialog_fg") );
    document.body.removeChild( document.getElementById( "dialog_bg") );
}

