<?php
    // IOPT Simulator
    // 2014 (C) GRES Research Group - FCT/UNL - Uninova
    // Author: Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);
/*
    $tdset = array();
    $td_cnt = 0;
    $xpath = new DOMXPath( $pnmlDoc );
    $tdlist = $xpath->query( "//pnml/net/place/timedomain/text" );
    foreach( $tdlist as $tdn ) {
        $td = $tdn->textContent;
        if( !isset($tdset[$td]) ) {
	    $tdset[$td] = true;
	    ++$td_cnt;
	}
    }
    if( $td_cnt > 1 ) {
        echo( "<p>GALS Model: Please decompose and run the simulator on each component.</p>" );
	die( "<p><a href='index.php'> Return to model </a></p>" );
    }
*/
?>

<html>
<head>
<title> IOPT Tools - Simulator [BETA] </title>
    <script src="js_gen.php" language="javascript"></script>
    <script src="iopt-simulator.js" language="javascript"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body onload="startSimulator();">
<font size="-1">
<table width="100%" height="95%" style="width:100%; height:95%;">
<tr>
<td width="14%" style="width:14%;" ><iframe id="toolbox" src="sim-toolbox.html" width="100%" height="100%"></iframe></td>
<?php
    if( !strstr( $_SERVER["HTTP_USER_AGENT"], "Chrome" ) &&
	 strstr( $_SERVER["HTTP_USER_AGENT"], "Safari" ) &&
	     (strstr( $_SERVER["HTTP_USER_AGENT"], "iPad" ) ||
	      strstr( $_SERVER["HTTP_USER_AGENT"], "iPhone" ) ) ) {
	echo '<td width="68%" style="width:68%; overflow:scroll; -webkit-overflow-scrolling:touch;">';
	echo '<iframe id="drawingarea" src="background.html" width="100%" height="100%" style="width:100%; height:100%; overflow:scroll; -webkit-overflow-scrolling:touch;" bgcolor="white" scrolling="yes"></iframe>';
    }
    else if( strstr( $_SERVER["HTTP_USER_AGENT"], "Chrome" ) ||
	     strstr( $_SERVER["HTTP_USER_AGENT"], "Safari" ) ) {
	echo '<td width="68%" style="width:68%;">';
	echo '<iframe id="drawingarea" src="background.html" width="100%" height="100%" style="width:100%; height:100%;" bgcolor="white" scrolling="yes"></iframe>';
    }
    else {
	echo '<td width="68%" style="width:68%;">';
	echo '<iframe id="drawingarea" src="background.html" width="100%" height="100%" style="width:100%;" bgcolor="white" scrolling="yes"></iframe>';
    }
?>
</td>
<td width="18%" style="width:18%;" ><iframe id="state" width="100%" height="100%" src="sim_prop.php"></iframe></td>
</tr>
</table>

<input type="text" id="run_mode" value="Idle" readonly="1" size="10" />
<input type="text" id="status" value="IOPT Simulator/Debugger Ready" readonly="1" size="100"/>
</font>
</body>
</html>
