<?php
    // Author: 2013 (C) Fernando J. G. Pereira

    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $dir = $user_dir . "/ss_gen/" . $out_file;
    if( !file_exists($dir) ) {
	header( "Location: ss_init_marking.php" );
	exit();
    }

    $orig_dir = getcwd();
    chdir( $dir );
  
    if( !file_exists("progress.txt") ) {
	header( "Location: ss_init_marking.php" );
	exit();
    }

    $done = false;
    $proc = intval( file("progress.txt")[0] );
    if( $proc > 0 ) $done = !posix_kill( $proc, 10 );

    if( isset($_GET["Close"]) ) {
	if( !$done && $proc > 0 ) posix_kill( $proc, 9 );
	exec( "make clean-all" );
	chdir( $orig_dir );
	rmdir( $dir );
	echo "<script language='javascript'> window.close(); </script>\n";
	exit();
    }

    if( isset($_GET["Interrupt"]) ) {
	if( !$done && $proc > 0 ) posix_kill( $proc, 15 );
    }

    if( !$done ) {
	header( "Location: ss_progress.php" );
	exit();
    }

    if( isset($_GET["Download"]) ) {
	$zipname = "ss.zip";
	if( file_exists($zipname) ) unlink( $zipname );
	$zipfile = new ZipArchive();
	$zipfile->open( $zipname, ZIPARCHIVE::CREATE );
	$zipfile->addFile( "ss.xml", "/ss.xml.gz" );
	$zipfile->close();
	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename='.basename($zipname));
	header('Content-Transfer-Encoding: binary');
	header('Expires: 0');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Pragma: public');
	header('Content-Length: ' . filesize( $zipname ) );
	ob_clean();
	flush();
	readfile( $zipname );
	unlink( $zipname );
    }
    else if( isset($_GET["View"]) ) {
	header("Pragma: no-cache");
	header("Content-type: image/svg+xml");
	header("Content-encoding: gzip");
	readfile( "ss.xml" );
    }
    else header( "Location: ss_progress.php" );
?>
