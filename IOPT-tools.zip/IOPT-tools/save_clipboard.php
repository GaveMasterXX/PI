<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = "saved_clipboard.pnml";
        $model_file = $user_dir . "/files/" . $out_file;
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
    }
    else die("<p>No PNML Document</p>");
    unlink( $model_file );
    $file = fopen( $model_file, "w" );
    fwrite( $file, $HTTP_RAW_POST_DATA );
    fclose( $file );
?>
