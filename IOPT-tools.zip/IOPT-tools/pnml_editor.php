<html>
<head>
<title> IOPT Tools - PNML Editor</title>
    <script src="pnml_editor.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body onload="loadDocument();" onkeydown="keyPressed(event);">
<font size="-1">
<table width="100%" height="95%" style="width:100%; height:95%;">
<tr>
<td width="13%" style="width:13%;" ><iframe id="toolbox" src="toolbox.php" width="100%" height="100%"></iframe></td>
<?php
    if( !strstr( $_SERVER["HTTP_USER_AGENT"], "Chrome" ) &&
	 strstr( $_SERVER["HTTP_USER_AGENT"], "Safari" ) &&
	     (strstr( $_SERVER["HTTP_USER_AGENT"], "iPad" ) ||
	      strstr( $_SERVER["HTTP_USER_AGENT"], "iPhone" ) ) ) {
	echo '<td width="65%" style="width:65%; overflow:scroll; -webkit-overflow-scrolling:touch;">';
	echo '<iframe id="drawingarea" src="background.html" width="100%" height="100%" style="width:100%; height:100%; overflow:scroll; -webkit-overflow-scrolling:touch;" bgcolor="white" scrolling="yes"></iframe>';
    }
    else if( strstr( $_SERVER["HTTP_USER_AGENT"], "Chrome" ) ||
	     strstr( $_SERVER["HTTP_USER_AGENT"], "Safari" ) ) {
	echo '<td width="65%" style="width:65%;">';
	echo '<iframe id="drawingarea" src="background.html" width="100%" height="100%" style="width:100%; height:100%;" bgcolor="white" scrolling="yes"></iframe>';
    }
    else {
	echo '<td width="65%" style="width:65%;">';
	echo '<iframe id="drawingarea" src="background.svg" width="100%" height="100%" style="width:100%;" bgcolor="white" scrolling="yes"></iframe>';
    }
?>
</td>
<td width="22%" style="width:22%;" ><iframe id="properties" width="100%" height="100%"></iframe></td>
</tr>
</table>

<input type="text" id="status" value="IOPT Editor Ready" readonly="1" size="100"/>
&nbsp;X:<input type="text" id="coord_x" value="0" readonly="1" size=5 />
&nbsp;Y:<input type="text" id="coord_y" value="0" readonly="1" size=5 />
&nbsp;Grid: <input type="checkbox" id="snap" name="Snap" checked="1" onchange="setGrid(event);" />
&nbsp;Snap: <input type="checkbox" id="snap" name="Snap" checked="1" onchange="setSnap(event);" />
</font>
</body>
</html>
