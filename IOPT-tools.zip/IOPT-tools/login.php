<?php
    // 2013 (C) GRES
    // Author: Fernando J. G. Pereira

    header("Pragma: no-cache");
?>

<html>
<head>
    <title>IOPT Tools</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<center>
<p>&nbsp;</p>
<p><font size="+5"><b>IOPT Tools</b></font></p>

<?php
    session_start();

    unset( $_SESSION["pnml_file"] );

    $inv = array( " ", "\t", ".", "/", "\\", "&", "%");
    if( isset($_POST["username"]) )
	$user = addslashes( str_replace( $inv, "_", $_POST["username"]) );
    else $user ="";

    if( isset($_POST["password"]) )
	$pass = sha1( $_POST["password"], false );
    else $pass = "";

    $user_dir = "users/" . $user . "__" . $pass;

    if( isset($_POST["login"]) && $_POST["login"] ) {
        if( file_exists( $user_dir ) ) {
	    $_SESSION["username"] = $user;
	    $_SESSION["user_dir"] = $user_dir;
            header( "Location: manage-files.php" );
	    exit();
	}
        echo "<p>Invalid Login - please try again !<p>" ;
    }

    if( isset($_POST["create"]) && isset($_POST["confirm"]) ) {
        if( strlen( $_POST["password"] ) < 6 )
	    echo "<p>Password too short<p>\n";
        else if( strlen( $_POST["email"] ) < 6 )
	    echo "<p>Email too short<p>\n";
        else if( $_POST["password"] == $_POST["confirm"] ) {
	    if( $user == "guest" || file_exists( $user_dir ) ) {
		echo "<p>Invalid Username/Password<p>\n";
	    }
            else {
		mkdir( $user_dir );
		mkdir( $user_dir . "/files" );
		mkdir( $user_dir . "/code_gen" );
		mkdir( $user_dir . "/ss_gen" );
		mkdir( $user_dir . "/queries" );
		chmod( $user_dir . "/files", 0777 );
		$_SESSION["username"] = $user;
		$_SESSION["user_dir"] = $user_dir;

		if( isset( $_POST["email"] ) ) {
		    $fptr = fopen( $user_dir . "/email", "w" );
		    fwrite( $fptr, addSlashes($_POST["email"]) . "\n" );
		    fclose( $fptr );
		}

		header( "Location: manage-files.php" );
		exit();
	    }
	}
	else echo "<p> Password confirmation does not match </p>\n";
    }

    unset( $_SESSION["username"] );
    unset( $_SESSION["user_dir"] );
?>

<form name="login_form" action="login.php" method="post">
<table border='0' width="70%" height="20%">
<tr>
    <td></td><th> User Login: </th>
    <td rowspan="4" align="center" width="50%">
    <div><?php include 'login.svg'; ?></div></td>
</tr>
<tr><td align="right" width="20%">Username:</td>
    <td> <input type="text" size="40" name="username"
    <?php echo "value=\"" . $user . "\""; ?>
    ></input></td>
</tr>
<tr><td align="right" width="20%">Password:</td>
    <td> <input type="password" size="40" name="password"
    <?php if( isset($_POST["password"]) )
          echo "value = \"" . $_POST["password"] . "\""; ?>
    ></input></td>
</tr>
<?php
    if( isset($_POST["create"]) ) {
	echo "<tr><td align=\"right\" width=\"30%\">Confirm Password:</td>";
	echo "<td><input type=\"password\" size=\"40\" name=\"confirm\"></input></td>";
	echo "</tr>\n";
	echo "<tr><td align=\"right\" width=\"30%\">EMail:</td>";
	echo "<td><input type=\"text\" size=\"60\" name=\"email\"";
	if( isset( $_POST["email"] ) )
	    echo "value='" . addSlashes($_POST["email"]) . "'";
	echo "></input></td>";
	echo "</tr>\n";
    }
?>
<tr><td></td><td align="center">
<?php 
    if( !isset($_POST["create"]) ) { 
        echo "<input type=\"submit\" name=\"login\" value=\"Login\"></input>\n";
    }
?>
    <input type="submit" name="create" value="New User"></input>
    <input type="submit" name="cancel" value="Cancel"></input>
</td></tr>
</table>
</form>
<p>Copyright (C) 2012-15 GRES Research Group</p>
<div style="text-align:left; margin-left:3cm; margin-right:3cm;">
<font color="yellow">
<p>NOTES: Example models available under username "<b>models</b>" and password "<b>models</b>".</p>
<p>Anonymous users can login into the system with username "<b>guest</b>" and password "<b>guest</b>", to create new IOPT models and test all system functionalities. However, these models will be openly accessible to all users and may be modified by other users or deleted at any time. Therefore, creating a personal user account [free] is highly recommended.</p>
<p> For information about the tools please download the <a href="../iopt_usermanual.pdf" target="_new"> User Manual </a>.</p>
<p><a href="../iopt_publications.html">IOPT-Tools</a> have been developed by several members of the R&D Group on Reconfigurable and Embedded Systems (<a href="..">GRES</a>).
At current development phase, some changes and improvements will occur in the near future. Comments or requests can be directed to gres@uninova.pt</p>
<p>IOPT-Tools received finantial support from the project Petri-Rig - A Petri net based framework from embedded systems engineering, ref. PTDC/EEI-AUT/2641/2012</p>
</font>
<font size="+1">
<p><b> Important note: IOPT-Tools require the latest Browser versions: Firefox >= 10, Chrome >= 12, Safari, Opera </b></p>
</font>
</div>
</center>
</body>
</html>
