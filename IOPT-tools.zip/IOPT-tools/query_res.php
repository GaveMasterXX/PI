<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";


    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
        $query_file = $user_dir . "/queries/" . $out_file;
        $query_res_file = $user_dir . "/queries/" . $out_file . ".res";
    }
    else die("<p>No PNML Document</p>");

    if( !file_exists($query_file) ) {
        die( "<p>Query results not found - Please generate state space !</p>" );
    }

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($query_file);
    $query_list = $pnmlDoc->getElementsByTagName( "query" );

    $matches = array();
    $expand = array();
    $count = 0;
    $counters = array();
    for( $i = 0; $i < 32; ++$i ) $counters[$i] = 0;
    $res = file( $query_res_file );
    foreach( $res as $r ) {
        sscanf( $r, "%d %d", $s, $q );
	$matches[$count++] = array( $q, $s );
	++$counters[$q];
    }

    echo "<html>\n";
    echo "<head>\n";
    echo "<title> IOPT State Space Query Results </TITLE>\n";
    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n";
    echo "<link href='../css/style.css' rel='stylesheet' type='text/css' media='screen' />\n";
    echo "</head>\n";
    echo "<body>\n";
    echo "<center>\n";
    echo "<h1>Found $count matching query results for model $out_file</h1>\n";
    echo "<form name='action' method='post' action='query_res.php'>\n";
    echo "<table border='1' width='80%'>\n";
    echo "<tr><th align='center' colspan='2'><font size='+2'>Summary:</font></th></tr>\n";
    for( $i = 1; $i < 32; ++$i ) {
	if( $counters[$i] > 0 ) {
	    echo "<tr><td><input type='checkbox' ";
	    if( isset($_POST["query_$i"]) && $_POST["query_$i"] ) {
	        echo "checked='1' ";
		$expand[$i] = 1;
	    }
	    echo "name='query_$i'> Query $i </input>( ";
	    $elems = $query_list->item($i-1)->getElementsByTagName("elem");
	    foreach( $elems as $e ) {
	        echo $e->getAttribute("value") . " ";
	    }
	    echo ")</td>";
	    echo "<td align='center'>" . $counters[$i] . " matching states </td></tr>";
	}
    }
    echo "</table>\n";

    echo "<p>\n";
    echo "<input type='radio' name='sort' value='1'";
    if( $_POST["sort"] == 1 ) echo "checked='1' ";
    echo ">Sort by Query</input>\n";
    echo "<input type='radio' name='sort' value='0'";
    if( $_POST["sort"] == 0 ) echo "checked='1' ";
    echo ">Sort by State</input>\n";
    echo "<input type='submit' name='update' value='Show Results'></input>\n";
    echo "<input type='button' value='Exit' onclick=\"document.location='index.php';\"></input>\n";
    echo "</p>\n";
    echo "</form>\n";

    if( !isset($_POST["update"]) ) return;

    if( $_POST["sort"] == '1' ) sort( $matches );

    echo "<table border='1' width='80%'>\n";
    echo "<tr><th align='center'>State/Link ID</th><th align='center'>Query Nr.</th></tr>\n";
    for( $i = 0; $i < $count; ++$i ) {
        $s = $matches[$i][1];
        $q = $matches[$i][0];
        if( isset( $expand[$q] ) )
	    echo "<tr><td align='center'>$s</td><td align='center'>$q</td></tr>\n";
    }
    echo "</table>\n";
    echo "</center>\n";
    echo "</body>\n";
    echo "</html>\n";
?>

