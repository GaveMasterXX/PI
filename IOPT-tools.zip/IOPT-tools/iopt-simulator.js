// IOPT Simulator
// 2014 (C) GRES Research Group - FCT/UNL - Uninova
// Author: Fernando J. G. Pereira


var netname = "";
var marking = null;
var input_signals = null;
var input_events = null;
var output_signals = null;
var output_events = null;
var transitions = null;
var breakpoints = null;
var place_names = null;
var transition_names = null;

var sim_history = new Array();
var history_pos = 1;

var drawingarea = null;
var drawingwindow = null;
var state_frame = null;
var toolbox = null;
var statusbar = null;
var run_mode  = null;
var history_step = null;
var history_size = null;
var waveform_window = null;

var run_interval = null;
var play_interval = null;
var play_delay = 500;

var gr_places = new Array();
var gr_marking = new Array();
var gr_transitions = new Array();
var gr_input_signals = new Array();
var gr_output_signals = new Array();
var gr_input_events = new Array();
var gr_output_events = new Array();
var svg_doc = null;

var scroll_page = false;
var button_pressed = false;
var start_x = 0;
var start_y = 0;

var gui_window = null;

var backupVarArrays = null;
var restoreVarArrays = null;



function loadXMLDoc( dname )
{
    var xhttp;
    if( window.XMLHttpRequest ) xhttp= new XMLHttpRequest();
    else alert( "Error: Web Browser does not support XMLHttpRequest !" );
    xhttp.open( "GET", dname, false );
    xhttp.send("");
    return xhttp.responseXML;
}


function drawNet()
{
    var nodes = drawingarea.childNodes;
    for( var i=nodes.length-1; i >= 0; i-- ) {
        drawingarea.removeChild( nodes[i] );
    }
    drawingarea.appendChild( svg_doc.documentElement );
}



function startSimulator()
{
    state_frame = document.getElementById("state").contentDocument;
    toolbox = document.getElementById("toolbox").contentDocument;
    statusbar = document.getElementById("status");
    run_mode = document.getElementById("run_mode");
    drawingwindow = document.getElementById("drawingarea").contentWindow;
    drawingarea =
        document.getElementById("drawingarea").contentDocument.documentElement;

    svg_doc = loadXMLDoc( "show_iopt.php?edit=1" );
    drawNet();

    netname = state_frame.getElementById("netname").value;
    history_step = toolbox.getElementById( "history_step" );
    history_size = toolbox.getElementById( "history_size" );

    backupVarArrays = eval( netname + "_backupVarArrays" );
    restoreVarArrays = eval( netname + "_restoreVarArrays" );

    marking = eval( netname + "_marking" );
    input_signals = eval( netname + "_input_signals" );
    input_events = eval( netname + "_input_events" );
    output_signals = eval( netname + "_output_signals" );
    output_events = eval( netname + "_output_events" );
    transitions = eval( netname + "_tfired" );
    place_names = eval( netname + "_place_names" );
    transition_names = eval( netname + "_transition_names" );
    resetBreakpoints();

    findGraphicObjects();

    initialState();
    resetHistory();
}


function resetBreakpoints()
{
    breakpoints = clone(transitions);
    for( var i in breakpoints ) breakpoints[i] = false;
}


function findNode( type, id, elem )
{
    var items = drawingarea.getElementsByTagName( elem );
    for( var i = 0; i < items.length; ++i ) {
        if( items[i].getAttribute( "node-type" ) == type &&
	    items[i].getAttribute( "id" ) == id ) return items[i];
    }
    return null;
}


function findGraphicObjects()
{
    var i, obj;

    for( i in marking ) {
        obj = findNode( "place", i.slice(2), "circle" );
	if( obj != null ) gr_places[i] = obj;
	else {
	    obj = findNode( "place", i.slice(2), "path" );
	    if( obj != null ) gr_places[i] = obj;
	}
	if( obj != null ) {
	    var siblings = obj.parentNode.getElementsByTagName("text");
	    for( var j = 0; j < siblings.length; ++j ) {
	        if( siblings[j].getAttribute("id") == "marking" ) {
	            gr_marking[i] = siblings[j];
		    gr_marking[i].textContent= "";
		    break;
	        }
	    }
	}
    }
    for( i in transitions ) {
        obj = findNode( "transition", i.slice(2), "rect" );
	if( obj != null ) gr_transitions[i] = obj;
    }
    for( i in input_signals ) {
        obj = findNode( "signal", i, "circle" );
	if( obj != null ) gr_input_signals[i] = obj;
    }
    for( i in input_events ) {
        obj = findNode( "event", i, "polygon" );
	if( obj != null ) gr_input_events[i] = obj;
    }
    for( i in output_signals ) {
        obj = findNode( "signal", i, "circle" );
	if( obj != null ) gr_output_signals[i] = obj;
    }
    for( i in output_events ) {
        obj = findNode( "event", i, "polygon" );
	if( obj != null ) gr_output_events[i] = obj;
    }
}


function showStatus( msg )
{
     statusbar.value = msg;
}


function updateState()
{
    for( var i in marking ) {
        var p = state_frame.getElementById( "place_" + i );
	p.value = marking[i];
    }
    for( var i in input_signals ) {
        var p = state_frame.getElementById( "input_" + i );
	if( p.getAttribute("type") == "checkbox" )
	    p.checked = input_signals[i];
	else
	    p.value = input_signals[i];
    }
    for( var i in input_events ) {
        var p = state_frame.getElementById( "event_" + i );
	if( p != null ) p.checked = input_events[i];
    }
    for( var i in output_signals ) {
        var p = state_frame.getElementById( "output_" + i );
	p.value = output_signals[i];
    }

    history_step.value = history_pos;
    history_size.value = sim_history.length;

    updateGraphics();

    if( gui_window != null ) gui_window.updateState();
}


function updateGraphics()
{
    var i, ready, enabled;

    eval( netname + "_generateInputEvents()" );

    for( i in gr_places ) {
	gr_places[i].setAttribute( "fill",
	    marking[i] > 1 ? "magenta" : marking[i] > 0 ? "red" : "yellow" );
    }

    for( i in gr_marking ) {
	if( marking[i] > 0 ) gr_marking[i].textContent = marking[i];
	else gr_marking[i].textContent = "";
    }

    for( i in gr_transitions ) {
        ready = eval( netname + "_t" + i.slice(2) + "_ready()" );
        enabled = eval( netname + "_t" + i.slice(2) + "_enabled( marking )" );
	gr_transitions[i].setAttribute( "fill",
	    ready & enabled ? "green" :
	    enabled ? "orange" :
	    ready ? "yellow" : "cyan" );

	gr_transitions[i].setAttribute( "stroke",
	    breakpoints[i] ? "red" : "black" );
	gr_transitions[i].setAttribute( "stroke-width", 1+breakpoints[i]*2 );
    }

    for( i in gr_input_signals ) {
	gr_input_signals[i].setAttribute( "fill",
	    input_signals[i] > 0 ? "green" : "#60DADA" );
    }

    for( var i in gr_input_events ) {
	gr_input_events[i].setAttribute( "fill",
	    input_events[i] > 0 ? "green" : "#60DADA" );
    }

    for( i in gr_output_signals ) {
	gr_output_signals[i].setAttribute( "fill",
	    output_signals[i] > 0 ? "red" : "#90D090" );
    }

    for( i in gr_output_events ) {
	gr_output_events[i].setAttribute( "fill",
	    output_events[i] > 0 ? "red" : "#90D090" );
    }
}


function readInputs( redraw )
{
    for( var i in input_signals ) {
        var p = state_frame.getElementById( "input_" + i );
	if( p.getAttribute("type") == "checkbox" )
	    input_signals[i] = p.checked;
	else {
	    var min = state_frame.getElementById( "min_input_" + i );
	    var max = state_frame.getElementById( "max_input_" + i );
	    input_signals[i] = Number(p.value) | 0;
	    if( input_signals[i] < Number(min.value) ) {
		input_signals[i] = Number(min.value);
		p.value = input_signals[i];
	    }
	    else if( input_signals[i] > Number(max.value) ) {
		input_signals[i] = Number(max.value);
		p.value = input_signals[i];
	    }
	}
    }
    for( var i in input_events ) {
        var p = state_frame.getElementById( "event_" + i );
	if( p != null ) input_events[i] = p.checked;
    }

    if( redraw ) {
        updateGraphics();
	if( gui_window != null ) gui_window.updateState();
    }
}


function initialState()
{
    eval( netname + "_init()" );
    saveHistoryStep();
    stopRun();
    pauseReplayHistory();
    updateState();
    showStatus( "Initial State" );
}


function forceState()
{
    saveHistoryStep();
    stopRun();
    for( var i in marking ) {
        var p = state_frame.getElementById( "place_" + i );
	marking[i] = Math.floor(Number(p.value));
	if( marking[i] < 0 ) marking[i] = 0;
    }
    resetHistory();
    pauseReplayHistory();
    updateState();
    showStatus( "Force State" );
}


function saveHistoryStep()
{
     if( sim_history.length > 1000000 ) {
         alert( "History size too large. Please clear History" );
	 stopRun();
     }

     var state = {
         'marking'       : clone( marking ),
	 'transitions'   : clone( transitions ),
         'input_signals' : clone( input_signals ),
         'output_signals': clone( output_signals ),
	 'input_events'  : clone( input_events ),
	 'output_events' : clone( output_events ),
	 'var_arrays'    : backupVarArrays() 
    };

    sim_history.push( state );
    history_pos = sim_history.length;
}


function copyArray( dest, source )
{
    for( var i in source ) dest[i] = source[i];
}


function loadHistoryStep()
{
    var prev_input_signals = eval( netname + "_prev_input_signals" );
    copyArray( marking,        sim_history[history_pos-1].marking );
    copyArray( input_signals,  sim_history[history_pos-1].input_signals );
    copyArray( input_events,   sim_history[history_pos-1].input_events );
    copyArray( output_signals, sim_history[history_pos-1].output_signals );
    copyArray( output_events,  sim_history[history_pos-1].output_events );
    copyArray( transitions,    sim_history[history_pos-1].transitions );
    copyArray( prev_input_signals, input_signals );
    restoreVarArrays( sim_history[history_pos-1].var_arrays );
}


function truncHistory()
{
    while( sim_history.length > history_pos ) sim_history.pop();
}


function undoStep()
{
    stopRun();
    pauseReplayHistory();

    if( sim_history.length > 1 ) {
	sim_history.pop();
	history_pos = sim_history.length;
	loadHistoryStep();
    }
    updateState();
    showStatus( "Undo 1 Step" );
}


function step()
{
    readInputs( false );
    eval( netname + "_ExecutionStep()" );
    saveHistoryStep();
    updateState();
}


function execStep( nsteps )
{
    stopRun();
    pauseReplayHistory();

    if( history_pos < sim_history.length ) {
        if( confirm( "Truncate history and run from current state ?" ) )
	    truncHistory();
	else endHistory();
    }

    for( var i = 0; i < nsteps; ++i ) step();
    showStatus( "Execute " + nsteps + " Step(s)" );
}



function runStep()
{
    step();
    for( i in breakpoints ) {
        if( breakpoints[i] && transitions[i] ) {
	    clearInterval( run_interval );
	    showStatus( "Breakpoint " + i );
	    gr_transitions[i].setAttribute( "fill", "red" );
	    alert( "Breakpoint at " + transition_names[i] + "(" + i + ")" );
	    break;
	}
    }
}


function stopRun()
{
    if( run_interval != null ) {
        clearInterval( run_interval );
	run_mode.value = "Stop Run";
	run_mode.style.backgroundColor = "red";
    }
    run_interval = null;
}


function startRun( step_delay )
{
    pauseReplayHistory();

    if( history_pos < sim_history.length ) {
        if( confirm( "Truncate history and run from current state ?" ) )
	    truncHistory();
	else endHistory();
    }

    if( run_interval ) clearInterval( run_interval );
    run_interval = setInterval( runStep, step_delay );
    run_mode.value = "Running";
    run_mode.style.backgroundColor = "green";
}


function rewindHistory()
{
    stopRun();
    pauseReplayHistory();

    history_pos = 1;
    loadHistoryStep();
    updateState();
    showStatus( "Rewind" );
}


function backHistory()
{
    stopRun();
    pauseReplayHistory();

    --history_pos;
    if( history_pos < 1 ) history_pos = 1;
    loadHistoryStep();
    updateState();
    showStatus( "Back History" );
}


function forwardHistory()
{
    stopRun();

    if( history_pos >= sim_history.length ) return;

    ++history_pos;
    copyArray( input_signals, sim_history[history_pos-1].input_signals );
    setTimeout( doForwardHistory, play_delay/2 );
    updateState();
}


function doForwardHistory()
{
    loadHistoryStep();
    updateState();
    if( play_interval != null ) {
        if( history_pos == sim_history.length ) {
	    clearInterval( play_interval );
	    play_interval = null;
	    run_mode.value = "Replay End";
	    run_mode.style.backgroundColor = "red";
	}
    }
    else showStatus( "Forward History" );
}


function endHistory()
{
    stopRun();
    pauseReplayHistory();

    history_pos = sim_history.length;
    loadHistoryStep();
    updateState();
    showStatus( "End History" );
}


function resetHistory()
{
    stopRun();
    pauseReplayHistory();

    sim_history = new Array();
    saveHistoryStep();
    history_pos = 1;
    updateState();
    showStatus( "Reset History" );
}


function replayHistory( step_delay )
{
    stopRun();
    if( history_pos >= sim_history.length ) rewindHistory();
    play_delay = step_delay;
    if( play_interval ) clearInterval( play_interval );
    play_interval = setInterval( forwardHistory, play_delay );
    run_mode.value = "Replaying";
    run_mode.style.backgroundColor = "yellow";
}


function pauseReplayHistory()
{
    if( play_interval != null ) {
        clearInterval( play_interval );
	run_mode.value = "Pause Replay";
	run_mode.style.backgroundColor = "gray";
    }
    play_interval = null;
    play_delay = 500;
}


function historyGoTo( pos )
{
    stopRun();
    pauseReplayHistory();

    history_pos = pos;
    if( history_pos < 1  ) history_pos = 1;
    if( history_pos > sim_history.length ) history_pos = sim_history.length;
    loadHistoryStep();
    updateState();
    showStatus( "Go To Step " + pos );
}


function showHistoryTable()
{
    stopRun();
    pauseReplayHistory();

    var win = window.open( "sim-history.html", "sim-history" );
}


function exportHistory()
{
    var text = "# Simulation History: " + netname + "\r\n";
    text += "\"Step\"; ";

    for( var i in sim_history[0] ) {
        for( var j in sim_history[0][i] ) {
	    if( i == "marking" )
		text += "\"" + place_names[j] + "("+j+")" + "\"; ";
	    else if( i == "transitions" )
		text += "\"" + transition_names[j] + "("+j+")" + "\"; ";
	    else text += "\"" + j + "\"; ";
	}
    }
    text += "\r\n";

    for( var s in sim_history ) {
	text += s + "; ";
        var state = sim_history[s];
	for( var i in state ) {
	    for( var j in state[i] ) {
		text += Number(state[i][j]) + "; ";
	    }
	}
	text += "\r\n";
    }

    window.open( "data:text/csv;charset=utf-8," + encodeURIComponent(text),
                 netname + "_simhist.csv" );
}


function loadHistory()
{
    alert( "loadHistory not yet implemented !" );
}


function getWaveforms()
{
    var waveform = [];

    for( var i in sim_history[0] ) {
        for( var j in sim_history[0][i] ) {
	    var signal = {};
	    signal.name = j;
	    if( i == "marking" ) signal.name += "/" + place_names[j];
	    if( i == "transitions" ) signal.name += "/" + transition_names[j];

	    signal.type = (i=="input_signals"||i=="input_events") ? "input" :
	                  (i=="output_signals"||i=="output_events") ? "output" :
	                  "internal";
	    signal.subtype = (i == "marking") ? "place" :
			     (i=="input_signals"||i=="output_signals")?"signal":
			     (i=="input_events" ||i=="output_events") ?"event" :
			     (i=="transitions") ? "transition" : i;
	    signal.minValue = 0;
	    signal.maxValue = 1;
	    if( signal.subtype == "place" ) {
		for( var step = 0; step < sim_history.length; ++step ) {
		    if( Number(sim_history[step][i][j]) > signal.maxValue )
		        signal.maxValue = Number(sim_history[step][i][j]);

		}
	    }
	    else if( signal.subtype == "signal" ) {
		var min = state_frame.getElementById("min_"+signal.type+"_"+j);
		var max = state_frame.getElementById("max_"+signal.type+"_"+j);
		if( min != null ) signal.minValue = Number(min.value);
		if( max != null ) signal.maxValue = Number(max.value);
	    }
	    signal.behaviourVector = [];
	    signal.viewMode = "normal";
	    if( signal.maxValue > 1 ) signal.viewMode = "simpleComp";
	    signal.numericalBase = "d";
	    signal.visibility = 1;

	    for( var step = 0; step < sim_history.length; ++step ) {
	        signal.behaviourVector.push( Number(sim_history[step][i][j]) );
	    }

	    waveform.push( signal );
	}
    }

    return waveform;
}


function exportWaveforms()
{
    var waveform = getWaveforms();

    window.open( "data:text/json;charset=utf-8," +
                 encodeURIComponent(JSON.stringify(waveform,null,2)),
                 netname + "_simhist.json" );
}


function waveformEditor()
{
     waveform_window = 
         window.open( 'http://gres.uninova.pt/~fjp/waveform-editor/',
	              'Waveform Editor' );
}



function importInputWaveforms()
{
    if( waveform_window == null ) return;

    var signal_descr = waveform_window.window.allSignals;
    if( signal_descr == null ) return;

    var waveforms = new Object();
    var count = 0;
    var n_steps = 0;

    for( var i in input_signals ) {
	for( var j in signal_descr ) {
	    if( signal_descr[j].type == "input" && i == signal_descr[j].name ) {
	        waveforms[i] = signal_descr[j].behaviourVector.slice(0);
		if( waveforms[i].length > 0 ) {
		    ++count;
		    n_steps = waveforms[i].length;
		}
		break;
	    }
	}
    }

    if( count < 1 || n_steps < 1 ) {
        alert( "Error: No input signals found !" );
        return;
    }

    initialState();
    resetHistory();

    for( var step = 0; step < n_steps; ++step ) {
        for( var w in waveforms ) {
	    input_signals[w] = waveforms[w][step];
	}
	eval( netname + "_ExecutionStep()" );
	saveHistoryStep();
    }
    updateState();

    waveformEditor();
    replayHistory( 100 );
}



function exitSimulator()
{
    if( run_interval ) stopRun();
    else if( play_interval ) pauseReplayHistory();
    else document.location = "index.php";
}


function bg_click( evt )
{
    evt.preventDefault();
}


function pickNode( type, evt )
{
    evt.preventDefault();
}


function bg_move( evt )
{
    var btn, x, y;

    evt.preventDefault();
    evt.stopPropagation();

    if( scroll_page == false ) return;

    if(evt.type=="touchstart" || evt.type=="touchmove" || evt.type=="touchend"){
        if( evt.touches.length > 1 ||
	    evt.touches.length == 1 && evt.typr == "touchend" ) return;
	btn = 0;
	x = evt.changedTouches[0].screenX;
	y = evt.changedTouches[0].screenY;
    }
    else {
        btn = evt.button;
	x = evt.screenX;
	y = evt.screenY;
    }

    if( btn != 0 || evt.type == "mouseup" || evt.type == "touchend" ) {
        button_pressed = false;
	scroll_page = false;
    }

    if( evt.type == "mousedown" || evt.type == "touchstart" )
	button_pressed = true;
    else if( button_pressed ) drawingwindow.scrollBy( start_x-x, start_y-y );
    start_x = x;
    start_y = y;
}


function node_move( evt )
{
    if( scroll_page ) {
        bg_move( evt );
	return;
    }

    var btn = 0;
    var target = evt.target;

    if( (evt.type != "mousedown" && evt.type != "touchstart") ||
        play_interval != null ) return;
    if( evt.type == "touchstart" ) {
        if( evt.touches.length > 1 ) return;
	evt.preventDefault();
	btn = 0;
    }
    else btn = evt.button;

    var node_type = target.getAttribute("node-type");
    var id = target.getAttribute("id");

    if( node_type == "transition" ) {
	var tid = "t_" + id;
	if( breakpoints[tid] != null ) {
	    breakpoints[tid] = !breakpoints[tid];
	    updateGraphics();
	    showStatus( (breakpoints[tid] ? "Set" : "Clear") + " Breakpoint " +
			transition_names[tid] + "(" + tid + ")" );
	}
	return;
    }

    if( node_type == "signal" ) {
	if( input_signals[id] == null ) return;

	if( state_frame.getElementById("input_"+id).getAttribute("type") ==
	    "checkbox" ) {
	    input_signals[id] = !input_signals[id];
	    showStatus( input_signals[id] ? "Set Signal " + id :
					  "Reset Signal " + id );
	}
	else {
	    var min = state_frame.getElementById( "min_input_" + id );
	    var max = state_frame.getElementById( "max_input_" + id );

	    if( btn == 0 ) ++input_signals[id];
	    else --input_signals[id];

	    if( input_signals[id] < Number(min.value) ) 
	        input_signals[id] = Number(max.value);
	    if( input_signals[id] > Number(max.value) ) 
	        input_signals[id] = Number(min.value);

	    showStatus( btn == 0 ? "Increment Signal " + id :
				   "Decrement Signal " + id );
	}
	updateState();
	return;
    }

    if( node_type == "event" ) {
	// Only Autonomous Events
        if( state_frame.getElementById( "event_" + id ) == null ) return;

	if( input_events[id] != null ) {
	    input_events[id] = !input_events[id];
	    updateState();
	    showStatus( input_events[id] ? "Set Event " + id :
					    "Reset Event " + id );
	}
	return;
    }

    if( node_type == "array" && btn == 0 ) {
	window.open( "sim-array-contents.html?id="+id , "sim-array-content" );
	return;
    }

    //showStatus( evt.type + " " + evt.target.getAttribute("node-type") + " " + evt.target.getAttribute( "id") );
}


function scrollPage()
{
    scroll_page = true;
}

