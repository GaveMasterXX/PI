<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["username"]) ) $user = $_SESSION["username"];
    else {
	header( "Location: login.php" );
	exit();
    }

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    $zipname = $user_dir."/code_gen/".$user."_backup_".date("Ymd").".zip";
    if( file_exists($zipname) ) unlink( $zipname );
    $zipfile = new ZipArchive();
    $zipfile->open( $zipname, ZIPARCHIVE::CREATE );
    $zipfile->addEmptyDir( $user . "_models" );

    $i = 0;
    $ent = opendir( $user_dir . "/files" );
    while( $file = readdir( $ent ) ) {
	if( $file[0] != '.' && $file != 'CVS') {
	    $zipfile->addFile( $user_dir . "/files/" . $file, 
	                       "/" . $user . "_models/" . $file );
	}
    }
    closedir( $ent );
    $zipfile->close();

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename( $zipname ) );
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize( $zipname ) );
    ob_clean();
    flush();
    readfile( $zipname );
    unlink( $zipname );
?>
