#!/bin/sh
cp plugins/test_plug_result.pnml $2
