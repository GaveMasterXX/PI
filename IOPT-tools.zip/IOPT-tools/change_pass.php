<?php
    // 2013 (C) GRES
    // Author: Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["username"]) && isset($_SESSION["user_dir"]) )
       $user = $_SESSION["username"];
    else {
	header( "Location: login.php" );
	exit();
    }
?>

<html>
<head>
    <title>IOPT Tools</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<center>
<br />
<p><font size="+2">
<b> IOPT Tools <?php echo "($user)"; ?></b>
</font><br />

<?php
    $old_pass = sha1( $_POST["old_pass"], false );
    $new_pass = sha1( $_POST["new_pass"], false );
    $old_dir = "users/" . $user . "__" . $old_pass;
    $new_dir = "users/" . $user . "__" . $new_pass;

    if( $_POST["change_pass"] && isset($_POST["change_pass"]) ) {
        if( $user == "guest" || $user == "models" ) {
	    echo "<p>Cannot change guest/models password !<p>\n";
        }
        else if( $old_dir != $_SESSION["user_dir"] || !file_exists($old_dir) ) {
	    echo "<p>Incorrect Old Password<p>\n";
	}
        else if( $old_pass == $new_pass ) {
	    echo "<p>Password not changed<p>\n";
	}
        else if( strlen( $_POST["new_pass"] ) < 6 ) {
	    echo "<p>Password too short<p>\n";
	}
        else if( $_POST["new_pass"] != $_POST["confirm"] ) {
	    echo "<p> Password confirmation does not match </p>\n";
	}
	else if( file_exists( $new_dir ) ) {
	    echo "<p>Unable to change Password<p>\n";
	}
	else {
	    rename( $old_dir, $new_dir );
	    $_SESSION["user_dir"] = $new_dir;
	    header( "Location: manage-files.php" );
	    exit();
	}
    }
?>

<form name="pass_form" action="change_pass.php" method="post">
<table border='2' width="60%" height="40%">
<tr><th colspan="2"> Change Password: </th></tr>
<tr><td align="right" width="30%">Old Password:</td>
    <td><input type="password" size="40" name="old_pass"></input></td>
</tr>
<tr><td align="right" width="30%">New Password:</td>
    <td><input type="password" size="40" name="new_pass"></input></td>
</tr>
<tr><td align="right" width="30%">Confirm Password:</td>
<td><input type="password" size="40" name="confirm"></input></td>
</tr>
<tr><td colspan="2" align="center">
<input type="submit" name="change_pass" value="Change"></input> &nbsp;
<input type="button" name="cancel" value="Cancel" onclick="document.location.href='manage-files.php';"></input>
</td></tr>
</table>
</form>
<p>&nbsp;</p>

</center>
</body>
</html>
