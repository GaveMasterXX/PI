<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $out_file = "saved_clipboard.pnml";
        $model_file = $user_dir . "/files/" . $out_file;
    }
    else die("<p>No PNML Document</p>");

    header("Content-type: text/xml");
    readfile( $model_file );
?>
