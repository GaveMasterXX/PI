<?php
    // Author: 2011 (C) Fernando J. G. Pereira

    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_GET["model"] ) ) {
        $fname = addslashes(str_replace( "..", "__", $_GET["model"]));
        $pnml_file = $user_dir . "/files/" . $fname;
    }
    else die("<p>No Document - please check if your browser has cookie support enabled.</p>");

    header("Content-type: image/svg+xml");
    header("Pragma: no-cache");

    $xslDoc = new DOMDocument();
    $xslDoc->load("xsl/iopt2svg-edit.xslt");
    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);
    $proc->setParameter('','width','2048');
    $proc->setParameter('','height','2048');
    $proc->setParameter('','scale','0.5');

    echo $proc->transformToXML($pnmlDoc);
?>
