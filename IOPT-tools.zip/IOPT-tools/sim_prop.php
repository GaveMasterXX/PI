<?php
    // Author: 2013 (C) Fernando J. G. Pereira

    header("Pragma: no-cache");
    session_start();

    if( isset($_SESSION["user_dir"]) ) $user_dir = $_SESSION["user_dir"];
    else $user_dir = ".";

    if( isset( $_SESSION["pnml_file"] ) ) {
        $pnml_file = $user_dir . "/files/" . $_SESSION["pnml_file"];
        $out_file = $_SESSION["pnml_file"];
	$n = strpos( $out_file, "." );
	if( $n > 0 ) $out_file = substr( $out_file, 0, $n );
	if( strlen( $out_file ) < 1 ) die( "Invalid file name" );
    }
    else die("<p>No PNML Document</p>");

    $pnmlDoc = new DOMDocument();
    $pnmlDoc->load($pnml_file);

    $tdset = array();
    $td_cnt = 0;
    $xpath = new DOMXPath( $pnmlDoc );
    $tdlist = $xpath->query( "//pnml/net/place/timedomain/text" );
    foreach( $tdlist as $tdn ) {
        $td = $tdn->textContent;
        if( !isset($tdset[$td]) ) {
	    $tdset[$td] = true;
	    ++$td_cnt;
	}
    }
    if( $td_cnt > 1 ) {
	//aplicar a replace_acs.xsl e obter o novo pnml
	$xslReplace = new DOMDocument;
	$xslReplace->load('xsl/replace_acs_simul.xsl');
	$procReplace = new XSLTProcessor;
	$procReplace->importStyleSheet($xslReplace); 
	$trPnmlDoc = new DOMDocument();
	$trPnmlDoc->loadXML(  $procReplace->transformToXML($pnmlDoc) );
	unset( $pnmlDoc );
	$pnmlDoc = $trPnmlDoc;
    }

    unset( $xpath );
    $xpath = new DOMXPath( $pnmlDoc );

    echo "<HTML>\n";
    echo "<HEAD>\n";
    echo "<TITLE> Simulation Properties </TITLE>\n";
    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n";
    echo "<link href='../css/style.css' rel='stylesheet' type='text/css' media='screen' />\n";
    echo "</HEAD>\n";
    echo "<BODY>\n";
    echo "<font size='-1'>\n";
 
    $model = $xpath->query( "//pnml/net" );
    $name = $model->item(0)->getAttribute( "name" );
    $len = strlen($name);
    if( $len < 10 ) $len = 10;

    echo "<p align='center'> Model: " . 
          "<input type='text' id='netname' readonly='true' value='$name' " .
	  "size='$len' />" .
	  "</p>\n";

    echo "<p>\n";
    echo "<b>Marking:</b><br/>\n";
    echo "<table width='100%'>\n";

    $pl_names = $xpath->query( "//pnml/net/place/name/text" );
    foreach( $pl_names as $pname ) {
	$place = $pname->parentNode->parentNode;
        $name = $pname->textContent;
        $id = $place->getAttribute( "id" );
	echo "<tr>\n";
	echo "  <td align='right' width='70%'>$name:</td>\n";
	echo "  <td><input type='text' size='2' id='place_p_$id' value='0' /></td>\n";
	echo "</tr>\n";
    }
    echo "</table>\n";
    echo "</p>\n";

    echo "<p>\n";
    echo "<b>Input:</b><br/>\n";
    echo "<table width='100%'>\n";

    $signals = $xpath->query( "//pnml/net/input/signal" );
    foreach( $signals as $signal ) {
        $id = $signal->getAttribute( "id" );
	echo "<tr>\n";
	echo "  <td align='right' width='70%'>$id:</td>\n";
	if( $signal->getAttribute("type") == "boolean" )
	    echo "  <td><input type='checkbox' id='input_$id' onchange='parent.readInputs(true, event);'/></td>\n";
	else {
	    $min = $signal->getAttribute("min");
	    $max = $signal->getAttribute("max");

	    echo "  <td><input type='number' step='1' min='$min' max='$max' id='input_$id' value='$min' size='3' onchange='parent.readInputs(true, event);'/>\n";
	    echo "  <input type='hidden' id='min_input_$id' value='$min'/>\n";
	    echo "  <input type='hidden' id='max_input_$id' value='$max'/>\n";
	    echo "</td>\n";
	}
	echo "</tr>\n";
    }
    $events = $xpath->query( "//pnml/net/input/event[@autonomous='true']" );
    foreach( $events as $event ) {
        $id = $event->getAttribute( "id" );
	echo "<tr>\n";
	echo "  <td align='right' width='70%'>Ev. $id:</td>\n";
	echo "  <td><input type='checkbox' id='event_$id' onchange='parent.readInputs(true, event);'/></td>\n";
	echo "</tr>\n";
    }
    echo "</table>\n";
    echo "</p>\n";

    echo "<p>\n";
    echo "<b>Output:</b><br/>\n";
    echo "<table width='100%'>\n";

    $signals = $xpath->query( "//pnml/net/output/signal" );
    foreach( $signals as $signal ) {
        $id = $signal->getAttribute( "id" );
	echo "<tr>\n";
	echo "  <td align='right' width='70%'>$id:</td>\n";
	echo "  <td><input type='text' size='3' id='output_$id' value='0' readonly='true'/>\n";
	if( $signal->getAttribute("type") != "boolean" ) {
	    $min = $signal->getAttribute("min");
	    $max = $signal->getAttribute("max");
	    echo "  <input type='hidden' id='min_output_$id' value='$min'/>\n";
	    echo "  <input type='hidden' id='max_output_$id' value='$max'/>\n";
	}
	echo "</td></tr>\n";
    }
    echo "</table>\n";
    echo "</p>\n";

    echo "</font>\n";
    echo "</BODY>\n";
    echo "</HTML>\n";
?>
